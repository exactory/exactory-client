"""Minimum paper-family citation tiers with exact-version evidence obligations.

set_roots accepts {profile, roots: [exact IDs], collection_ids: [IDs], target?,
historical_cutoff?}. Verification target is {kind: work, id, source_id, sha256};
an incomplete pin may be prepared but cannot complete the foundation. Scope
changes replace literature_scope/{profile}; Store events preserve prior scopes.

Graph traversal includes every registry occurrence of a Tier 1/2 captured version
and the occurrences of the bundle selected for each of its acquired originals that
has a bundle. An acquired original is an available main original (main_captures),
so an original that a bundle of another of the version's bodies links as a
supplement unit is another body. Only a version none of whose acquired originals
has a bundle reads the bundle selected for each other body among its bundles, such
as the saved response of a passage or such a supplement, so a bundle of another
body is not read beside a bundle of an acquired original, whichever was imported
first, while a passage bundle whose body is an acquired original is read as that
original's bundle. A verification target reads the bundle of each acquired
original whatever its pin; the pin decides only which originals owe a complete
bibliography. A bundle that a later bundle of the same body replaced contributes
no occurrence. A root
(Tier 1) is read in full with its complete bibliography. Its references are Tier 3
(abstract) unless an active full-text requirement of this profile selects them
(require-fulltext, or a work cited by the selected search judgment of a purpose);
a selected reference is Tier 2 (full reading and complete bibliography) wherever it
appears in the network, and its own references are Tier 3 unless selected too. The author therefore reads few papers in full while every
reference of those papers is still inventoried and read at abstract depth.
Registry observations never establish a complete article bibliography. Aliases
resolve families only; an unversioned reference includes all captured versions
of its unambiguous family without claiming their contents are interchangeable.
An occurrence or resolution that carries target_family resolves to that family
alone, after the same validation as at import; an exact arXiv target of that
family keeps its version. Every other occurrence keeps the ordinary lookup, so
conflicting assertions still report ambiguous_alias.
"""

from .errors import ResearchError
from .components import is_component
from .evidence import digest
from .identities import family_versions, normalize_identifier, select_family
from .operations import fields, iso_date, prepared_mutation, profile_name, strings
from .source_links import exact_work, fulltext_capture


def obligation(code, explanation, **affected):
    return dict(code=code, explanation=explanation, **affected)


def format_search_requirement_id(search_id, version_id):
    """The ID of the full-text requirement that a search judgment creates for one cited work."""
    return "search:" + digest([search_id, version_id])


def find_active_requirements(records):
    """The full-text requirements that count now: {id: requirement}.

    A search judgment owns the requirements of its cited works only while it is the selected
    judgment of its profile and purpose; once the selection names another judgment, they stop
    counting. The stored records never change, and every other requirement always counts."""
    selection = records.get("search_selection", {})
    retired_ids = set()
    for search in records.get("literature_search", {}).values():
        selected_id = selection.get(search["profile"] + ":" + search["purpose"], {}).get("search_id")
        if selected_id is not None and selected_id != search["id"]:
            retired_ids.update(format_search_requirement_id(search["id"], version) for version in search["cited_work_ids"])
    return {key: value for key, value in records.get("fulltext_requirement", {}).items() if key not in retired_ids}


def find_bound_requirements(records, profile, graph):
    """The full-text requirements of the profile that a binding or a digest holds: {id: requirement}.

    It holds every record of a version while the version is a required full text: while one of its own records
    counts, or while the profile's citation graph places it at Tier 1 or 2. For such a version these are the
    records that bindings held before a replaced judgment's requirements stopped counting. A binding therefore
    changes when a record is added or a version starts or stops being a required full text, and not when a
    record stops counting while its version stays a required full text."""
    required_versions = {version for node in graph["nodes"] if node["tier"] <= 2 for version in node["version_ids"]}
    required_versions.update(r["version_id"] for r in find_active_requirements(records).values() if r["profile"] == profile)
    return {key: value for key, value in records.get("fulltext_requirement", {}).items()
            if value["profile"] == profile and value["version_id"] in required_versions}


def validate_target(records, target, roots):
    fields(target, ("kind", "id", "source_id", "sha256"), code="invalid_target")
    if target["kind"] != "work" or target["id"] not in roots:
        raise ResearchError("invalid_target", "Verification roots must include the exact pinned work")
    work = exact_work(records, target["id"])
    if target["source_id"] is None or target["sha256"] is None:
        if target["source_id"] is not None or target["sha256"] is not None:
            raise ResearchError("invalid_target", "An incomplete source pin must leave both source_id and sha256 null")
        return
    capture = fulltext_capture(work, target["source_id"])
    if (capture is None or is_component(capture) or capture["original"] is None or capture["original"]["sha256"] != target["sha256"]
            or capture["availability"] != "available"):
        raise ResearchError("invalid_target", "The pin must identify the exact work's available original main document")


def set_roots(store, payload, *, expected_revision, request_id):
    def prepare(records, value):
        fields(value, ("profile", "roots", "collection_ids"), ("target", "historical_cutoff"))
        profile_name(value["profile"])
        roots = strings(value["roots"], "Roots", nonempty=True, code="invalid_roots")
        if len(roots) > 5:
            raise ResearchError("invalid_roots", "Choose one to five closest paper families")
        works = []
        for identifier in roots:
            try:
                work = exact_work(records, identifier)
            except ResearchError as error:
                raise ResearchError("invalid_roots", "Roots must name acquired exact versions", {"identifier": identifier}) from error
            if work["id"] != identifier:
                raise ResearchError("invalid_roots", "Use the canonical exact work ID for each root")
            works.append(work)
        if len({w["work_id"] for w in works}) != len(roots):
            raise ResearchError("invalid_roots", "Root comparisons must be distinct paper families")
        strings(value["collection_ids"], "Collections")
        for collection in value["collection_ids"]:
            if collection not in records.get("collection", {}):
                raise ResearchError("unknown_collection", "Collect the frozen cohort before selecting it")
        if value.get("historical_cutoff") is not None:
            iso_date(value["historical_cutoff"])
        if value["profile"] == "verification":
            validate_target(records, value.get("target"), roots)
            configured = records.get("configuration", {}).get("research", {})
            if configured.get("profile") == "verification" and configured.get("target") != value["target"]:
                raise ResearchError("target_mismatch", "Literature target must match the configured verification target")
        elif value.get("target") is not None:
            raise ResearchError("invalid_target", "Research literature scope does not define an author objective")
        return [("literature_scope", value["profile"], value)], value

    return prepared_mutation(store, "literature.roots", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def index_bundles(records):
    bundles = records.get("source_bundle", {})
    by_version = {}
    for bundle in bundles.values():
        entry = by_version.setdefault(bundle["version_id"], {"originals": {}, "supplements": set()})
        original = bundle["original_sha256"]
        previous = entry["originals"].get(original)
        if previous is None or bundle["sequence"] > bundles[previous]["sequence"]:
            entry["originals"][original] = bundle["id"]
        entry["supplements"].update(unit["link"]["source_id"] for unit in bundle["units"]
            if unit["kind"] == "supplement" and unit["link"] is not None
            and unit["link"]["source_id"] != bundle["source_id"])
    return by_version


def selected_bundle(records, version_id, target=None, *, bundle_index=None):
    selection = records.get("bundle_selection", {}).get(version_id, {})
    selected = records.get("source_bundle", {}).get(selection.get("bundle_id"))
    if target is None or target.get("id") != version_id or target.get("sha256") is None:
        return selected
    if selected is not None and selected["version_id"] == version_id and selected.get("original_sha256") == target["sha256"]:
        return selected
    if bundle_index is None:
        candidates = (bundle for bundle in records.get("source_bundle", {}).values()
                      if bundle["version_id"] == version_id and bundle.get("original_sha256") == target["sha256"])
        return max(candidates, key=lambda bundle: bundle["sequence"], default=None)
    bundle_id = bundle_index.get(version_id, {}).get("originals", {}).get(target["sha256"])
    return records.get("source_bundle", {}).get(bundle_id)


def main_captures(records, work, target=None, *, bundle_index=None):
    """Distinct available originals, excluding explicitly inventoried supplements."""
    if bundle_index is None:
        supplements = {u["link"]["source_id"] for b in records.get("source_bundle", {}).values() if b["version_id"] == work["id"]
                       for u in b["units"] if u["kind"] == "supplement" and u["link"] is not None and u["link"]["source_id"] != b["source_id"]}
    else:
        supplements = bundle_index.get(work["id"], {}).get("supplements", set())
    captures = {}
    for capture in work["fulltexts"]:
        if is_component(capture) or capture["availability"] != "available" or capture["source_id"] in supplements:
            continue
        if target and target.get("id") == work["id"] and capture["original"]["sha256"] != target.get("sha256"):
            continue
        captures.setdefault(capture["original"]["sha256"], capture)
    return list(captures.values())


def citation_graph(records, profile):
    profile_name(profile)
    scope = records.get("literature_scope", {}).get(profile)
    if not scope:
        return {"nodes": [], "references": [], "obligations": [obligation("roots_missing", "Select one to five exact starting works.")]}
    versions, tiers = {}, {}
    obligations, references = [], {}
    selected_families = set()
    for requirement in find_active_requirements(records).values():
        work = records.get("work", {}).get(requirement["version_id"])
        if requirement["profile"] == profile and work is not None:
            selected_families.add(work["work_id"])
    for identifier in scope["roots"]:
        work = records.get("work", {}).get(identifier)
        if work is None:
            obligations.append(obligation("root_missing", "Reacquire the selected exact root.", version_id=identifier))
            continue
        versions.setdefault(work["work_id"], set()).add(identifier)
        tiers[work["work_id"]] = 1
    # A registry observation has no bundle and is always read. Of a version's bundles, the graph reads the one
    # selected for each acquired original that has a bundle; a version none of whose acquired originals has a
    # bundle reads the one selected for each other body instead, such as the saved response of a passage or an
    # original that the bundle of another body links as a supplement. A bundle that a later bundle of the same
    # body replaced is never read, so its occurrences carry no obligation.
    bundle_index = index_bundles(records)
    read_bundle_ids = set()
    for version, entry in bundle_index.items():
        version_bodies = set(entry["originals"])
        acquired_bodies = version_bodies & {c["original"]["sha256"]
                                            for c in main_captures(records, records["work"][version], bundle_index=bundle_index)}
        read_bundle_ids.update(selected_bundle(records, version, {"id": version, "sha256": body}, bundle_index=bundle_index)["id"]
                               for body in acquired_bodies or version_bodies)
    by_source = {}
    for occurrence in records.get("reference_occurrence", {}).values():
        if "bundle_id" not in occurrence or occurrence["bundle_id"] in read_bundle_ids:
            by_source.setdefault(occurrence["source_work_id"], []).append(occurrence)
    processed = {}
    while True:
        pending = [(family, version) for family in sorted(versions) if tiers[family] <= 2
                   for version in sorted(versions[family]) if processed.get(version, 4) > tiers[family]]
        if not pending:
            break
        for family, version in pending:
            tier = tiers[family]
            processed[version] = tier
            for occurrence in sorted(by_source.get(version, []), key=lambda x: x["id"]):
                resolution = records.get("reference_resolution", {}).get(occurrence["id"], {})
                kind, target = resolution.get("kind", occurrence["kind"]), resolution.get("target", occurrence["target"])
                row = {"occurrence_id": occurrence["id"], "version_id": version, "source_id": occurrence["source_id"],
                       "kind": kind, "target": target, "raw": occurrence["raw"], "target_family": None, "status": "unresolved"}
                if kind == "nonpaper":
                    row["status"] = "nonpaper"
                elif target is not None:
                    try:
                        identifier = normalize_identifier(target)
                        selection = resolution or occurrence
                        if "target_family" in selection:
                            chosen = select_family(records, identifier, selection["target_family"])
                            candidates = records["work_family"][chosen]["version_ids"]
                            exact = records.get("work", {}).get(identifier)
                            if (exact is not None and exact["work_id"] == chosen
                                    and (not identifier.startswith("arxiv:") or exact["version"] is not None)):
                                candidates = [identifier]
                        else:
                            candidates = ([identifier] if identifier in records.get("work", {})
                                          else family_versions(records, identifier))
                            # Ordinary references still expose conflicting registry identity assertions.
                            family_versions(records, identifier)
                        candidates = [v for v in candidates if not v.startswith("arxiv:") or records["work"][v]["version"] is not None]
                        if not candidates:
                            raise ResearchError("missing_version", "Reference has no captured exact version")
                        target_family = records["work"][candidates[0]]["work_id"]
                        row.update(target_family=target_family, status="resolved", version_ids=sorted(candidates))
                        versions.setdefault(target_family, set()).update(candidates)
                        target_tier = 2 if target_family in selected_families else 3
                        tiers[target_family] = min(tiers.get(target_family, 4), target_tier)
                    except ResearchError as error:
                        row["status"] = error.code
                references[occurrence["id"]] = row
    for version in sorted(processed):
        captures = main_captures(records, records["work"][version], scope.get("target"), bundle_index=bundle_index)
        for capture in captures or [None]:
            pin = {"id": version, "sha256": capture["original"]["sha256"]} if capture else scope.get("target")
            bundle = selected_bundle(records, version, pin, bundle_index=bundle_index)
            if bundle is None or bundle["scope"] != "article" or not bundle.get("bibliography", {}).get("complete"):
                obligations.append(obligation("bibliography_incomplete", "Import an evidence-linked complete article bibliography; registry counts are insufficient.",
                                              version_id=version, source_id=capture["source_id"] if capture else None))
    for row in references.values():
        if row["status"] not in ("resolved", "nonpaper"):
            code = "reference_identity_ambiguous" if row["status"] == "ambiguous_alias" else "reference_unresolved"
            obligations.append(obligation(code, "Resolve this reference occurrence using saved identity evidence or a supported non-paper classification.",
                version_id=row["version_id"], reference_id=row["occurrence_id"], target=row["target"]))
    return {"nodes": [{"work_id": family, "tier": tiers[family], "version_ids": sorted(versions[family])} for family in sorted(tiers)],
            "references": sorted(references.values(), key=lambda r: r["occurrence_id"]), "obligations": obligations}

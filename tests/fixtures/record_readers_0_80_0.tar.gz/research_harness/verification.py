"""Task-only server identity, original-body preparation and exact verdict binding.

The server does not supply an original-document hash. Local acquisition supplies
that pin. A request's creator can independently verify an external paper; the
requestedByViewer flag is not an authorship declaration.

Under sampled-v1, a bound verdict states the percentile its own sample computes
and a band that contains the computed band, and it widens that band on one side
once the sample leaves more than sampling.UNPLACED_WIDEN members unplaced. The
bound record keeps the estimate in sample_prediction, which the other
preparation policies leave null.
"""

from .artifacts import ArtifactStore
from .errors import ResearchError
from .evaluation import Evaluation
from .evidence import digest
from .identities import normalize_identifier
from .operations import fields, immutable_record, prepared_mutation, text
from .principles import preparation_policy
from .reading import validate_read_evidence
from .source_links import validate_link
from .storage import check_command_bounds
from .synthesis import synthesis_state
from .workspace import strict_json


def task_identity(task):
    if not isinstance(task, dict) or not {"verificationId", "doi", "source", "sourceId", "sourceVersion", "url"} <= task.keys():
        raise ResearchError("verification_target_pending", "The task must supply its concrete source and version identity")
    for key in ("verificationId", "doi", "source", "sourceId", "url"):
        text(task[key], "Task " + key)
    if task["source"] == "arxiv":
        version = task["sourceVersion"]
        if type(version) is not int or version <= 0:
            raise ResearchError("verification_target_mismatch", "A versionless arXiv task cannot certify an exact body")
        work = normalize_identifier("arxiv:" + task["sourceId"] + "v" + str(version))
        if normalize_identifier(task["url"]) != work:
            raise ResearchError("verification_target_mismatch", "The task URL differs from its concrete source version")
        return {"source": "arxiv", "source_id": task["sourceId"], "version": version, "work_ids": [work]}
    if task["source"] == "zenodo":
        identifier = task["sourceId"]
        if not identifier.isdigit() or task["url"].rstrip("/") != "https://zenodo.org/records/" + identifier:
            raise ResearchError("verification_target_mismatch", "A Zenodo task must identify its concrete record")
        return {"source": "zenodo", "source_id": identifier, "version": task["sourceVersion"],
                "work_ids": ["doi:10.5281/zenodo." + identifier, "url:https://zenodo.org/records/" + identifier]}
    raise ResearchError("verification_target_pending", "This source needs a supported exact task identity adapter")


def _preparation(records, artifacts, task):
    try:
        report = synthesis_state(records, artifacts, "verification")
    except ResearchError as error:
        raise ResearchError("readiness_required", "Exact-target preparation contains unavailable or changed source bytes",
                            {"obligations": [error.as_dict()]}) from error
    if not report["ready"]:
        raise ResearchError("readiness_required", "Read the exact target and complete independent verification preparation",
                            {"obligations": report["obligations"]})
    target = report["configuration"]["target"]
    identity = task_identity(task)
    if target["id"] not in identity["work_ids"]:
        raise ResearchError("verification_target_mismatch", "The current task is a different concrete work from the acquired original body",
                            {"target": target, "task_identity": identity})
    return report, target, identity


def record_task(store, payload, *, expected_revision, request_id):
    """Capture a task-only response after acquiring its configured exact body."""
    def prepare(records, value):
        artifacts = Evaluation(records, store.build_artifact_store())
        fields(value, ("task",))
        report, target, identity = _preparation(records, artifacts, value["task"])
        record = {"task": value["task"], "target": target, "identity": identity,
                  "preparation_digest": report["digest"], "observed_revision": expected_revision}
        record["digest"] = digest(record)
        return [immutable_record(records, "verification_task", record["digest"], record),
                ("verification_selection", "task", {"digest": record["digest"]})], record
    return prepared_mutation(store, "verification.task", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def _body(artifacts, reference):
    return validate_verdict_body(strict_json(artifacts.read(reference)))


def validate_verdict_body(body):
    fields(body, ("stance", "summary", "prediction"),
           ("rationaleSections", "wouldChange", "suggestions", "findings", "supersedesVerdictId"))
    text(body["stance"], "Verdict stance")
    text(body["summary"], "Verdict summary")
    if not isinstance(body["prediction"], dict) or "percentile" not in body["prediction"]:
        raise ResearchError("prediction_required", "Record the separate cohort impact prediction")
    return body


def review_packet(records, artifacts, task_digest):
    """Exact external-paper evidence without prior verdicts or strategic gates."""
    from .review_packets import _source_closure, scrub
    from .sampling import SAMPLED, current_sample, prediction
    task = records.get("verification_task", {}).get(task_digest)
    if task is None:
        raise ResearchError("verification_task_required", "Bind the exact verification task before review assignment")
    report, target, identity = _preparation(records, artifacts, task["task"])
    versions = {reading["version_id"] for reading in records.get("reading", {}).values()}
    versions.add(target["id"])
    packet = {"kind": "verification", "task_digest": task_digest, "target": target,
                  "task_identity": identity, "preparation_digest": report["digest"],
                  "sources": _source_closure(records, versions),
                  "standards": report.get("sections", {}).get("standards"),
                  "prediction_cohort": [record["definition"] for record in records.get("collection", {}).values()]}
    if preparation_policy(records) == SAMPLED:
        packet["sampling_context"] = {"sample": current_sample(records), "prediction": prediction(records)}
    return scrub(packet)


def require_verdict_assignment(records, artifacts, value, body):
    from .review_protocol import assignment_state
    from .review_parts_study import require_complete_series
    from .operations import normalized_text
    assessment = value["assessment"]
    identifier = assessment.get("assignment_id")
    if identifier is None:
        raise ResearchError("review_assignment_missing", "An independent verdict needs its observed exact-paper assignment")
    state = assignment_state(records, artifacts, identifier)
    if not state["ready"]:
        raise ResearchError("review_context_unverified", "The current verifier context does not establish independence", {"obligations": state["obligations"]})
    assignment = records["review_assignment"][identifier]
    series = require_complete_series(records, artifacts, identifier)
    packet = series['packets'][-1] if series else strict_json(artifacts.read(assignment["packet"]))
    if (state["role"] != "verification" or packet.get("paper", {}).get("task_digest") != value["task_digest"]
            or normalized_text(state["reviewer_id"]) != normalized_text(assessment["assessor"])):
        raise ResearchError("verification_target_mismatch", "Use the observed verifier and exact task evidence")
    if state["output"] != {"verdict": body, "checks": assessment["checks"]}:
        raise ResearchError("review_output_mismatch", "Bind the observed verifier's unchanged body and separate scientific checks")
    return state


def bind_verdict(store, payload, *, expected_revision, request_id):
    """Bind {id, task_digest, body:ArtifactRef, assessment} without changing the wire schema."""
    def prepare(records, value):
        from .sampling import SAMPLED, UNPLACED_WIDEN, prediction
        artifacts = Evaluation(records, store.build_artifact_store())
        fields(value, ("id", "task_digest", "body", "assessment"))
        text(value["id"], "Verdict assessment ID")
        task = records.get("verification_task", {}).get(value["task_digest"])
        if task is None:
            raise ResearchError("verification_task_required", "Acquire and bind the task-only server target first")
        report, target, identity = _preparation(records, artifacts, task["task"])
        body = _body(artifacts, value["body"])
        # exactory verify sends this body, and the remote intent keeps it deeper than its file, so it is a command
        # input. The bind-verdict payload only refers to the body, so the refusal names the body.
        check_command_bounds(body, "The verdict body")
        sample_prediction = None
        if preparation_policy(records) == SAMPLED:
            sample_prediction = prediction(records)
            claimed = body["prediction"]
            fields(claimed.get("band"), ("best", "worst"))
            band = claimed["band"]
            if any(type(n) is not int or not 1 <= n <= 100 for n in (claimed["percentile"], band["best"], band["worst"])):
                raise ResearchError("invalid_input", "Percentile and band are integers from 1 to 100")
            computed = sample_prediction["band"]
            # The clauses in the order the refusal names them: a sample that placed no member
            # states no percentile; the verdict claims the computed percentile; its band contains
            # the computed one; and it widens that band once more than UNPLACED_WIDEN of the
            # sampled members stay unplaced (spec 5.2).
            if computed is None:
                mismatch_msg = "The sample places no member; revise the placements before binding"
            elif claimed["percentile"] != sample_prediction["percentile"]:
                mismatch_msg = "The verdict's percentile equals the sample estimate of %d" % sample_prediction["percentile"]
            elif band["best"] > computed["best"] or band["worst"] < computed["worst"]:
                mismatch_msg = "The verdict's band contains the sample band %d..%d" % (computed["best"], computed["worst"])
            elif sample_prediction["widen_required"] and (band["best"], band["worst"]) == (computed["best"], computed["worst"]):
                mismatch_msg = ("More than %d sampled members are unplaced; widen the band beyond the sample band %d..%d"
                                % (UNPLACED_WIDEN, computed["best"], computed["worst"]))
            else:
                mismatch_msg = None
            if mismatch_msg is not None:
                raise ResearchError("prediction_mismatch", mismatch_msg, {"sample": sample_prediction, "claimed": claimed})
        assessment = value["assessment"]
        fields(assessment, ("assessor", "provenance", "independence_basis", "blind", "checks"), ("assignment_id",))
        text(assessment["assessor"], "Verifier identity")
        text(assessment["independence_basis"], "Independent verification basis")
        artifacts.read(assessment["provenance"])
        if assessment["blind"] is not True:
            raise ResearchError("review_not_independent", "The verifier must assess the paper before reading other verdicts")
        if not isinstance(assessment["checks"], list):
            raise ResearchError("invalid_verdict_assessment", "Assess soundness, novelty and impact separately")
        evidence, dimensions = [], set()
        for check in assessment["checks"]:
            fields(check, ("dimension", "reason", "evidence"))
            if check["dimension"] not in ("soundness", "novelty", "impact") or check["dimension"] in dimensions:
                raise ResearchError("invalid_verdict_assessment", "Assess soundness, novelty and impact exactly once each")
            dimensions.add(check["dimension"])
            text(check["reason"], "Verification reasoning")
            if not isinstance(check["evidence"], list) or not check["evidence"]:
                raise ResearchError("invalid_verdict_assessment", "Support each distinct assessment with actual full-read source links")
            for link in check["evidence"]:
                validate_link(records, artifacts, link)
                evidence.append(validate_read_evidence(records, artifacts, link, depth="fulltext", target=target))
        if dimensions != {"soundness", "novelty", "impact"}:
            raise ResearchError("invalid_verdict_assessment", "Keep validity independent of novelty and impact prediction")
        if not any(link["version_id"] == target["id"] for c in assessment["checks"] if c["dimension"] == "soundness" for link in c["evidence"]):
            raise ResearchError("invalid_verdict_assessment", "The soundness reasoning must inspect the exact target itself")
        require_verdict_assignment(records, artifacts, value, body)
        record = dict(value, target=target, task_identity=identity, verification_id=task["task"]["verificationId"],
                      preparation_digest=report["digest"], evidence=evidence, sample_prediction=sample_prediction,
                      reviewed_revision=expected_revision)
        record["digest"] = digest(record)
        return [immutable_record(records, "verdict_assessment", value["id"], record),
                ("verification_selection", "verdict", {"id": value["id"]})], record
    return prepared_mutation(store, "verification.verdict", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def validate_verdict(store, task, body):
    snapshot = store.snapshot()
    records = snapshot["records"]
    artifacts = Evaluation(records, store.build_artifact_store())
    report, target, identity = _preparation(records, artifacts, task)
    selection = records.get("verification_selection", {}).get("verdict")
    if selection is None:
        raise ResearchError("verdict_assessment_required", "Bind an evidence-linked assessment of this exact verdict body")
    saved = records["verdict_assessment"][selection["id"]]
    if saved["verification_id"] != task["verificationId"] or saved["task_identity"] != identity or saved["target"] != target:
        raise ResearchError("verification_target_mismatch", "The current server task differs from the assessed exact target")
    if saved["preparation_digest"] != report["digest"]:
        raise ResearchError("verdict_assessment_stale", "Reassess the verdict against current exact-target preparation")
    if _body(artifacts, saved["body"]) != body:
        raise ResearchError("verdict_body_mismatch", "The transmitted verdict body must equal the bound assessment, including revisions")
    for check in saved["assessment"]["checks"]:
        for link in check["evidence"]:
            validate_read_evidence(records, artifacts, link, depth="fulltext", target=target)
    require_verdict_assignment(records, artifacts, saved, body)
    return {"ready": True, "revision": snapshot["revision"], "assessment": saved, "body": body, "task": task,
            "preparation_digest": report["digest"]}

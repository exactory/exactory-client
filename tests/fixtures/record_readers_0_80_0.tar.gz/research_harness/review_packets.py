"""Neutral packets for independent reviewers.

A readiness reviewer needs the candidate, its branches, plans, assessments,
checkpoints, sources and the synthesis sections to judge validity, scope,
novelty, contribution, development and branches. A manuscript reviewer needs
the exact files, the claim-to-evidence map, the evidence those claims cite,
the observed executions behind result evidence, and the field standards.
Neither needs revision labels, request identities, launcher tokens, author
names, assessment history, strategy accounts or the author's own plans, so
those never enter a packet. A round assessor judges the research program, not
the paper's quality, so the round packet deliberately carries history: the
manuscript packet, every blind review and prediction of the bundle, the
decision under review, every round's goal and assessment, the closing round's
development blocks, the synthesis sections, the consequence searches, the
study's current Grand Challenge record, the bundle's contribution analysis with
the captured responses of its investigation, the record that analysis named its
criteria against when another has replaced it, and the resource accounts; author names, request identities, launcher tokens and
revision labels still never enter it. Delivery copies exactly the artifacts a
packet references.
"""

from .challenge import find_current_challenge
from .contribution import find_analysis
from .evidence import digest
from .predictions import measurement_summary
from .principles import objective_changes
from .publication import latest_reviews, read_bundle_input
from .resources import account_report
from .rounds import admissions, assessment_for, closing_round_assessments
from .source_deferrals import build_source_gap_disclosure


_FORBIDDEN_KEYS = ("request_id", "token")
_FORBIDDEN_SUFFIX = "_revision"


def scrub(value, keys=_FORBIDDEN_KEYS):
    """Remove request identities, launcher tokens, revision labels and the named keys at every depth."""
    if isinstance(value, dict):
        return {key: scrub(item, keys) for key, item in value.items()
                if key not in keys and not key.endswith(_FORBIDDEN_SUFFIX)}
    if isinstance(value, list):
        return [scrub(item, keys) for item in value]
    return value


def readiness_packet(report):
    """The six readiness checks' evidence, without labels, history or author names at any depth."""
    inputs = dict(report["review_inputs"])
    inputs["synthesis"] = {key: value for key, value in inputs["synthesis"].items() if key != "history"}
    foundation = inputs["synthesis"]["foundation"]
    if "source_deferrals" in foundation:
        # Reviewers receive the scientific gap, never the private authorization or logs.
        inputs["synthesis"]["foundation"] = dict(foundation, source_deferrals=build_source_gap_disclosure(foundation["source_deferrals"]))
    return scrub({"kind": "readiness", "inputs": inputs, "execution_observations": report["execution_observations"]},
                 _FORBIDDEN_KEYS + ("authors",))


def _source_closure(records, version_ids):
    works, readings, bundles, source_ids = {}, {}, {}, set()
    readings_by_version, bundles_by_version = {}, {}
    for reading in records.get("reading", {}).values():
        readings_by_version.setdefault(reading["version_id"], []).append(reading)
    for bundle in records.get("source_bundle", {}).values():
        bundles_by_version.setdefault(bundle["version_id"], []).append(bundle)
    for version in sorted(version_ids):
        work = records.get("work", {}).get(version)
        if work is None:
            continue
        works[version] = work
        source_ids.update(work.get("source_ids", []))
        for reading in readings_by_version.get(version, ()):
            readings[reading["id"]] = reading
            source_ids.update(i["link"]["source_id"] for i in reading["inspections"])
        for bundle in bundles_by_version.get(version, ()):
            bundles[bundle["id"]] = bundle
            source_ids.update(u["link"]["source_id"] for u in bundle["units"] if u["link"] is not None)
    sources = {identifier: records["source"][identifier] for identifier in sorted(source_ids) if identifier in records.get("source", {})}
    return {"work": works, "reading": readings, "source_bundle": bundles, "source": sources}


def manuscript_packet(records, bundle, artifacts=None):
    """The exact manuscript, its claim evidence closure, observed executions and field standards."""
    inputs = read_bundle_input(bundle, artifacts, "review_inputs")
    observations = read_bundle_input(bundle, artifacts, "execution_observations")
    versions, executions = set(), set()
    for claim in bundle["claim_evidence"]:
        for item in claim["evidence"]:
            if item.get("kind") == "source":
                versions.add(item["link"]["version_id"])
            elif item.get("kind") == "result":
                executions.add(item["execution_id"])
    results = {}
    for identifier in sorted(executions):
        execution = records.get("execution", {}).get(identifier)
        results[identifier] = {"execution": execution["payload"] if execution else None,
                               "observation": observations.get(identifier)}
    standards = inputs["synthesis"]["sections"].get("standards", {}).get("payload")
    foundation = inputs["synthesis"]["foundation"]
    packet = {"kind": "manuscript", "bundle_digest": bundle["digest"], "files": bundle["files"],
              "claim_evidence": bundle["claim_evidence"], "evidence": _source_closure(records, versions),
              "results": results, "standards": standards,
              "digest": digest({"bundle": bundle["digest"], "claims": bundle["claim_evidence"]})}
    if "source_deferrals" in foundation:
        packet["source_gaps"] = build_source_gap_disclosure(foundation["source_deferrals"])
    if bundle.get("publication_scope") is not None:
        packet["scientific_scope"] = bundle["publication_scope"]["projection"]
    return scrub(packet)


def round_packet(records, bundle, decision, artifacts=None):
    """The paper, its reviews and predictions, the decision under review, and the program's history."""
    reviews = [{"id": saved["id"], "kind": saved["assessor"]["kind"], "core": saved["core"]}
               for saved in latest_reviews(records, bundle["digest"]).values()]
    predictions = [saved["prediction"] for saved in records.get("manuscript_prediction", {}).values()
                   if saved["bundle_digest"] == bundle["digest"]]
    history = []
    for admission in admissions(records):
        opened_by = records["round_decision"][admission["decision_id"]]
        assessment = assessment_for(records, admission["id"])
        history.append({"number": admission["number"], "goal": admission["goal"], "objective": admission["objective"],
                        "resource_limits": admission["resource_limits"],
                        "decision": {k: opened_by[k] for k in ("id", "payload", "digest")},
                        "assessment": None if assessment is None else {k: assessment[k] for k in ("payload", "derived", "successful", "unproductive")}})
    development = {identifier: assessment["payload"]["development"]
                   for identifier, assessment in closing_round_assessments(records).items()}
    selection = records.get("synthesis_selection", {})
    synthesis = {kind: records["synthesis"][selection["research:" + kind]["id"]]["payload"]
                 for kind in ("context", "innovation") if "research:" + kind in selection}
    searches = {}
    for purpose in ("downstream", "next_step"):
        selected = records.get("search_selection", {}).get("research:" + purpose)
        if selected is not None:
            search = records["literature_search"][selected["search_id"]]
            searches[purpose] = {k: search[k] for k in ("purpose", "found_work_ids", "dispositions", "impact", "gaps")}
    current_challenge = find_current_challenge(records)
    analysis = find_analysis(records, bundle["digest"])
    # The analysis named its criteria against the record that was current then; deliver it when another record replaced it.
    analyzed_against = (analysis or {}).get("grand_challenge")
    replaced = analyzed_against is not None and current_challenge is not None and analyzed_against["id"] != current_challenge["id"]
    manifest = {"kind": "round", "manuscript": manuscript_packet(records, bundle, artifacts),
                "reviews": reviews, "predictions": predictions,
                "measurement": measurement_summary(records, bundle),
                "decision": {"payload": decision["payload"], "digest": decision["digest"], "closes": decision["closes"]},
                "rounds": history, "development": development, "synthesis": synthesis, "searches": searches,
                "grand_challenge": current_challenge["payload"] if current_challenge else None,
                "contribution_analysis": analysis["payload"] if analysis else None,
                "analysis_grand_challenge": records["grand_challenge"][analyzed_against["id"]]["payload"] if replaced else None,
                "resources": account_report(records, "research"),
                "digest": digest({"bundle": bundle["digest"], "decision": decision["digest"]})}
    changes = objective_changes(records)
    if changes:
        manifest["objective_changes"] = changes
    return scrub(manifest, _FORBIDDEN_KEYS + ("authors", "author"))


def find_round_investigation_responses(records, manifest):
    """Bind post-measurement captures to this nonblind program assessment only.

    A captured query is not a source import or a scientific reading. Its original
    bytes let the round assessor judge the author's investigation independently.
    They are created after the scientific scope and manuscript have been pinned.
    """
    if manifest.get("kind") != "round":
        return []
    analysis = find_analysis(records, manifest.get("manuscript", {}).get("bundle_digest"))
    if analysis is None:
        return []
    payload = scrub(analysis["payload"], _FORBIDDEN_KEYS + ("authors", "author"))
    if manifest.get("contribution_analysis") != payload:
        return []
    return [entry["response"] for entry in payload.get("investigation", [])]

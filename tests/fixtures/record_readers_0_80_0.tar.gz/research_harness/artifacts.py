"""Atomic, content-addressed objects with checked workspace-relative paths.

Objects are published only after all bytes have been written and synced. An
existing address is verified, never overwritten. Directory descriptors and
O_NOFOLLOW keep object traversal within the selected workspace on macOS/Linux.
Read-only operations never create directories or files.
"""

import errno
import hashlib
import io
import os
import re
import stat
import uuid
from contextlib import contextmanager
from pathlib import Path

from .errors import ResearchError
from .file_streams import _check_file_size, _copy_stream, freeze_file


_OBJECT_DIRECTORY = "research/sources/objects"
_SEALED_DIRECTORY = "research/sources/sealed"
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_TOKEN = r"[-!#$%&'*+.^_`|~0-9A-Za-z]+"
_MEDIA_TYPE = re.compile(_TOKEN + "/" + _TOKEN + r"(?:;[\x20-\x7e]+)?\Z")


class _CheckEffectRequired(BaseException):
    pass


def _filesystem_error(error: OSError) -> ResearchError:
    if error.errno in (errno.ELOOP, errno.ENOTDIR):
        return ResearchError("unsafe_path", "Research paths must not contain symlinks or non-directories")
    return ResearchError("storage_io", "Research filesystem operation failed", {"errno": error.errno})


@contextmanager
def _artifact_operation():
    """Translate errors only within an artifact operation's own I/O boundary."""
    try:
        yield
    except FileNotFoundError:
        raise
    except OSError as error:
        raise _filesystem_error(error) from error


def _relative_parts(relative: str):
    if (not isinstance(relative, str) or not relative or "\\" in relative or "\x00" in relative
            or any(part in ("", ".", "..") for part in relative.split("/"))):
        raise ResearchError("unsafe_path", "Expected a canonical workspace-relative path")
    return relative.split("/")


class _Workspace:
    """Shared checked filesystem boundary for SQLite and content objects."""

    def __init__(self, root: Path):
        try:
            supplied = Path(root).absolute()
            # Resolve the caller-selected parent, including macOS /var aliases,
            # but retain the final component so a symlinked workspace is rejected.
            self.root = supplied.parent.resolve() / supplied.name
        except (TypeError, ValueError, OSError, RuntimeError) as error:
            raise ResearchError("unsafe_path", "Invalid research workspace path") from error

    @contextmanager
    def directory(self, relative: str, *, create: bool = False):
        parts = list(self.root.parts[1:]) + _relative_parts(relative)
        descriptor = None
        try:
            try:
                descriptor = os.open(self.root.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                for name in parts:
                    if create:
                        try:
                            os.mkdir(name, mode=0o700, dir_fd=descriptor)
                        except FileExistsError:
                            pass
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                    dir_fd=descriptor)
                    try:
                        if create:
                            # An existing entry may belong to a paused earlier creator.
                            # Sync its checked parent before acknowledging any child use.
                            os.fsync(descriptor)
                    except BaseException:
                        os.close(child)
                        raise
                    os.close(descriptor)
                    descriptor = child
            except FileNotFoundError:
                raise
            except OSError as error:
                raise _filesystem_error(error) from error
            # The caller can hold this directory while committing another store.
            # Preserve its failure type and let its own recovery protocol run.
            yield descriptor
        finally:
            if descriptor is not None:
                os.close(descriptor)


def _regular_file(directory: int, name: str) -> int:
    descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    if not stat.S_ISREG(os.fstat(descriptor).st_mode):
        os.close(descriptor)
        raise ResearchError("unsafe_path", "Research content must be a regular file")
    return descriptor


def _media_type(value):
    if not isinstance(value, str) or not _MEDIA_TYPE.fullmatch(value):
        raise ResearchError("invalid_input", "Expected a media type without control characters")


def describe_artifact(data: bytes, media_type: str) -> dict:
    """Describe immutable content without writing it to a workspace."""
    if not isinstance(data, bytes):
        raise ResearchError("invalid_input", "Artifact data must be bytes")
    _media_type(media_type)
    digest = hashlib.sha256(data).hexdigest()
    return {"sha256": digest, "path": _OBJECT_DIRECTORY + "/" + digest,
            "size": len(data), "media_type": media_type}


def is_sealed_artifact(ref):
    return isinstance(ref, dict) and isinstance(ref.get("path"), str) and ref["path"].startswith(
        _SEALED_DIRECTORY + "/")


def validate_reference(ref: dict, *, sealed=False):
    """Check the complete descriptor before filesystem access or a cache hit."""
    if not isinstance(ref, dict) or not {"sha256", "path", "size", "media_type"} <= ref.keys():
        raise ResearchError("invalid_input", "Artifact reference is missing required fields")
    if not isinstance(ref["sha256"], str) or not _SHA256.fullmatch(ref["sha256"]):
        raise ResearchError("invalid_input", "Artifact SHA-256 must have 64 lowercase hexadecimal digits")
    if type(ref["size"]) is not int or ref["size"] < 0:
        raise ResearchError("invalid_input", "Artifact size must be a nonnegative integer")
    _media_type(ref["media_type"])
    _relative_parts(ref["path"])
    directory = _SEALED_DIRECTORY if sealed else _OBJECT_DIRECTORY
    if not sealed and is_sealed_artifact(ref):
        raise ResearchError("artifact_sealed", "Completion-check outputs are sealed unread")
    if ref["path"] != directory + "/" + ref["sha256"]:
        raise ResearchError("unsafe_path", "Artifact path must identify its content-addressed object")


def _verify_object(directory: int, reference: dict, *, retain=True):
    descriptor = _regular_file(directory, reference["sha256"])
    with os.fdopen(descriptor, "rb") as source:
        if not retain:
            _copy_stream(source, expected=reference)
            return
        _check_file_size(source, reference)
        data = source.read()
    return _verify_content(data, reference)


def _verify_content(data, reference):
    if len(data) != reference["size"] or hashlib.sha256(data).hexdigest() != reference["sha256"]:
        raise ResearchError("artifact_corrupt", "Stored artifact does not match its size and SHA-256",
                            {"path": reference["path"]})
    return data


class ArtifactStore:
    """Store immutable bytes and return portable, independently checked references."""

    def __init__(self, root: Path):
        self._workspace = _Workspace(root)
        self.root = self._workspace.root

    def put(self, data: bytes, media_type: str) -> dict:
        reference = describe_artifact(data, media_type)
        return self._put(data, reference, _OBJECT_DIRECTORY)

    def put_stream(self, source, media_type: str, *, expected=None) -> dict:
        """Publish a complete bounded stream, optionally checking a pinned descriptor."""
        return self._publish_stream(source, media_type, expected)

    def put_file(self, path, media_type: str, *, expected=None) -> dict:
        """Insert a regular file through the checked workspace descriptor boundary."""
        from .workspace import open_file
        _media_type(media_type)
        try:
            path = Path(path).absolute()
        except (TypeError, ValueError, OSError, RuntimeError) as error:
            raise ResearchError("unsafe_path", "Invalid artifact input path") from error
        with open_file(path.parent, path.name) as source:
            return self._publish_stream(source, media_type, expected)

    def _publish_stream(self, source, media_type, expected):
        _media_type(media_type)
        if expected is not None:
            validate_reference(expected)
        # Check-mode stores must never inherit a mutating publication path.
        self.require_external_effect()
        with _artifact_operation(), self._workspace.directory(_OBJECT_DIRECTORY, create=True) as directory:
            temporary = ".object-" + uuid.uuid4().hex
            descriptor = os.open(temporary, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                 0o600, dir_fd=directory)
            try:
                with os.fdopen(descriptor, "w+b") as target:
                    identity = _copy_stream(source, target, expected)
                    reference = {"sha256": identity["sha256"],
                                 "path": _OBJECT_DIRECTORY + "/" + identity["sha256"],
                                 "size": identity["size"], "media_type": media_type}
                    target.flush()
                    target.seek(0)
                    _copy_stream(target, expected=reference)
                    os.fchmod(target.fileno(), 0o444)
                    os.fsync(target.fileno())
                try:
                    os.link(temporary, reference["sha256"], src_dir_fd=directory, dst_dir_fd=directory,
                            follow_symlinks=False)
                except FileExistsError:
                    _verify_object(directory, reference, retain=False)
            finally:
                os.unlink(temporary, dir_fd=directory)
            os.fsync(directory)
        return reference

    def require_external_effect(self):
        pass

    def require_local_read(self, kind):
        """Permit runtime identification and verification of retained context."""
        wrapped = self._find_wrapped_store()
        if wrapped is not None:
            wrapped.require_local_read(kind)

    def read_runtime_fingerprint(self, route):
        """Observe the dependencies of one command's optional state memo."""
        wrapped = self._find_wrapped_store()
        if wrapped is not None:
            return wrapped.read_runtime_fingerprint(route)
        from .review_protocol import read_route_runtime
        return read_route_runtime(self, route)

    def _find_wrapped_store(self):
        wrapped = getattr(self, '_store', None)
        from .evaluation import Evaluation
        while isinstance(wrapped, Evaluation):
            wrapped = wrapped.store
        return wrapped

    def put_sealed(self, data: bytes, media_type: str) -> dict:
        reference = describe_artifact(data, media_type)
        reference["path"] = _SEALED_DIRECTORY + "/" + reference["sha256"]
        return self._put(data, reference, _SEALED_DIRECTORY)

    def _put(self, data, reference, relative):
        digest = reference["sha256"]
        with _artifact_operation(), self._workspace.directory(relative, create=True) as directory:
            try:
                _verify_object(directory, reference, retain=False)
                os.fsync(directory)
                return reference
            except FileNotFoundError:
                pass
            temporary = ".object-" + uuid.uuid4().hex
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                 0o600, dir_fd=directory)
            try:
                with os.fdopen(descriptor, "wb") as target:
                    target.write(data)
                    target.flush()
                    os.fchmod(target.fileno(), 0o444)
                    os.fsync(target.fileno())
                try:
                    os.link(temporary, digest, src_dir_fd=directory, dst_dir_fd=directory,
                            follow_symlinks=False)
                except FileExistsError:
                    _verify_object(directory, reference, retain=False)
            finally:
                os.unlink(temporary, dir_fd=directory)
            os.fsync(directory)
        return reference

    def verify_sealed(self, ref):
        """Verify retained unread bytes without returning their contents to a reader."""
        validate_reference(ref, sealed=True)
        try:
            with self._workspace.directory(_SEALED_DIRECTORY) as directory:
                _verify_object(directory, ref, retain=False)
        except FileNotFoundError as error:
            raise ResearchError("artifact_missing", "Sealed artifact has not been stored",
                                {"path": ref["path"]}) from error
        except OSError as error:
            raise _filesystem_error(error) from error

    def read(self, ref: dict) -> bytes:
        validate_reference(ref)
        try:
            with self._workspace.directory(_OBJECT_DIRECTORY) as directory:
                return _verify_object(directory, ref)
        except FileNotFoundError as error:
            raise ResearchError("artifact_missing", "Artifact has not been stored",
                                {"path": ref["path"]}) from error
        except OSError as error:
            raise _filesystem_error(error) from error

    @contextmanager
    def _open_source(self, ref):
        validate_reference(ref)
        try:
            with self._workspace.directory(_OBJECT_DIRECTORY) as directory:
                source = os.fdopen(_regular_file(directory, ref["sha256"]), "rb")
        except FileNotFoundError as error:
            raise ResearchError("artifact_missing", "Artifact has not been stored", {"path": ref["path"]}) from error
        except OSError as error:
            raise _filesystem_error(error) from error
        with source:
            yield source

    def verify(self, reference):
        """Verify an existing object with bounded reads and no retained body."""
        with self._open_source(reference) as source, _artifact_operation():
            _copy_stream(source, expected=reference)
            self._record_verified(reference)

    def _record_verified(self, reference):
        pass

    @contextmanager
    def open_verified(self, reference):
        """Yield a private FrozenFile, verified before the caller can read it."""
        with self._open_source(reference) as source, freeze_file(source, reference) as frozen:
            self._record_verified(reference)
            yield frozen

    @contextmanager
    def materialize_verified(self, reference, directory):
        """Yield a verified private subprocess input path and remove it on exit."""
        from .workspace import checked_parent
        validate_reference(reference)
        destination = _Workspace(directory).root
        temporary = ".artifact-" + uuid.uuid4().hex
        with self.open_verified(reference) as frozen, checked_parent(destination, temporary) as (parent, name):
            with _artifact_operation():
                os.mkdir(name, mode=0o700, dir_fd=parent)
            try:
                with _Workspace(destination).directory(name) as private:
                    filename = reference["sha256"]
                    try:
                        with _artifact_operation():
                            descriptor = os.open(filename, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                                 0o600, dir_fd=private)
                            with os.fdopen(descriptor, "w+b") as target:
                                _copy_stream(frozen.stream, target, reference)
                                target.flush()
                                target.seek(0)
                                _copy_stream(target, expected=reference)
                                os.fchmod(target.fileno(), 0o444)
                                os.fsync(target.fileno())
                        yield destination / name / filename
                    finally:
                        with _artifact_operation():
                            try:
                                os.unlink(filename, dir_fd=private)
                            except FileNotFoundError:
                                pass
            finally:
                with _artifact_operation():
                    os.rmdir(name, dir_fd=parent)


class _StagedArtifacts(ArtifactStore):
    """Check publication paths and retain prepared bytes only in this operation."""

    def __init__(self, root):
        super().__init__(root)
        self._staged = {}
        self._observed = set()

    def _put(self, data, reference, relative):
        with _artifact_operation():
            try:
                with self._workspace.directory(relative) as directory:
                    _verify_object(directory, reference, retain=False)
            except FileNotFoundError:
                pass
        self._staged[reference["path"]] = data
        self._observed.add(reference["sha256"])
        return reference

    def _publish_stream(self, source, media_type, expected):
        _media_type(media_type)
        if expected is not None:
            validate_reference(expected)
        raise _CheckEffectRequired()

    def read(self, ref):
        validate_reference(ref)
        if ref["path"] in self._staged:
            data = _verify_content(self._staged[ref["path"]], ref)
        else:
            data = super().read(ref)
        self._observed.add(ref["sha256"])
        return data

    def verify_sealed(self, ref):
        validate_reference(ref, sealed=True)
        if ref["path"] in self._staged:
            _verify_content(self._staged[ref["path"]], ref)
        else:
            super().verify_sealed(ref)
        self._observed.add(ref["sha256"])

    def read_digests(self):
        return sorted(self._observed)

    @contextmanager
    def _open_source(self, ref):
        validate_reference(ref)
        if ref["path"] in self._staged:
            with io.BytesIO(self._staged[ref["path"]]) as source:
                yield source
        else:
            with super()._open_source(ref) as source:
                yield source

    def _record_verified(self, reference):
        self._observed.add(reference["sha256"])

    def require_external_effect(self):
        raise _CheckEffectRequired()

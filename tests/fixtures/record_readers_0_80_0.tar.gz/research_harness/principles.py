"""Authoritative study configuration and explicit constitution adoption.

configuration/research contains {profile, target, constitution,
preparation_policy}. Policy bytes are archived in constitution/{sha256};
research_objective/{id} fixes the full objective independently of branches;
objective_lineage/{id} records a widening admitted by a round, or a change the
user authorized with a pinned context file (relation "user_authorized"), with
the predecessor objective id, so the earlier objective stays retained.
The preparation policy decides which population members owe structured reading.
A caller that names none gets the profile's default, lineage-v1 for research and
sampled-v1 for verification; a configuration without the field is exhaustive-v1.
A policy adoption or change does not relabel old decisions: their bound
dependencies require new current assessments.
"""

import hashlib
import re
from pathlib import Path, PurePosixPath

from .artifacts import ArtifactStore
from .errors import ResearchError
from .evaluation import Evaluation
from .evidence import digest
from .graph import main_captures, obligation, validate_target
from .operations import fields, immutable_record, normalized_text, prepared_mutation, profile_name, text
from .source_links import captured_source, exact_work


CONSTITUTION_PATH = Path(__file__).resolve().parent.parent / "RESEARCH_CONSTITUTION.md"
PREVIOUS_CONSTITUTION = {"version": "6", "sha256": "9017d65280d1362e82a3e7fd1a0ce27393251901c96bc25e685ccaf711f53ee3"}
POLICIES = ("exhaustive-v1", "screened-v1", "lineage-v1", "sampled-v1")
LEGACY_POLICY = "exhaustive-v1"
POLICY_PROFILES = {"lineage-v1": "research", "sampled-v1": "verification"}
DEFAULT_POLICIES = {"research": "lineage-v1", "verification": "sampled-v1"}


def default_policy(profile):
    """The policy a new workspace of this profile records when the caller names none."""
    return DEFAULT_POLICIES[profile_name(profile)]


def preparation_policy(records):
    """The study's recorded preparation policy; configurations from earlier releases are exhaustive."""
    config = records.get("configuration", {}).get("research") or {}
    return (config.get("preparation_policy") or {}).get("id", LEGACY_POLICY)


def _policy(value, profile):
    if value not in POLICIES:
        raise ResearchError("invalid_input", "Preparation policy must be one of: " + ", ".join(POLICIES))
    required = POLICY_PROFILES.get(value)
    if required is not None and required != profile:
        raise ResearchError("policy_inapplicable", "The " + value + " policy belongs to the " + required + " profile",
                            {"policy": value, "profile": profile})
    return {"id": value}


def _constitution():
    try:
        data = CONSTITUTION_PATH.read_bytes()
        versions = re.findall(r"^Version: ([^\r\n]+)$", data.decode("utf-8"), re.MULTILINE)
        if len(versions) != 1 or not versions[0].strip():
            raise ValueError("The policy requires one version declaration")
    except (OSError, UnicodeError, ValueError) as error:
        raise ResearchError("constitution_unavailable", "Read the distributed versioned research constitution before proceeding") from error
    return {"path": "RESEARCH_CONSTITUTION.md", "version": versions[0],
            "sha256": hashlib.sha256(data).hexdigest()}, data


def constitution_contract():
    """Return the distributed policy's stable relative path, version and SHA-256."""
    return _constitution()[0]


def _validate_objective(target):
    fields(target, ("kind", "id", "statement"), ("title", "category"), code="invalid_target")
    if target["kind"] != "objective":
        raise ResearchError("invalid_target", "A research target must identify the complete objective")
    for key in ("id", "statement"):
        text(target[key], "Objective " + key, code="invalid_target")
    for key in ("title", "category"):
        if key in target:
            text(target[key], "Objective " + key, code="invalid_target")


def _validate_target(records, artifacts, profile, target):
    if profile == "research":
        if target is not None:
            _validate_objective(target)
        return
    fields(target, ("kind", "id", "source_id", "sha256"), code="invalid_target")
    work = exact_work(records, target["id"])
    if work["id"] != target["id"]:
        raise ResearchError("invalid_target", "Use the canonical exact work ID")
    validate_target(records, target, [work["id"]])
    if target["source_id"] is not None:
        captured_source(records, artifacts, target["source_id"])
        if not main_captures(records, work, target):
            raise ResearchError("invalid_target", "The verification pin must name the original main document, not a supplement")


def _archive_policy(records, artifacts, contract, data):
    return immutable_record(records, "constitution", contract["sha256"],
                            dict(contract, artifact=artifacts.put(data, "text/markdown; charset=utf-8")))


def prepare_initialization(records, artifacts, value):
    """Prepare configuration for an atomic workspace initialization or adoption."""
    fields(value, ("profile", "target"), ("preparation_policy",))
    if records.get("configuration", {}).get("research") is not None:
        raise ResearchError("configuration_exists", "Use explicit target or constitution operations for the existing study")
    profile_name(value["profile"])
    _validate_target(records, artifacts, value["profile"], value["target"])
    contract, data = _constitution()
    config = {"profile": value["profile"], "target": value["target"], "constitution": contract,
              "preparation_policy": _policy(value.get("preparation_policy", default_policy(value["profile"])), value["profile"])}
    changes = [_archive_policy(records, artifacts, contract, data), ("configuration", "research", config)]
    if value["profile"] == "research" and value["target"] is not None:
        changes.append(immutable_record(records, "research_objective", value["target"]["id"], value["target"]))
    return changes, config


def initialize_research(store, payload, *, expected_revision, request_id):
    """Initialize once with {profile, target}; null research targets are pending."""
    artifacts = store.build_artifact_store()

    def prepare(records, value):
        return prepare_initialization(records, artifacts, value)

    return prepared_mutation(store, "research.initialize", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def _configuration(records):
    config = records.get("configuration", {}).get("research")
    if config is None:
        raise ResearchError("configuration_missing", "Initialize the study profile and constitution first")
    return config


def set_target(store, payload, *, expected_revision, request_id):
    """Set {target, reason}, with {authorization} for a changed research objective.

A fixed complete research objective changes only with `authorization`: the id of
a pinned local artifact under context/ that holds the user's explicit
instruction and authorized no earlier change. The harness checks the pin and its
bytes, not who wrote them. The earlier objective stays retained as the
predecessor of the new one. Verification repinning is explicit and leaves
mismatching literature scope pending until set_roots selects the same target.
It preserves earlier events.
"""
    artifacts = store.build_artifact_store()

    def prepare(records, value):
        fields(value, ("target", "reason"), ("authorization", "decision_id", "source_impact"))
        text(value["reason"], "Target decision reason")
        config = _configuration(records)
        current = config["target"]
        changed = config["profile"] == "research" and current is not None and current != value["target"]
        if changed and "authorization" not in value:
            raise ResearchError("objective_locked", "Keep the complete original objective; record special cases as separate branches")
        if not changed and "authorization" in value:
            raise ResearchError("invalid_target", "Authorization applies only to a change of the fixed research objective")
        _validate_target(records, artifacts, config["profile"], value["target"])
        updated = dict(config, target=value["target"])
        changes = [("configuration", "research", updated)] + (_narrowing(records, artifacts, current, value) if changed else [])
        if config["profile"] == "research" and value["target"] is not None:
            from .strategy import managed_research
            if managed_research(records) and current != value["target"]:
                from .research_decisions import prepare_objective_commitment
                commitment_changes, _ = prepare_objective_commitment(
                    records, artifacts, value["target"],
                    decision_id=value.get("decision_id"),
                    source_impact=value.get("source_impact"), revision=expected_revision + 1)
                changes.extend(commitment_changes)
            changes.append(immutable_record(records, "research_objective", value["target"]["id"], value["target"]))
        return changes, updated

    return prepared_mutation(store, "research.target", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def _narrowing(records, artifacts, current, value):
    """The lineage record of a user-authorized change of the fixed research objective."""
    target = value["target"]
    if (target is None or target["id"] in records.get("research_objective", {})
            or normalized_text(target["statement"]) == normalized_text(current["statement"])):
        raise ResearchError("objective_locked", "A changed objective needs a new identity and a changed statement")
    pinned = records.get("local_artifact", {}).get(value["authorization"]) if isinstance(value["authorization"], str) else None
    if pinned is None or PurePosixPath(pinned["path"]).parts[0] != "context":
        raise ResearchError("invalid_target", "Name the pinned context/ file that holds the user's instruction")
    instruction = Evaluation(records, artifacts).read(pinned["artifact"])
    if not instruction.strip():
        raise ResearchError("invalid_target", "The user's instruction file is empty")
    used = {r["authorization"]["artifact"]["sha256"] for r in records.get("objective_lineage", {}).values() if r.get("relation") == "user_authorized"}
    if pinned["artifact"]["sha256"] in used:
        raise ResearchError("objective_locked", "Each objective change needs its own instruction from the user")
    authorization = {"id": pinned["id"], "path": pinned["path"], "artifact": pinned["artifact"],
                     "text": instruction.decode("utf-8", "replace")}
    record = {"id": target["id"], "predecessor": current["id"], "relation": "user_authorized", "reason": value["reason"],
              "authorization": authorization, "round_id": None}
    return [immutable_record(records, "objective_lineage", target["id"], record)]


def objective_changes(records):
    """The user-authorized changes in the current objective's lineage, oldest first, for reviewers."""
    objectives = records.get("research_objective", {})
    current = records.get("configuration", {}).get("research", {}).get("target")
    changes = []
    while current is not None:
        link = records.get("objective_lineage", {}).get(current["id"])
        if link is None:
            break
        if link.get("relation") == "user_authorized":
            changes.append({"from": objectives[link["predecessor"]], "to": current, "reason": link["reason"],
                            "authorization": link["authorization"]})
        current = objectives.get(link["predecessor"])
    return changes[::-1]


def widen_objective(records, target, lineage, round_id):
    """Changes that widen the research objective through an admitted round; the old objective stays retained.

    `target` is the wider objective, `lineage` is {previous_id, containment}
    naming the current objective and why the wider one contains it. The
    configuration target becomes `target`; research_objective/{target id} and
    objective_lineage/{target id} record the widening. Containment is the
    author's recorded assertion, judged by the round reviewer: the statement
    text gives no mechanical containment check.
    """
    config = _configuration(records)
    current = config["target"]
    fields(lineage, ("previous_id", "containment"), code="invalid_target")
    text(lineage["containment"], "Objective containment", code="invalid_target")
    _validate_objective(target)
    if config["profile"] != "research" or current is None or lineage["previous_id"] != current["id"]:
        raise ResearchError("objective_locked", "Widen the current complete objective through its recorded predecessor")
    if normalized_text(target["statement"]) == normalized_text(current["statement"]) or target["id"] in records.get("research_objective", {}):
        raise ResearchError("objective_locked", "A widened objective needs a new identity and a wider statement")
    record = {"id": target["id"], "predecessor": current["id"], "containment": lineage["containment"], "round_id": round_id}
    return [("configuration", "research", dict(config, target=target)),
            immutable_record(records, "research_objective", target["id"], target),
            immutable_record(records, "objective_lineage", target["id"], record)]


def revalidate_constitution(store, payload, *, expected_revision, request_id):
    """Adopt current policy with {previous_sha256, reason}, without migrating decisions.

Every active synthesis/development decision must separately be reassessed under
the current contract. Re-recording an assessment preserves its predecessor.
"""
    artifacts = store.build_artifact_store()

    def prepare(records, value):
        fields(value, ("previous_sha256", "reason"))
        text(value["reason"], "Current policy assessment")
        config = _configuration(records)
        if value["previous_sha256"] != config["constitution"]["sha256"]:
            raise ResearchError("constitution_conflict", "Revalidate against the policy currently bound to this study")
        contract, data = _constitution()
        updated = dict(config, constitution=contract)
        return [_archive_policy(records, artifacts, contract, data), ("configuration", "research", updated)], dict(
            updated, decisions_revalidated=False)

    return prepared_mutation(store, "research.constitution", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def change_policy(store, payload, *, expected_revision, request_id):
    """Change the preparation policy with {previous, policy, reason}; dependent assessments become stale."""
    def prepare(records, value):
        fields(value, ("previous", "policy", "reason"))
        text(value["reason"], "Policy change reason")
        config = _configuration(records)
        if value["previous"] != preparation_policy(records):
            raise ResearchError("policy_conflict", "Name the policy currently recorded for this study",
                                {"current": preparation_policy(records)})
        updated = dict(config, preparation_policy=_policy(value["policy"], config["profile"]))
        return [("configuration", "research", updated)], dict(updated, decisions_revalidated=False)

    return prepared_mutation(store, "research.policy", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def configuration_state(records, artifacts, profile):
    """Snapshot-level configuration check shared by downstream managed gates."""
    profile_name(profile)
    evaluation = Evaluation.of(records, artifacts)
    return evaluation.once(("configuration", profile), lambda: _configuration_state(evaluation, profile))


def _configuration_state(evaluation, profile):
    records, artifacts = evaluation.records, evaluation
    contract = constitution_contract()
    config = records.get("configuration", {}).get("research")
    archived = None
    if config is not None:
        adopted = config["constitution"]
        archived = records.get("constitution", {}).get(adopted["sha256"])
        if (adopted == dict(PREVIOUS_CONSTITUTION, path="RESEARCH_CONSTITUTION.md")
                and archived is not None and all(archived.get(key) == value for key, value in adopted.items())
                and archived["artifact"]["sha256"] == adopted["sha256"]):
            # Native audits compare complete frozen reports, including this
            # digest and the reported contract. Keep the adopted v6 semantics.
            contract = dict(contract, **adopted)
    obligations = []
    if config is None:
        obligations.append(obligation("configuration_missing", "Initialize the study profile, target and constitution."))
    elif config["profile"] != profile:
        obligations.append(obligation("profile_mismatch", "Use the study's configured research or verification profile."))
    else:
        if config["constitution"] != contract:
            obligations.append(obligation("constitution_revalidation_required", "Explicitly review the current policy and reassess dependent decisions.",
                                          previous=config["constitution"], current=contract))
        if archived is None:
            obligations.append(obligation("constitution_archive_missing", "Restore the archived policy that the study actually adopted."))
        else:
            artifacts.read(archived["artifact"])
        target = config["target"]
        _validate_target(records, artifacts, profile, target)
        if profile == "research":
            if target is None:
                obligations.append(obligation("objective_missing", "Fix the complete research objective before judging readiness."))
            elif records.get("research_objective", {}).get(target["id"]) != target:
                obligations.append(obligation("objective_mismatch", "The configuration must retain the original complete objective."))
        else:
            if target["source_id"] is None:
                obligations.append(obligation("target_source_pin_missing", "Acquire and pin the exact original main target body."))
            scope = records.get("literature_scope", {}).get(profile)
            if scope is None or scope.get("target") != target:
                obligations.append(obligation("target_mismatch", "Set the literature roots and target to the configured exact source pin."))
    return {"ready": not obligations, "digest": digest({"configuration": config, "current_constitution": contract}),
            "obligations": obligations, "counts": {"obligations": len(obligations)},
            "preparation_policy": preparation_policy(records),
            "profile": profile, "target": config["target"] if config and config["profile"] == profile else None,
            "constitution": contract, "configuration": config if config and config["profile"] == profile else None,
            "next": obligations[0] if obligations else None,
            "limits": "A current policy and target do not establish scientific readiness or revalidate historical decisions."}


def configuration_report(store, profile):
    records = store.snapshot()["records"]
    return configuration_state(records, Evaluation(records, store.build_artifact_store()), profile)

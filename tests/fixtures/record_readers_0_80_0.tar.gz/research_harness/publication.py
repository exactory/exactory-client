"""Exact manuscript snapshots, unchanged rubric reviews and publication receipts."""

import hashlib
import json
from pathlib import Path

from .artifacts import ArtifactStore
from .claim_dependencies import accept_claim_dependencies, project_claim_dependencies, uses_claim_dependencies
from .citations import account_citations, find_citing_entry, read_bibliography
from .execution_evidence import author_readiness_state
from .errors import ResearchError
from .evaluation import Evaluation
from .evidence import digest
from .file_streams import freeze_file
from .graph import find_active_requirements, obligation
from .operations import fields, immutable_record, prepared_mutation, strings, text
from .storage import _canonical, _check_stored_bounds
from .workspace import open_file, read_file, strict_json


FILE_TYPES = {"pdf": "application/pdf", "abstract": "text/plain", "bibliography": "text/plain",
              "claims": "application/json", "sources": "application/octet-stream"}
# The rubric's numeric scores and their unchanged maximum (every scale starts at 1).
SCORE_SCALES = (("soundness", 4), ("presentation", 4), ("contribution", 4), ("overall", 10))
# The axes whose score below its maximum names the changes that would reach it (design 7.2).
CHANGE_AXES = ("soundness", "presentation", "contribution")
_BUNDLE_INPUTS = ("review_inputs", "execution_observations")


def read_bundle_input(bundle, artifacts, name):
    """Resolve a pinned input object or retain the original inline value of a historical bundle."""
    if name + "_artifact" not in bundle:
        return bundle.get(name)
    if artifacts is None:
        raise ResearchError("invalid_input", "Reading a pinned input artifact requires its artifact store")
    return strict_json(artifacts.read(bundle[name + "_artifact"]))


def _ready(records, artifacts, *, check_decision=True):
    if check_decision:
        from .decision_integration import require_decision
        require_decision(records, artifacts, "write")
    from .publication_scope import assess_manuscript_readiness, has_publication_scope
    if has_publication_scope(records):
        report = assess_manuscript_readiness(records, artifacts)
        if not report["manuscript_ready"]:
            raise ResearchError("manuscript_readiness_required", "Current independent scoped manuscript readiness is required",
                                {"obligations": report["manuscript_obligations"]})
        return report
    report = author_readiness_state(records, artifacts)
    if not report["ready"]:
        raise ResearchError("readiness_required", "Current whole-candidate readiness is required for the manuscript",
                            {"obligations": report["obligations"]})
    return report


def rebuild_pinned_readiness(records, artifacts, bundle):
    evaluation = Evaluation.of(records, artifacts)
    records = evaluation.records
    key = ("pinned_readiness", bundle["id"], bundle.get("prepared_revision"), digest(bundle))
    return evaluation.compute_once_in_root(key, lambda: _rebuild_pinned_readiness(records, evaluation, bundle))


def _rebuild_pinned_readiness(records, artifacts, bundle):
    """Recover pin-time science exclusively from its recorded input snapshot."""
    from .development import _Context
    from .publication_scope import assess_manuscript_readiness
    context = _Context(records, artifacts)
    identifier = bundle["id"]
    evaluation = context.read_snapshot(bundle.get("prepared_revision"), identifier)
    snapshot = evaluation.records
    inputs = read_bundle_input(bundle, artifacts, "review_inputs")
    context.require_recorded_fields(inputs, ("candidate", "synthesis", "branches"), identifier)
    if not inputs or not inputs.get("synthesis") or not inputs.get("candidate"):
        context.require_reassessment(identifier, "recorded manuscript readiness inputs")
    context.require_recorded_fields(inputs["synthesis"], ("configuration", "foundation"), identifier)
    context.require_recorded_fields(inputs["synthesis"]["configuration"], ("target", "constitution"), identifier)
    candidate = inputs["candidate"]
    historical = _Context(snapshot, evaluation, project_claims=True)
    original = historical.rebuild_candidate(candidate, identifier)
    restore = {"dependencies": {"preparation": original["preparation_digest"], "constitution": original["constitution"]},
               "record_id": identifier, "synthesis": inputs["synthesis"]}
    body = {key: value for key, value in original.items() if key != "digest"}
    restore["project_claims"] = digest(body) != original["digest"]
    projected, _ = historical.build_candidate()
    restore["project_readings"] = original["source_records_digest"] == projected["source_records_digest"]
    evaluate = assess_manuscript_readiness if bundle.get("publication_scope") else author_readiness_state
    original_report = evaluate(snapshot, evaluation, restore_inputs=restore)
    if original_report["review_inputs"] != inputs:
        context.require_reassessment(identifier, "matching recorded readiness inputs and snapshot")
    return original_report, evaluate(snapshot, evaluation, restore_inputs=dict(restore, project_claims=True, project_readings=True))


def _scientific_readiness(report, records=None):
    """Bind unchanged science independently of a later support assessor's identity.

    The current support verdict is always checked by _ready before this binding.
    The full report digest and original review remain retained as pin-time history.
    """
    dependencies = {key: value for key, value in report.items() if key != "review"}
    return {"kind": "scientific-inputs-v1", "digest": digest(project_claim_dependencies(
        dependencies, managed=uses_claim_dependencies(records or {}), kind="readiness"))}


def _claim_markers(claim):
    """A claim carries at most one continuity marker: `revised: {previous, reason}` or `superseded: {reason}`."""
    if "revised" in claim and "superseded" in claim:
        raise ResearchError("publication_claims_missing", "A claim is revised or superseded, not both")
    if "revised" in claim:
        fields(claim["revised"], ("previous", "reason"), code="publication_claims_missing")
        text(claim["revised"]["previous"], "Revised claim previous text", code="publication_claims_missing")
        text(claim["revised"]["reason"], "Revision reason", code="publication_claims_missing")
    if "superseded" in claim:
        fields(claim["superseded"], ("reason",), code="publication_claims_missing")
        text(claim["superseded"]["reason"], "Supersession reason", code="publication_claims_missing")


def validate_claim_evidence(claim_evidence, candidate):
    """Require every ledger reference to match current candidate evidence by digest."""
    if not isinstance(claim_evidence, list):
        raise ResearchError("publication_claims_missing", "Map each claim to current candidate evidence")
    allowed = {digest(reference) for reference in candidate["evidence"]}
    mismatches = []
    for link in claim_evidence:
        fields(link, ("claim_id", "evidence"))
        text(link["claim_id"], "Claim ID")
        if not isinstance(link["evidence"], list) or not link["evidence"]:
            raise ResearchError("publication_evidence_mismatch",
                                "Claim " + link["claim_id"] + " needs a nonempty evidence array "
                                "of current candidate references")
        mismatches.extend({"claim_id": link["claim_id"], "evidence": reference}
                          for reference in link["evidence"] if digest(reference) not in allowed)
    if mismatches:
        first = mismatches[0]
        reference = json.dumps(first["evidence"], ensure_ascii=False, sort_keys=True)
        raise ResearchError("publication_evidence_mismatch",
                            "Claim " + first["claim_id"] + " links evidence outside the current candidate: "
                            + reference, {"mismatches": mismatches})


def check_claims(store, claim_evidence):
    snapshot = store.snapshot()
    records = snapshot["records"]
    artifacts = Evaluation(records, store.build_artifact_store())
    from .publication_scope import assess_manuscript_readiness, has_publication_scope
    report = (assess_manuscript_readiness(records, artifacts) if has_publication_scope(records)
              else author_readiness_state(records, artifacts))
    if report["candidate"] is None:
        raise ResearchError("candidate_checkpoint_missing",
                            "Select a current assessed candidate to check claim evidence",
                            {"obligations": report["obligations"]})
    validate_claim_evidence(claim_evidence, report["candidate"])
    return {"revision": snapshot["revision"], "mismatches": []}


def prepare_publication(store, payload, *, expected_revision, request_id):
    """Pin {id, files:{pdf,abstract,bibliography,claims,sources}, claim_evidence, citation_accounting?}.

    Every fully read or search-cited work is cited by the bibliography or accounted for
    (research_harness.citations); the bundle keeps the resulting accounting."""
    def prepare(records, value):
        artifacts = Evaluation(records, store.build_artifact_store())
        fields(value, ("id", "files", "claim_evidence"), ("citation_accounting",))
        text(value["id"], "Publication bundle ID")
        fields(value["files"], tuple(FILE_TYPES))
        # contribution imports this module through predictions, so it is imported here.
        from .contribution import find_bundle_owing_analysis
        owing = find_bundle_owing_analysis(records)
        if owing is not None:
            raise ResearchError("contribution_analysis_missing", "Record the contribution analysis of the measured bundle "
                                "before pinning the next one", {"bundle_id": owing["id"]})
        report = _ready(records, artifacts)
        saved = {}
        for kind, path in value["files"].items():
            if path is None and kind == "sources":
                saved[kind] = None
                continue
            data = read_file(store.root, path)
            if not data or kind == "pdf" and not data.startswith(b"%PDF-"):
                raise ResearchError("publication_artifact_invalid", "Publication files must contain their declared content")
            if kind == "abstract":
                try:
                    nonempty = bool(data.decode("utf-8").strip())
                except UnicodeError as error:
                    raise ResearchError("publication_artifact_invalid", "The abstract must be UTF-8 text") from error
                if not nonempty:
                    raise ResearchError("publication_artifact_invalid", "The abstract must contain nonblank text")
            saved[kind] = {"path": path, "artifact": artifacts.put(data, FILE_TYPES[kind])}
        claims = strict_json(artifacts.read(saved["claims"]["artifact"]))
        if not isinstance(claims, list) or not claims:
            raise ResearchError("publication_claims_missing", "Provide the actual manuscript claim registry")
        claim_ids = []
        for claim in claims:
            if not isinstance(claim, dict):
                raise ResearchError("publication_claims_missing", "Claim records must have stable IDs and claim text")
            claim_ids.append(text(claim.get("id"), "Claim ID"))
            text(claim.get("claim"), "Claim text")
            _claim_markers(claim)
        if len(set(claim_ids)) != len(claim_ids):
            raise ResearchError("publication_claims_missing", "Claim IDs must be unique")
        if not isinstance(value["claim_evidence"], list):
            raise ResearchError("publication_claims_missing", "Map each claim to current candidate evidence")
        seen = set()
        for link in value["claim_evidence"]:
            fields(link, ("claim_id", "evidence"))
            if link["claim_id"] not in claim_ids or link["claim_id"] in seen:
                raise ResearchError("publication_claims_missing", "Map each manuscript claim exactly once")
            seen.add(link["claim_id"])
        if seen != set(claim_ids):
            raise ResearchError("publication_claims_missing", "Map every manuscript claim to evidence")
        validate_claim_evidence(value["claim_evidence"], report["candidate"])
        scoped = report.get("contract")
        if scoped is not None:
            from .publication_scope import validate_manuscript_claims, collect_scientific_authors
            validate_manuscript_claims(scoped, claims, value["claim_evidence"])
            candidate = dict(report["candidate"], authors=collect_scientific_authors(records, scoped))
            readiness_review = report["review"]
        else:
            candidate = report["candidate"]
            readiness_review = records["readiness_review"][records["development_selection"]["review"]["review_id"]]
        accounting = account_citations(records, artifacts.read(saved["bibliography"]["artifact"]),
                                       value.get("citation_accounting"))
        # Keep the original bundle's cross-interpreter bounds when moving its inputs to immutable objects.
        _check_stored_bounds({key: report[key] for key in _BUNDLE_INPUTS})
        inputs = {key + "_artifact": artifacts.put(_canonical(report[key]).encode("utf-8"), "application/json")
                  for key in _BUNDLE_INPUTS}
        bundle = dict(value, files=saved, citation_accounting=accounting, candidate=candidate,
                      readiness_digest=digest(report), readiness_review=readiness_review,
                      readiness_binding=_scientific_readiness(report, records),
                      prepared_revision=expected_revision, mechanical_only=True, **inputs)
        if scoped is not None:
            bundle["publication_scope"] = {"mode": scoped["payload"]["policy"], "contract_id": scoped["id"],
                                           "scientific_target_digest": scoped["scientific_target_digest"],
                                           "objective_complete": False, "projection": scoped["public_projection"]}
        bundle["digest"] = digest(bundle)
        return [immutable_record(records, "publication_bundle", value["id"], bundle),
                ("publication_selection", "bundle", {"id": value["id"]})], bundle
    return prepared_mutation(store, "publication.prepare", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def find_selected_bundle(records):
    """The selected publication bundle, current or not, or None before the first pin."""
    selected = records.get("publication_selection", {}).get("bundle")
    return records["publication_bundle"][selected["id"]] if selected else None


def _matches_file(artifacts, path, reference):
    store = artifacts.store if isinstance(artifacts, Evaluation) else artifacts
    with open_file(artifacts.root, path) as source, freeze_file(source) as frozen:
        store.verify(reference)
        return frozen.size == reference["size"] and frozen.sha256 == reference["sha256"]


def _bundle(records, artifacts):
    bundle = find_selected_bundle(records)
    if bundle is None:
        raise ResearchError("publication_bundle_missing", "Prepare the exact PDF, abstract, bibliography and claims")
    report = _ready(records, artifacts, check_decision=False)
    binding = bundle.get("readiness_binding")
    managed = uses_claim_dependencies(records)
    if binding is not None:
        unchanged = _scientific_readiness(report, records) == binding
    else:
        unchanged = digest(report) == bundle["readiness_digest"]
    if not unchanged and managed:
        original, projected = rebuild_pinned_readiness(records, artifacts, bundle)
        raw = {key: value for key, value in original.items() if key != "review"} if binding is not None else original
        recorded = binding["digest"] if binding is not None else bundle["readiness_digest"]
        claim = project_claim_dependencies({key: value for key, value in projected.items() if key != "review"},
                                           managed=True, kind="readiness")
        current = _scientific_readiness(report, records)["digest"]
        unchanged = accept_claim_dependencies(recorded, current, managed=True, recorded_inputs=raw,
                                               recorded_claim=claim, kind="readiness")
    if not unchanged and not managed and binding is None and isinstance(bundle.get("readiness_review"), dict):
        original_review = bundle["readiness_review"]
        if not bundle.get("publication_scope"):
            original_review = original_review.get("assessment")
        if original_review is not None:
            unchanged = digest(dict(report, review=original_review)) == bundle["readiness_digest"]
    if not unchanged:
        raise ResearchError("publication_readiness_stale", "Prepare and review the manuscript against current whole-candidate readiness")
    for key in _BUNDLE_INPUTS:
        if key + "_artifact" in bundle:
            artifacts.read(bundle[key + "_artifact"])
    for item in bundle["files"].values():
        if item is not None and not _matches_file(artifacts, item["path"], item["artifact"]):
            raise ResearchError("publication_artifact_changed", "The manuscript or its supporting files changed after preparation",
                                {"path": item["path"]})
    return bundle


def _assessor_key(assessor_id):
    return " ".join(assessor_id.casefold().split())


def latest_reviews(records, bundle_digest):
    """The latest manuscript review per assessor on the bundle, keyed by assessor.

    Recording refuses a second review per assessor per exact bundle; for reviews recorded
    before that rule the assessor's latest stands. The gate and the measurement summary
    both read this selection.
    """
    latest = {}
    for saved in records.get("manuscript_review", {}).values():
        if saved["bundle_digest"] == bundle_digest:
            key = _assessor_key(saved["assessor"]["id"])
            if key not in latest or saved["reviewed_revision"] > latest[key]["reviewed_revision"]:
                latest[key] = saved
    return latest


def validate_assessor(artifacts, assessor, authors):
    """An identified human or agent assessor with pinned provenance who is not an author."""
    fields(assessor, ("id", "kind", "provenance", "relationship", "independence_basis"),
           ("author_memory_notes_present",))
    if "author_memory_notes_present" in assessor and type(assessor["author_memory_notes_present"]) is not bool:
        raise ResearchError("invalid_input", "Author memory notes present must be a boolean")
    for key in ("id", "relationship", "independence_basis"):
        text(assessor[key], "Independent assessor " + key)
    if assessor["kind"] not in ("human", "agent"):
        raise ResearchError("review_not_independent", "Supply an identified independent reviewer")
    artifacts.read(assessor["provenance"])
    if _assessor_key(assessor["id"]) in {_assessor_key(a) for a in authors}:
        raise ResearchError("review_not_independent", "An author cannot provide an independent assessment")
    return assessor


def _review(records, artifacts, value, bundle):
    fields(value, ("id", "bundle_digest", "assessor", "review", "blind"), ("assignment_id",))
    text(value["id"], "Manuscript review ID")
    if value["bundle_digest"] != bundle["digest"]:
        raise ResearchError("publication_review_stale", "Review the exact current manuscript bundle")
    if value["blind"] is not True:
        raise ResearchError("review_not_independent", "Supply an identified independent blind reviewer")
    validate_assessor(artifacts, value["assessor"], bundle["candidate"]["authors"])
    core = strict_json(artifacts.read(value["review"]))
    # Optional here because the publication gate re-reads reviews recorded before 0.42.0;
    # record_manuscript_review requires it for every new review.
    fields(core, ("summary", "strengths", "weaknesses", "soundness", "presentation", "contribution", "overall", "decision"),
           ("changes_for_maximum",))
    text(core["summary"], "Review summary")
    for key in ("strengths", "weaknesses"):
        strings(core[key], key, nonempty=True)
    for key, maximum in SCORE_SCALES:
        if type(core[key]) not in (int, float) or not 1 <= core[key] <= maximum:
            raise ResearchError("invalid_review", "Review scores must use the unchanged rubric scales")
    if core["decision"] not in ("accept", "reject"):
        raise ResearchError("invalid_review", "The rubric decision must be accept or reject")
    if "changes_for_maximum" in core:
        _check_changes_for_maximum(core)
    return core


def require_manuscript_assignment(records, artifacts, value, bundle, *, core=None, prediction=None):
    """Bind independence and content to the actual reviewed manuscript input."""
    from .review_protocol import assignment_state
    identifier = value.get("assignment_id")
    if identifier is None:
        raise ResearchError("review_assignment_missing", "Use the observed independent manuscript assignment; historical assertions remain unverified")
    state = assignment_state(records, artifacts, identifier)
    if not state["ready"]:
        raise ResearchError("review_context_unverified", "The current reviewer context does not establish independence", {"obligations": state["obligations"]})
    assignment = records["review_assignment"][identifier]
    packet = strict_json(artifacts.read(assignment["packet"]))
    if (state["role"] != "manuscript" or packet.get("paper", {}).get("bundle_digest") != bundle["digest"]
            or assignment.get("context", {}).get("bundle") != bundle
            or _assessor_key(state["reviewer_id"]) != _assessor_key(value["assessor"]["id"])):
        raise ResearchError("publication_review_stale", "The observed assessor must review this exact manuscript bundle")
    observed = state["output"]
    if core is not None and observed.get("review") != core:
        raise ResearchError("review_output_mismatch", "Record the actual reviewer's unchanged scientific review")
    if prediction is not None and (observed.get("prediction") != prediction or observed.get("reasons") != value["reasons"]):
        raise ResearchError("review_output_mismatch", "Record the actual reviewer's unchanged prediction and reasons")
    return state


def _check_changes_for_maximum(core):
    """Each axis below its maximum lists the changes that reach it; an axis at its maximum lists none."""
    changes = core["changes_for_maximum"]
    fields(changes, CHANGE_AXES, code="invalid_review")
    maxima = dict(SCORE_SCALES)
    for axis in CHANGE_AXES:
        strings(changes[axis], "Changes for the maximum " + axis, code="invalid_review")
        if bool(changes[axis]) != (core[axis] < maxima[axis]):
            raise ResearchError("invalid_review", "List the changes that bring each score below its maximum to the maximum, "
                                "and none for a score at the maximum", {"axis": axis})


def record_manuscript_review(store, payload, *, expected_revision, request_id):
    def prepare(records, value):
        artifacts = Evaluation(records, store.build_artifact_store())
        bundle = _bundle(records, artifacts)
        core = _review(records, artifacts, value, bundle)
        if "changes_for_maximum" not in core:
            raise ResearchError("invalid_review", "A review lists the changes that bring each score below its maximum to the maximum")
        key = _assessor_key(value["assessor"]["id"])
        for saved in records.get("manuscript_review", {}).values():
            if saved["bundle_digest"] == bundle["digest"] and _assessor_key(saved["assessor"]["id"]) == key:
                raise ResearchError("manuscript_review_duplicate", "This assessor already reviewed this exact bundle; a rejection stands until the manuscript changes",
                                    {"review_id": saved["id"]})
        require_manuscript_assignment(records, artifacts, value, bundle, core=core)
        record = dict(value, core=core, reviewed_revision=expected_revision, digest=digest(value))
        return [immutable_record(records, "manuscript_review", value["id"], record)], record
    return prepared_mutation(store, "publication.review", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def lineage_citation_obligations(records, artifacts, bundle):
    """Every lineage and nondeferred classic entry is cited in the pinned bibliography (lineage-v1).

    The bibliography is read for citation evidence, not validated: a manuscript may pin one
    in any encoding, and undecodable bytes become replacement characters rather than a gate
    that raises."""
    from .lineage import LINEAGE
    from .principles import preparation_policy
    if preparation_policy(records) != LINEAGE:
        return []
    bibliography = read_bibliography(artifacts.read(bundle["files"]["bibliography"]["artifact"]))
    found = []
    from .source_deferrals import assess_deferrals
    deferred = {d["version_id"] for d in assess_deferrals(records, artifacts) if d["status"] == "active"}
    for requirement in sorted(find_active_requirements(records).values(), key=lambda r: r["id"]):
        if requirement["profile"] != "research" or requirement["purpose"] not in ("lineage", "classic"):
            continue
        if requirement["purpose"] == "classic" and requirement["version_id"] in deferred:
            continue
        work = records["work"][requirement["version_id"]]
        if not find_citing_entry(bibliography, [work])[0]:
            found.append(obligation("lineage_citation_missing", "Cite this lineage or classic entry in the manuscript bibliography.",
                                    version_id=requirement["version_id"], title=work["title"]))
    return found


def publication_state(records, artifacts, action="publication"):
    artifacts = Evaluation.of(records, artifacts)
    bundle, reviews, obligations = None, [], []
    try:
        bundle = _bundle(records, artifacts)
        obligations.extend(lineage_citation_obligations(records, artifacts, bundle))
        cores = {}
        for saved in records.get("manuscript_review", {}).values():
            if saved["bundle_digest"] == bundle["digest"]:
                value = {k: saved[k] for k in ("id", "bundle_digest", "assessor", "review", "blind", "assignment_id") if k in saved}
                cores[saved["id"]] = _review(records, artifacts, value, bundle)
                if action != "manuscript":
                    try:
                        require_manuscript_assignment(records, artifacts, value, bundle, core=cores[saved["id"]])
                    except ResearchError as error:
                        obligations.append(obligation(error.code, error.message, review_id=saved["id"], **(error.details or {})))
        reviews = list(latest_reviews(records, bundle["digest"]).values())
        if action != "manuscript" and (len(reviews) < 2 or any(cores[saved["id"]]["decision"] != "accept" for saved in reviews)):
            obligations.append(obligation("manuscript_reviews_required", "Obtain two independent accepting reviews of this exact manuscript and resolve current rejections."))
        if action == "deposited":
            if not any(r.get("bundle_digest") == bundle["digest"] and r.get("doi") and r.get("environment") == "production"
                       for r in list_publication_receipts(records)):
                obligations.append(obligation("publication_receipt_required", "Publish this exact reviewed bundle and reconcile its concrete record DOI."))
        if action == "submitted":
            if not any(r.get("bundle_digest") == bundle["digest"] and r.get("matched") is True
                       for r in records.get("submission_receipt", {}).values()):
                obligations.append(obligation("submission_receipt_required", "Associate the current publication with the server's exact task target."))
    except ResearchError as error:
        obligations.append(obligation(error.code, error.message, **(error.details or {})))
    from .decision_integration import decision_report
    strategic = decision_report(records, artifacts, "write" if action == "manuscript" else "publication")
    obligations.extend(strategic["obligations"])
    return {"ready": not obligations, "obligations": obligations, "bundle": bundle, "reviews": reviews,
            "research_decision": strategic,
            "historical_publications": list_publication_receipts(records),
            "historical_submissions": list(records.get("submission_receipt", {}).values()),
            "digest": digest({"bundle": bundle["digest"] if bundle else None, "reviews": reviews, "obligations": obligations}),
            "mechanical_only": True}


def list_publication_receipts(records):
    """Every publication receipt: the receipts that deposits completed, then the read-back receipts
    that a read of the same deposition wrote for a receipt that an earlier version completed without
    a DOI (research_harness.zenodo)."""
    return [*records.get("publication_receipt", {}).values(), *records.get("publication_read_back", {}).values()]


def publication_report(store, action="publication"):
    snapshot = store.snapshot()
    evaluation = Evaluation(snapshot["records"], store.build_artifact_store())
    return dict(publication_state(snapshot["records"], evaluation, action), revision=snapshot["revision"])


def validate_upload(store, pdf, abstract, sources):
    snapshot = store.snapshot()
    artifacts = Evaluation(snapshot["records"], store.build_artifact_store(), retention_budget_bytes=0)
    report = publication_state(snapshot["records"], artifacts)
    if not report["ready"]:
        raise ResearchError("readiness_required", "Publication requires the exact manuscript and dual review gate", {"obligations": report["obligations"]})
    bundle = report["bundle"]
    for kind, supplied in (("pdf", pdf), ("abstract", abstract), ("sources", sources)):
        pinned = bundle["files"][kind]
        if (supplied is None) != (pinned is None):
            raise ResearchError("publication_artifact_mismatch", "Upload arguments must identify the reviewed bundle")
        if supplied is not None:
            selected = Path(supplied).absolute()
            # Normalize a caller's workspace alias, retaining each path component
            # inside it so checked reads still reject internal symlinks.
            ancestors = [parent for parent in selected.parents if parent.resolve() == store.root]
            if not ancestors:
                raise ResearchError("publication_artifact_mismatch", "Upload files must belong to the reviewed workspace")
            relative = selected.relative_to(ancestors[0]).as_posix()
            if not _matches_file(artifacts, relative, pinned["artifact"]):
                raise ResearchError("publication_artifact_mismatch", "The selected upload differs from the reviewed manuscript", {"kind": kind})
    return dict(report, revision=snapshot["revision"])

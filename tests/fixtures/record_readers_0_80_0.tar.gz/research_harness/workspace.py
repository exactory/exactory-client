"""Checked human inputs and disposable projections of authoritative records."""

from contextlib import contextmanager
import json
import os
from pathlib import Path
import stat

from .artifacts import _Workspace, _regular_file, _relative_parts, _filesystem_error
from .errors import ResearchError
from .storage import _canonical
from .native_writes import write_atomic


def strict_json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON field")
            result[key] = value
        return result
    try:
        value = json.loads(data, object_pairs_hook=unique)
        _canonical(value)
        return value
    except (ValueError, TypeError, UnicodeError, RecursionError) as error:
        raise ResearchError("invalid_json", "Expected finite JSON without duplicate fields") from error


def find_workspace(start=None, *, required=True):
    start = Path(start or Path.cwd()).absolute()
    if ".." in start.parts:
        # A parent segment follows the filesystem, as the shell does: a symlink before it leads to that link's
        # target, and the walk never visits the directory the segment passes through. The final component stays
        # as supplied, so a symlinked workspace is still refused where the artifacts are opened.
        start = Path(os.path.realpath(start)) if start.name == ".." else Path(os.path.realpath(start.parent)) / start.name
    for directory in (start, *start.parents):
        marker = directory / ".exactory"
        if any((marker / name).exists() or (marker / name).is_symlink()
               for name in ("research.sqlite3", "study.json", "draft.json")):
            return directory
    if required:
        raise ResearchError("migration_required", "Research readiness requires a current workspace; run exactory-research init or adopt")
    return None


@contextmanager
def checked_parent(root, relative, *, create=False):
    parts = _relative_parts(relative)
    workspace = _Workspace(root)
    if len(parts) == 1:
        boundary = _Workspace(workspace.root.parent)
        with boundary.directory(workspace.root.name, create=create) as descriptor:
            yield descriptor, parts[-1]
    else:
        with workspace.directory("/".join(parts[:-1]), create=create) as descriptor:
            yield descriptor, parts[-1]


@contextmanager
def open_file(root, relative):
    """Open a checked regular file without following path or final-entry links."""
    try:
        with checked_parent(root, relative) as (directory, name):
            source = os.fdopen(_regular_file(directory, name), "rb")
    except FileNotFoundError as error:
        raise ResearchError("artifact_missing", "Required workspace file is missing", {"path": relative}) from error
    except OSError as error:
        raise _filesystem_error(error) from error
    with source:
        yield source


def read_file(root, relative):
    try:
        with open_file(root, relative) as source:
            return source.read()
    except FileNotFoundError as error:
        raise ResearchError("artifact_missing", "Required workspace file is missing", {"path": relative}) from error
    except OSError as error:
        raise _filesystem_error(error) from error


def find_entry_kind(root, relative):
    """The kind of entry at a checked workspace path, "absent", "regular", "link" or "other"; a final link is not
    followed."""
    try:
        with checked_parent(root, relative) as (directory, name):
            mode = os.stat(name, dir_fd=directory, follow_symlinks=False).st_mode
    except FileNotFoundError:
        return "absent"
    except OSError as error:
        raise _filesystem_error(error) from error
    if stat.S_ISLNK(mode):
        return "link"
    return "regular" if stat.S_ISREG(mode) else "other"


def parse_workspace_marker(raw):
    """A legacy workspace marker as stored: a JSON object whose version is 1 or 2; no version counts as 1."""
    marker = strict_json(raw)
    if not isinstance(marker, dict) or marker.get("version", 1) not in (1, 2):
        raise ResearchError("migration_required", "Unsupported legacy workspace marker")
    return marker


def write_projection(root, relative, data, *, writable=False):
    """Atomically replace a disposable view; never follow an existing symlink."""
    with checked_parent(root, relative, create=True) as (directory, name):
        write_atomic(name, data, mode=0o600 if writable else 0o400, directory_fd=directory)


def json_projection(root, relative, value):
    write_projection(root, relative, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))

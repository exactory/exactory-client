"""Durable literature acquisition without creating reading or readiness records.

Public APIs (Store is already initialized):
collect_cohort(store, definition, *, request_id, expected_revision,
               max_requests=None, http=None, page_size=100)
resume_cohort(store, collection_id, *, request_id, expected_revision,
              max_requests=None, http=None)
collection_status(store, collection_id=None)
acquire_work(store, identifier, *, request_id, expected_revision, http=None,
             provider=None, max_requests=None)
acquire_fulltext(store, identifier, url, *, request_id, expected_revision,
                 http=None, max_requests=None, extractor=None, extraction_options=None, component=None)
import_response(store, provider, response: bytes, *, source_url, captured_at,
                request_id, expected_revision, media_type=None, mappings=None)
preview_import_response(store, provider, response: bytes, *, source_url, captured_at,
                        media_type=None, mappings=None)

Collection definitions are exactly freeze's four fields. collection/{id} holds
definition, page_size, active_operation, partitions [{id,start,end,offset,total,
seen_count,epoch,status,restart}], sequence, source_count, returned_count,
extraction_failures, pending, last_attempt_at and next_eligible_at. The latter
retains the latest observed Retry-After deadline as a UTC ISO timestamp, even
after expiry. Every resume restores it in a fresh client; a future deadline
beyond the fetch wait allowance produces pending without a new HTTP attempt.
Inclusive minute partitions
are disjoint; a query above the provider's 10,000-result ceiling is bisected
until enumerable or explicitly pending at a single minute, and a partition also
splits when the cursor reaches that ceiling before the partition completes.
cohort_member/cohort_exclusion/cohort_seen records are keyed by a hash of
collection/family and hold collection_id, work_id, version_ids and source_ids.
Family counts never count versions twice.
cohort_partition_member binds family membership to an enumeration epoch;
cohort_partition_entry binds every listed entry (exact id, or the listing
position of an entry without one) so a partition completes when the entries
seen equal the reported total. Entries outside the frozen window, without a
usable primary category, or without a parseable identity are retained as
exclusions with a reason, never as a reason to re-fetch the partition.
collection_page records every response/failed attempt, requested cursor,
reported counts, disposition, exact source_ids and excluded entries.
Historical pages never change.

acquisition_operation/{request_id} holds operation, payload, state, target,
admission_revision and original result. Admission uses the supplied revision;
every later commit uses a consistent snapshot and explicit revision CAS.
Deterministic derived request IDs identify pages and finalization. A replay
returns the original finalized result (or committed admission after a crash)
without further network I/O. A NEW request id for the same operation and target
supersedes an interrupted predecessor: a resumed collector's predecessor cannot
commit a page, a superseded work or full-text acquisition cannot finish, and a
superseded operation holds no request reservation.

max_requests counts all HTTP attempts, including retry/redirect/resolution
failures, across this invocation. Exhaustion is resumable and never complete.
Collection completion means enumeration and saved abstracts only. Status gives
actual source paths and separate reading obligations; it does not assert they
have been read. Registry acquisition's scope is metadata, not full-text reading
or verified bibliography completeness. Fulltext availability is source-specific.
Fulltext capture values contain source_id, requested_version_id, observed version,
url, original/text artifacts, availability (available|pending), extraction_status,
includes_abstract, visual_inspection_required, and extraction (extractor, version,
media_type, format_detection, options, and the measures of the extracted text).
media_type is the type the extraction used and format_detection names how it was
decided, so a PDF served as application/octet-stream or binary/octet-stream is
identifiable afterwards.
A capture with different extraction options is a distinct capture of the same
original. Missing bytes, extraction or exact-version agreement remain pending.
All PDF/HTML captures retain a separate visual inspection obligation for
non-text content.

source_import/{request_id} holds provider, source_url, captured_at,
response_sha256, media_type, mappings, source_id, work_ids and parser failures.
Web/MCP source_url identifies the supplied result's provenance, not a verified
origin article download. Their partial excerpts cannot replace full sources.

preview_import_response parses the same payload against the current snapshot
and returns {status: "preview", scope: "metadata_import", revision, work_ids,
pending, warnings, identity_conflicts} without a record, artifact, receipt or
charge. identity_conflicts, also in the original result of every new
import_response, lists each DOI whose family assertions the batch makes
ambiguous: {identifier, existing_families, incoming_families, candidates}, the
three arrays sorted. It covers conflicts inside one batch; an assertion that
repeats a recorded family adds none. The import continues; the field is
advisory, and an earlier result replays without it.
"""

import copy
import fcntl
import functools
import hashlib
import inspect
import os
import stat
from contextlib import contextmanager
import re
from datetime import date, datetime, timedelta, timezone

from .artifacts import ArtifactStore, describe_artifact
from .errors import ResearchError
from .finishing import retry_store_write
from .evidence import derived_id, digest, media_type as response_media_type, prepare_sources, prepare_work, put_sources, put_work
from .fulltext import GENERIC_BINARY_MEDIA_TYPES, XML_MEDIA_TYPES, parse_base_media_type, extract, extraction_measures
from .http import HttpClient, HttpFailure, RequestBudget, safe_url
from .identities import family_id, find_doi_family_conflicts, normalize_identifier, version_of
from .imports import parse_mapped, parse_publisher_capture
from .import_io import read_import_input, validate_import_size
from .workspace import checked_parent
from .operations import text
from .providers import Arxiv, Crossref, OpenAlex
from .provenance import runtime_provenance
from . import resources


@contextmanager
def hold_operation(store, target, request_id):
    relative = ".exactory/acquisition-locks/" + digest(target) + ".lock"
    with checked_parent(store.root, relative, create=True) as (directory, name):
        descriptor = os.open(name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=directory)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise ResearchError("unsafe_path", "Acquisition lock must be a regular file")
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            owner = os.read(descriptor, 4096).decode("utf-8", errors="replace")
            raise ResearchError("acquisition_in_progress", "An acquisition is running for this target",
                                {"target": target, "operation_id": owner})
        os.ftruncate(descriptor, 0)
        os.write(descriptor, request_id.encode("utf-8"))
        yield
    finally:
        os.close(descriptor)


def serialize_acquisition(function):
    signature = inspect.signature(function)

    @functools.wraps(function)
    def run(*args, **kwargs):
        values = signature.bind(*args, **kwargs).arguments
        store, request_id = values["store"], values["request_id"]
        # Authenticate replays in the operation itself, without acquiring a new lock.
        if store.committed_request(request_id) is not None:
            return function(*args, **kwargs)
        if "identifier" in values:
            target = normalize_identifier(values["identifier"])
        elif "definition" in values:
            target = "cohort:" + digest(_definition(values["definition"]))
        elif "collection_id" in values:
            target = text(values["collection_id"], "Collection ID")
        else:
            target = safe_url(values["source_url"])
        with hold_operation(store, target, request_id):
            return function(*args, **kwargs)
    return run


def _definition(value):
    if not isinstance(value, dict) or set(value) != {"corpus", "primaryCategory", "windowStart", "windowEnd"}:
        raise ResearchError("invalid_input", "Collection needs the exact four-field frozen cohort definition")
    if value["corpus"] != "arxiv":
        raise ResearchError("unsupported_corpus", "Managed cohort collection currently supports the arXiv corpus")
    if not isinstance(value["primaryCategory"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9.-]*", value["primaryCategory"]):
        raise ResearchError("invalid_input", "Cohort primary category is invalid")
    try:
        start, end = date.fromisoformat(value["windowStart"]), date.fromisoformat(value["windowEnd"])
        if start > end or start.isoformat() != value["windowStart"] or end.isoformat() != value["windowEnd"]:
            raise ValueError()
    except (TypeError, ValueError) as error:
        raise ResearchError("invalid_input", "Cohort window must contain ordered ISO dates") from error
    return dict(value)


_ENTRY_FAILURES = ("invalid_identifier", "invalid_response")
_CATEGORY_FAILURES = ("missing_primary_category", "invalid_primary_category")


def _partition(identifier, start, end):
    return {"id": identifier, "start": start, "end": end, "offset": 0, "total": None,
            "seen_count": 0, "entries_seen": 0, "epoch": 0, "status": "pending", "restart": False}


def describe_query_ceiling(partition, total):
    return {"code": "query_ceiling", "partition_id": partition["id"], "reported_total": total,
            "partition": {"start": partition["start"], "end": partition["end"]},
            "adapter_ceiling": Arxiv.query_ceiling, "retryable_with_same_configuration": False}


def _split_partition(collection, partition):
    """Replace a multi-minute partition by two date halves that restart at offset zero."""
    begin, end = (datetime.strptime(partition[key], "%Y%m%d%H%M") for key in ("start", "end"))
    middle = begin + timedelta(minutes=int((end - begin).total_seconds() // 120))
    children = [_partition(partition["id"] + ".0", partition["start"], middle.strftime("%Y%m%d%H%M")),
                _partition(partition["id"] + ".1", (middle + timedelta(minutes=1)).strftime("%Y%m%d%H%M"), partition["end"])]
    index = collection["partitions"].index(partition)
    collection["partitions"][index:index + 1] = children


def _supersede(transaction, operation, target, request_id):
    for identifier, record in transaction.records("acquisition_operation").items():
        if record["state"] == "admitted" and record["operation"] == operation and record["target"] == target and identifier != request_id:
            transaction.put("acquisition_operation", identifier, dict(record, state="superseded"))


def _begin(store, operation, payload, request_id, expected_revision, *, target=None, apply=None, reserved_requests=None):
    admitted = []
    runtime = runtime_provenance()

    def admission(transaction):
        if apply:
            apply(transaction)
        _supersede(transaction, operation, target, request_id)
        if reserved_requests != 0:
            resources.admit(transaction, "literature", payload.get("max_requests") if reserved_requests is None else reserved_requests)
        result = {"status": "admitted", "request_id": request_id, "revision": expected_revision + 1,
                  "target": target, "pending": [{"code": "operation_incomplete"}]}
        transaction.put("acquisition_operation", request_id,
                        {"operation": operation, "payload": payload if reserved_requests is None else dict(payload, max_requests=reserved_requests),
                         "state": "admitted", "target": target,
                         "admission_revision": expected_revision + 1, "result": result, "runtime": runtime})
        admitted.append(True)
        return result

    receipt = store.mutate(operation, payload, admission, expected_revision=expected_revision, request_id=request_id)
    if admitted:
        return None
    record = store.snapshot()["records"].get("acquisition_operation", {}).get(request_id)
    return receipt["result"] if record is None else record["result"]


def _finish(store, request_id, revision, result, *, apply=None):
    return retry_store_write(lambda: _finish_once(store, request_id, store.revision, result, apply=apply))


def _finish_once(store, request_id, revision, result, *, apply=None):
    final = dict(result, request_id=request_id, revision=revision + 1)

    def commit(transaction):
        if apply:
            apply(transaction)
        operation = transaction.get("acquisition_operation", request_id)
        if operation is None or operation["state"] != "admitted":
            raise ResearchError("operation_conflict", "Acquisition operation is no longer admitted")
        operation.update({"state": "finished", "result": final})
        transaction.put("acquisition_operation", request_id, operation)
        captured = sum(s["response"]["size"] for s in transaction.records("source").values()
                       if s.get("operation_id") == request_id and s.get("response") is not None)
        change = resources.charge(transaction, "literature", {"network_requests": final.get("attempts_used", 0), "source_bytes": captured},
                                  refuse=False)
        if change is not None:
            transaction.put(*change)
        return final

    return store.mutate("acquisition.finish", {"operation_id": request_id, "result": final}, commit,
                        expected_revision=revision, request_id=derived_id(request_id, "finish"))["result"]


def _collection_members(records, collection_id, kind):
    return [record for record in records.get(kind, {}).values() if record["collection_id"] == collection_id]


def _collection_summary(records, collection):
    from .cohort_evidence import current_selection
    collection_id = collection["id"]
    members = _collection_members(records, collection_id, "cohort_member")
    exclusions = _collection_members(records, collection_id, "cohort_exclusion")
    seen = _collection_members(records, collection_id, "cohort_seen")
    pending = copy.deepcopy(collection["pending"])
    # A family observed as a member on one capture and as an exclusion on another (the provider
    # changed its primary category between captures) is an explicit, retained conflict. Both
    # observations stay recorded; the member obligations remain; the collection is not paused.
    category_conflicts = sorted({m["work_id"] for m in members} & {m["work_id"] for m in exclusions})
    conflicts = [{"code": "primary_category_conflict", "work_ids": category_conflicts}] if category_conflicts else []
    obligations, historical = [], []
    for member in sorted(members, key=lambda m: m["work_id"]):
        for identifier in member["version_ids"]:
            work = records.get("work", {}).get(identifier)
            abstract = work.get("abstract") if work else None
            selection = current_selection(records, collection_id, member, identifier)
            if selection is not None:
                historical.append({"work_id": member["work_id"], "version_id": identifier,
                    "unresolved_assertion_id": selection["unresolved_assertion_id"], "artifact": abstract,
                    "source_ids": work["source_ids"], "selected_assertion_id": selection["selected_assertion_id"],
                    "reason": selection["reason"], "historical_version_resolved": False})
                obligations.append({"work_id": member["work_id"], "version_id": selection["version_id"], "depth": "abstract",
                                    "artifact": selection["artifact"], "source_ids": [selection["source_id"]],
                                    "selection": selection})
                continue
            if abstract is None:
                pending.append({"code": "missing_abstract", "work_id": member["work_id"], "version_id": identifier})
            if work and work["id"].startswith("arxiv:") and work["version"] is None:
                pending.append({"code": "missing_version", "work_id": member["work_id"]})
            obligations.append({"work_id": member["work_id"], "version_id": identifier, "depth": "abstract",
                                "artifact": abstract, "source_ids": [a["source_id"] for a in work["abstracts"]
                                    if a["artifact"] == abstract and a["completeness"] == "complete"] if work else []})
    unenumerated = [p["id"] for p in collection["partitions"] if p["status"] != "complete"]
    if not unenumerated:
        epochs = {(p["id"], p["epoch"]) for p in collection["partitions"]}
        current = {m["work_id"] for m in records.get("cohort_partition_member", {}).values()
                   if m["collection_id"] == collection_id and (m["partition_id"], m["epoch"]) in epochs}
        lost = sorted({m["work_id"] for m in seen} - current)
        if lost:
            pending.append({"code": "population_changed", "retained_work_ids": lost})
    if unenumerated and not pending:
        pending.append({"code": "collection_incomplete", "partitions": unenumerated})
    exclusion_reasons = {}
    for exclusion in exclusions:
        for reason in exclusion.get("exclusion_reasons", ["other_primary_category"]):
            exclusion_reasons[reason] = exclusion_reasons.get(reason, 0) + 1
    return {"collection_id": collection_id, "definition": collection["definition"],
            "status": "paused" if pending else "complete", "pending": pending,
            "source_count": collection["source_count"], "returned_count": collection["returned_count"],
            "unique_count": len(seen), "member_count": len(members), "exclusion_count": len(exclusions),
            "exclusion_reasons": dict(sorted(exclusion_reasons.items())),
            "extraction_failures": collection["extraction_failures"], "pending_partitions": unenumerated,
            "next_eligible_at": collection.get("next_eligible_at"),
            "historical_unresolved": historical, "conflicts": conflicts,
            "reading_obligations": obligations, "next_abstract": next((o for o in obligations if o["artifact"]), None)}


def collection_status(store, collection_id=None):
    snapshot = store.snapshot()
    collections = snapshot["records"].get("collection", {})
    if collection_id is not None and collection_id not in collections:
        raise ResearchError("unknown_collection", "No collection has this identifier")
    selected = list(collections.values()) if collection_id is None else [collections[collection_id]]
    summaries = [_collection_summary(snapshot["records"], c) for c in selected]
    from .evaluation import Evaluation
    from .oai_cohort import enumeration_evidence
    artifacts = Evaluation(snapshot["records"], ArtifactStore(store.root))
    for collection in selected:
        enumeration_evidence(snapshot["records"], artifacts, collection)
    for summary in summaries:
        for obligation in summary["reading_obligations"]:
            if obligation["artifact"]:
                artifacts.read(obligation["artifact"])
            if obligation.get("selection"):
                artifacts.read(snapshot["records"]["source"][obligation["selection"]["source_id"]]["response"])
        for historical in summary["historical_unresolved"]:
            for source_id in historical["source_ids"]:
                artifacts.read(snapshot["records"]["source"][source_id]["response"])
    return ({"revision": snapshot["revision"], "collections": summaries} if collection_id is None
            else dict(summaries[0], revision=snapshot["revision"]))


@serialize_acquisition
def collect_cohort(store, definition, *, request_id, expected_revision, max_requests=None, http=None, page_size=100):
    definition = _definition(definition)
    budget = RequestBudget(max_requests)
    if type(page_size) is not int or not 1 <= page_size <= 2000:
        raise ResearchError("invalid_input", "arXiv page_size must be between 1 and 2000")
    collection_id = "cohort:" + digest(definition)
    payload = {"definition": definition, "max_requests": max_requests, "page_size": page_size}

    def admission(transaction):
        collection = transaction.get("collection", collection_id)
        if collection is not None:
            raise ResearchError("collection_exists", "Use resume_cohort to continue the existing population", {"collection_id": collection_id})
        collection = {"id": collection_id, "definition": definition, "page_size": page_size,
                      "active_operation": request_id, "sequence": 0, "source_count": 0,
                      "returned_count": 0, "extraction_failures": 0, "pending": [], "last_attempt_at": None,
                      "next_eligible_at": None,
                      "partitions": [_partition("0", definition["windowStart"].replace("-", "") + "0000",
                                                definition["windowEnd"].replace("-", "") + "2359")]}
        transaction.put("collection", collection_id, collection)

    replay = _begin(store, "cohort.collect", payload, request_id, expected_revision, target=collection_id, apply=admission)
    return replay if replay is not None else _run_collection(store, collection_id, request_id, budget, http or HttpClient())


@serialize_acquisition
def resume_cohort(store, collection_id, *, request_id, expected_revision, max_requests=None, http=None, recheck=False):
    if type(recheck) is not bool:
        raise ResearchError("invalid_input", "recheck must be boolean")
    budget = RequestBudget(max_requests)
    held = (store._read_scoped_preparation().records.get("collection", {}).get(collection_id)
            if store.committed_request(request_id) is None else None)
    preserve_ceiling = (not recheck and held is not None and any(p.get("code") == "query_ceiling" for p in held["pending"]))

    def admission(transaction):
        collection = transaction.get("collection", collection_id)
        if collection is None:
            raise ResearchError("unknown_collection", "No collection has this identifier")
        previous = transaction.get("acquisition_operation", collection["active_operation"]) if collection["active_operation"] else None
        if previous is not None and previous["state"] == "admitted":
            transaction.put("acquisition_operation", collection["active_operation"], dict(previous, state="superseded"))
        collection["active_operation"] = request_id
        ceilings = {p.get("partition_id"): p for p in collection["pending"] if p.get("code") == "query_ceiling"}
        if recheck:
            for partition in collection["partitions"]:
                if partition['id'] in ceilings and partition['offset']:
                    partition['restart'] = True
            collection["pending"] = []
        elif ceilings:
            collection["pending"] = [describe_query_ceiling(partition, ceilings[partition['id']].get('reported_total'))
                                      for partition in collection['partitions'] if partition['id'] in ceilings
                                      and partition['start'] == partition['end']]
        else:
            collection["pending"] = []
        for partition in collection["partitions"]:
            if partition["restart"]:
                partition.update({"offset": 0, "total": None, "seen_count": 0, "epoch": partition["epoch"] + 1,
                                  "status": "pending", "restart": False})
                if "entries_seen" in partition:
                    partition["entries_seen"] = 0
        transaction.put("collection", collection_id, collection)

    payload = {"collection_id": collection_id, "max_requests": max_requests}
    if recheck:
        payload["recheck"] = True
    replay = _begin(store, "cohort.resume", payload,
                    request_id, expected_revision, target=collection_id, apply=admission,
                    reserved_requests=0 if preserve_ceiling else None)
    return replay if replay is not None else _run_collection(store, collection_id, request_id, budget, http or HttpClient())


def _member(transaction, collection_id, work, source_id, kind, reason=None):
    key = digest([collection_id, work["work_id"]])
    member = transaction.get(kind, key) or {"collection_id": collection_id, "work_id": work["work_id"], "version_ids": [], "source_ids": []}
    if work["id"] not in member["version_ids"]:
        member["version_ids"].append(work["id"])
    if source_id not in member["source_ids"]:
        member["source_ids"].append(source_id)
    if reason is not None and reason not in member.get("exclusion_reasons", []):
        member["exclusion_reasons"] = member.get("exclusion_reasons", []) + [reason]
    transaction.put(kind, key, member)


def _page_update(transaction, collection, partition_id, page, prepared, sources, error, request_id):
    if transaction.get("collection", collection["id"])["active_operation"] != request_id:
        raise ResearchError("operation_superseded", "A newer resume operation owns this collection")
    partition = next(p for p in collection["partitions"] if p["id"] == partition_id)
    requested = copy.deepcopy(partition)
    collection["source_count"] += len(sources)
    if sources:
        collection["last_attempt_at"] = sources[-1]["captured_at"]
    eligible_times = [source["next_eligible_at"] for source in sources if source["next_eligible_at"] is not None]
    if collection.get("next_eligible_at") is not None:
        eligible_times.append(collection["next_eligible_at"])
    collection["next_eligible_at"] = max(eligible_times) if eligible_times else None
    put_sources(transaction, sources)
    page_failures = [] if page is None else list(page.failures)
    failures = [f for f in page_failures if f["code"] not in _ENTRY_FAILURES + _CATEGORY_FAILURES]
    excluded_entries = [f for f in page_failures if f["code"] in _ENTRY_FAILURES]
    category_failures = {f.get("id"): f["code"] for f in page_failures if f["code"] in _CATEGORY_FAILURES}
    warnings = list(page.warnings) if page else []
    entry_keys = []
    if page is not None:
        collection["returned_count"] += page.returned_count
        collection["extraction_failures"] += len(page_failures)
    for item in prepared:
        work = put_work(transaction, item)
        source_id = item[0]["source_id"]
        _member(transaction, collection["id"], work, source_id, "cohort_seen")
        entry_keys.append(work["id"])
        category = item[0]["category"]
        published = item[0]["publication_date"]
        try:
            published_time = datetime.fromisoformat(published.replace("Z", "+00:00")).astimezone(timezone.utc)
            published_date = published_time.date().isoformat()
            within_window = collection["definition"]["windowStart"] <= published_date <= collection["definition"]["windowEnd"]
            if not partition["start"] <= published_time.strftime("%Y%m%d%H%M") <= partition["end"]:
                warnings.append({"code": "out_of_partition_date", "id": work["id"]})
        except (TypeError, ValueError, AttributeError):
            within_window = False
        # An entry the frozen window or the category rule excludes is retained with
        # its reason. It counts as seen; it is never a reason to re-fetch the partition.
        if not within_window:
            _member(transaction, collection["id"], work, source_id, "cohort_exclusion", "out_of_scope_date")
        elif not category:
            _member(transaction, collection["id"], work, source_id, "cohort_exclusion",
                    category_failures.get(work["id"], "missing_primary_category"))
        elif category == collection["definition"]["primaryCategory"]:
            _member(transaction, collection["id"], work, source_id, "cohort_member")
        else:
            _member(transaction, collection["id"], work, source_id, "cohort_exclusion", "other_primary_category")
    for failure in excluded_entries:
        entry_keys.append("position:" + str(partition["offset"] + failure["index"]))
    disposition = "accepted"
    if error and error.code == "query_ceiling" and partition["start"] != partition["end"]:
        # The cursor reached the provider's query ceiling before the partition
        # completed; its retained entries stay and its date range splits.
        _split_partition(collection, partition)
        disposition = "split"
    elif error:
        diagnosis = (describe_query_ceiling(partition, partition['total']) if error.code == 'query_ceiling'
                     else {"code": error.code})
        failures.insert(0, diagnosis)
        disposition = "failed"
    elif page.start != partition["offset"]:
        failures.insert(0, {"code": "changed_cursor"})
        partition["restart"] = True
    elif partition["total"] is not None and page.total != partition["total"]:
        failures.insert(0, {"code": "changed_total", "previous": partition["total"], "observed": page.total})
        partition["restart"] = True
    elif page.total > Arxiv.query_ceiling:
        if partition["start"] == partition["end"]:
            failures.insert(0, describe_query_ceiling(partition, page.total))
        else:
            _split_partition(collection, partition)
            disposition = "split"
    elif page.returned_count == 0 and page.total != partition["offset"]:
        failures.insert(0, {"code": "empty_page"})
    elif partition["offset"] + page.returned_count > page.total:
        failures.insert(0, {"code": "inconsistent_count"})
        partition["restart"] = True
    else:
        partition["total"] = page.total
        new_entries = 0
        for entry in entry_keys:
            key = digest([collection["id"], partition["id"], partition["epoch"], "entry", entry])
            if transaction.get("cohort_partition_entry", key) is None:
                new_entries += 1
                transaction.put("cohort_partition_entry", key,
                    {"collection_id": collection["id"], "partition_id": partition["id"],
                     "epoch": partition["epoch"], "entry": entry})
        for item in prepared:
            key = digest([collection["id"], partition["id"], partition["epoch"], item[0]["work_id"]])
            if transaction.get("cohort_partition_member", key) is None:
                partition["seen_count"] += 1
                transaction.put("cohort_partition_member", key,
                    {"collection_id": collection["id"], "partition_id": partition["id"],
                     "epoch": partition["epoch"], "work_id": item[0]["work_id"]})
        if page.returned_count and new_entries == 0:
            # The provider repeated a page it already served; keep the cursor and ask again.
            failures.append({"code": "duplicate_page"})
        else:
            if "entries_seen" in partition:
                partition["entries_seen"] += new_entries
            partition["offset"] += page.returned_count
            if partition["offset"] == partition["total"]:
                # Partitions from earlier releases counted families; new partitions count entries.
                counted = partition["entries_seen"] if "entries_seen" in partition else partition["seen_count"]
                if counted != partition["total"]:
                    failures.append({"code": "duplicate_or_missing_results"})
                    partition["restart"] = True
                elif not failures:
                    partition["status"] = "complete"
    if failures:
        disposition = "pending"
        collection["pending"] = failures
    page_record = {"collection_id": collection["id"], "sequence": collection["sequence"], "requested": requested,
                   "source_ids": [s["id"] for s in sources], "reported_total": page.total if page else None,
                   "returned_count": page.returned_count if page else 0, "disposition": disposition, "failures": failures,
                   "warnings": warnings, "excluded_entries": excluded_entries}
    transaction.put("collection_page", derived_id(collection["id"], "page", collection["sequence"]), page_record)
    collection["sequence"] += 1
    transaction.put("collection", collection["id"], collection)
    return {"collection_id": collection["id"], "sequence": collection["sequence"], "disposition": disposition}


def _run_collection(store, collection_id, request_id, budget, http):
    artifacts, provider = ArtifactStore(store.root), Arxiv()
    while True:
        snapshot = store.snapshot()
        collection = snapshot["records"]["collection"][collection_id]
        if collection["active_operation"] != request_id:
            raise ResearchError("operation_superseded", "A newer resume operation owns this collection")
        partition = next((p for p in collection["partitions"] if p["status"] != "complete"), None)
        if partition is None or collection["pending"]:
            break
        try:
            budget.check()
        except ResearchError as error:
            collection["pending"] = [{"code": error.code}]
            break
        if collection["last_attempt_at"]:
            http.pace_from("export.arxiv.org", collection["last_attempt_at"])
        page, failure, attempts, prepared = None, None, [], []
        try:
            request = provider.collection_request(collection["definition"]["primaryCategory"], partition["start"], partition["end"],
                                                    start=partition["offset"], page_size=collection["page_size"])
            response = http.get(request.url, headers=request.headers, accept=request.accept, budget=budget,
                                not_before=collection.get("next_eligible_at"))
            attempts = response.attempts
            page = provider.parse(response.body)
        except HttpFailure as error:
            failure, attempts = error, error.attempts
        except ResearchError as error:
            failure = error
        sources = prepare_sources(artifacts, attempts, "arxiv", request_id, start=collection["source_count"])
        if page is not None:
            prepared = [prepare_work(artifacts, w, sources[-1]["id"]) for w in page.works]
        result = retry_store_write(lambda: store.mutate("cohort.page", {"collection_id": collection_id, "sequence": collection["sequence"],
                              "source_ids": [s["id"] for s in sources], "failure": failure.code if failure else None},
            lambda tx: _page_update(tx, copy.deepcopy(collection), partition["id"], page, prepared, sources, failure, request_id),
            expected_revision=store.revision, request_id=derived_id(request_id, "page", collection["sequence"])))
        if result["result"]["disposition"] == "pending":
            continue
    result = _collection_summary(snapshot["records"], collection)
    result["attempts_used"] = budget.used

    def finish(transaction):
        current = transaction.get("collection", collection_id)
        if current["active_operation"] != request_id:
            raise ResearchError("operation_superseded", "A newer resume operation owns this collection")
        collection["active_operation"] = None
        transaction.put("collection", collection_id, collection)

    return _finish(store, request_id, snapshot["revision"], result, apply=finish)


def _next_eligible(records, identifier):
    """The latest persisted Retry-After deadline for this identifier, honored across processes."""
    deadlines = [s["next_eligible_at"] for s in records.get("source", {}).values()
                 if s.get("requested_identifier") == identifier and s.get("next_eligible_at")]
    return max(deadlines) if deadlines else None


def _provider(name):
    providers = {"arxiv": Arxiv, "openalex": OpenAlex, "crossref": Crossref}
    if name not in providers:
        raise ResearchError("unsupported_provider", "Expected arxiv, openalex or crossref")
    return providers[name]()


def _matches(identifier, work):
    if identifier == work["id"]:
        return True
    if identifier.startswith("arxiv:"):
        return version_of(identifier) is None and family_id(identifier) == work["work_id"]
    return identifier in work["aliases"]


@serialize_acquisition
def acquire_work(store, identifier, *, request_id, expected_revision, http=None, provider=None, max_requests=None):
    identifier = normalize_identifier(identifier)
    provider = _provider(provider or ("arxiv" if identifier.startswith("arxiv:") else "openalex" if identifier.startswith("openalex:") else "crossref"))
    request = provider.work_request(identifier)
    budget = RequestBudget(max_requests)
    replay = _begin(store, "work.acquire", {"identifier": identifier, "provider": provider.name, "max_requests": max_requests},
                    request_id, expected_revision, target=identifier)
    if replay is not None:
        return replay
    snapshot = store.snapshot()
    http, artifacts = http or HttpClient(), ArtifactStore(store.root)
    attempts, pending, works, observed_identifier, warnings = [], [], [], None, []
    try:
        response = http.get(request.url, headers=request.headers, accept=request.accept, budget=budget,
                            not_before=_next_eligible(snapshot["records"], identifier))
        attempts = response.attempts
        page = provider.parse(response.body)
        pending.extend(page.failures)
        warnings = list(page.warnings)
        if len(page.works) == 1:
            observed_identifier = page.works[0]["id"]
        if len(page.works) != 1 or not _matches(identifier, page.works[0]):
            pending.insert(0, {"code": "identifier_mismatch", "identifier": identifier})
        else:
            works = page.works
    except HttpFailure as error:
        attempts, pending = error.attempts, [{"code": error.code}]
    except ResearchError as error:
        pending.append({"code": error.code})
    sources = prepare_sources(artifacts, attempts, provider.name, request_id, requested_identifier=identifier)
    if observed_identifier and sources:
        sources[-1].update({"exact_version": version_of(observed_identifier), "observed_identifier": observed_identifier})
    prepared = [prepare_work(artifacts, work, sources[-1]["id"]) for work in works]
    for work in works:
        if work["abstract_text"] is None:
            pending.append({"code": "missing_abstract", "work_id": work["work_id"]})
        if work["id"].startswith("arxiv:") and work["version"] is None:
            pending.append({"code": "missing_version", "work_id": work["work_id"]})

    def commit(transaction):
        put_sources(transaction, sources)
        for item in prepared:
            put_work(transaction, item)

    return _finish(store, request_id, snapshot["revision"],
                   {"status": "pending" if pending else "complete", "scope": "metadata", "pending": pending, "warnings": warnings,
                    "work_ids": [w["id"] for w in works], "source_ids": [s["id"] for s in sources], "attempts_used": budget.used},
                   apply=commit)


def _extraction_options(value):
    if value is None:
        return {}
    if not isinstance(value, dict) or not set(value) <= {"layout", "ocr"} or any(type(v) is not bool for v in value.values()):
        raise ResearchError("invalid_input", "Extraction options accept boolean layout and ocr flags")
    if value.get("ocr") and "layout" in value:
        raise ResearchError("invalid_input", "The layout flag applies to pdftotext; OCR uses its recorded page segmentation mode")
    return dict(value)


@serialize_acquisition
def acquire_fulltext(store, identifier, url, *, request_id, expected_revision, http=None, max_requests=None, extractor=None,
                     extraction_options=None, component=None):
    identifier, url = normalize_identifier(identifier), safe_url(url)
    budget = RequestBudget(max_requests)
    options = _extraction_options(extraction_options)
    component = copy.deepcopy(component)

    def admission(transaction):
        if transaction.get("work", identifier) is None:
            raise ResearchError("unknown_work", "Acquire metadata for the exact version before acquiring its full text")

    payload = {"identifier": identifier, "url": url, "max_requests": max_requests}
    if options:
        payload["extraction_options"] = options
    if component is not None:
        payload["component"] = component
    replay = _begin(store, "fulltext.acquire", payload, request_id, expected_revision, target=identifier, apply=admission)
    if replay is not None:
        return replay
    snapshot = store.snapshot()
    http, artifacts = http or HttpClient(), ArtifactStore(store.root)
    attempts, pending, extracted, observed_identifier = [], [], None, None
    try:
        response = http.get(url, accept=("application/pdf", "text/html", "application/xhtml+xml",
                                         *sorted(XML_MEDIA_TYPES),
                                         *sorted(GENERIC_BINARY_MEDIA_TYPES)), budget=budget,
                            not_before=_next_eligible(snapshot["records"], identifier))
        attempts = response.attempts
        if component is None and identifier.startswith("arxiv:"):
            observed_identifier = normalize_identifier(response.url)
            if observed_identifier != identifier or version_of(observed_identifier) is None:
                raise ResearchError("version_mismatch", "Full-text destination differs from the requested arXiv version")
        extracted = extract(response.body, response_media_type(response.headers), extractor=extractor,
                            layout=options.get("layout", True), ocr=options.get("ocr", False))
        if extracted["status"] != "extracted":
            pending.append({"code": extracted["status"]})
    except HttpFailure as error:
        attempts, pending = error.attempts, [{"code": error.code}]
    except ResearchError as error:
        pending.append({"code": error.code})
    sources = prepare_sources(artifacts, attempts, "fulltext", request_id, requested_identifier=identifier)
    if observed_identifier and sources:
        sources[-1].update({"exact_version": version_of(observed_identifier), "observed_identifier": observed_identifier})
    if component is not None and sources:
        sources[-1].update({"exact_version": None, "observed_identifier": None})
    capture = {"source_id": sources[-1]["id"] if sources else None, "version": version_of(observed_identifier) if observed_identifier else None,
               "requested_version_id": identifier,
               "url": sources[-1]["url"] if sources else url, "original": sources[-1]["response"] if sources else None,
               "text": artifacts.put(extracted["text"].encode(), "text/plain; charset=utf-8") if extracted and extracted["text"] is not None else None,
               "availability": "available" if not pending else "pending", "extraction_status": extracted["status"] if extracted else pending[0]["code"],
               "includes_abstract": extracted["includes_abstract"] if extracted else None,
               "visual_inspection_required": extracted["visual_inspection_required"] if extracted else True,
               "extraction": dict({"extractor": extracted["extractor"] if extracted else None,
                                   "version": extracted["version"] if extracted else None,
                                   "media_type": extracted["media_type"] if extracted else None,
                                   "format_detection": extracted["format_detection"] if extracted else None,
                                   "options": extracted["options"] if extracted else options},
                                  **(extraction_measures(extracted["text"], len(response.body))
                                     if extracted and extracted["text"] is not None else
                                     {"text_bytes": None, "page_count": None, "max_line_length": None,
                                      "whitespace_fraction": None, "expansion_ratio": None}))}

    if extracted and "visual_asset_names" in extracted:
        capture["visual_asset_names"] = extracted["visual_asset_names"]

    if component is not None:
        from .components import validate_spec
        capture["component"] = {"status": "pending", "parent_version_id": identifier,
                                "spec": component, "identity": digest([identifier, component])}
        if not pending:
            try:
                validate_spec(snapshot["records"], artifacts, identifier, capture, component)
                capture["component"]["status"] = "bound"
            except ResearchError as error:
                pending.append({"code": error.code})
                capture["availability"] = "pending"

    def commit(transaction):
        put_sources(transaction, sources)
        work = transaction.get("work", identifier)
        work["fulltexts"].append(capture)
        transaction.put("work", identifier, work)

    return _finish(store, request_id, snapshot["revision"],
                   {"status": "pending" if pending else "complete", "scope": "fulltext_acquisition", "pending": pending,
                    "work_id": identifier, "capture": capture, "attempts_used": budget.used}, apply=commit)


def _import_page(provider, response, source_url, captured_at, media_type, mappings, publisher_capture=None):
    source_url = safe_url(source_url)
    if not isinstance(response, bytes):
        raise ResearchError("invalid_import", "Import response must be original bytes")
    try:
        timestamp = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
        if timestamp.utcoffset() is None:
            raise ValueError()
    except (TypeError, ValueError, AttributeError) as error:
        raise ResearchError("invalid_import", "Import capture time must contain an explicit timezone") from error
    if publisher_capture is not None:
        if provider not in ("web", "mcp") or mappings is not None:
            raise ResearchError("invalid_publisher_capture", "Publisher captures require web/MCP import without mappings")
        page = parse_publisher_capture(response, media_type, source_url, publisher_capture)
    elif provider in ("web", "mcp"):
        if parse_base_media_type(media_type) not in ("application/json", "text/plain", "text/html"):
            raise ResearchError("invalid_import", "Web/MCP import must declare JSON, text or HTML media type")
        try:
            describe_artifact(response, media_type)
        except ResearchError as error:
            raise ResearchError("invalid_import",
                                "Import media type must have no whitespace around type/subtype, "
                                "and the text after a semicolon must be non-empty printable ASCII") from error
        page = parse_mapped(response, media_type, mappings)
    else:
        adapter = _provider(provider)
        media_type = media_type or ("application/atom+xml" if provider == "arxiv" else "application/json")
        page = adapter.parse(response)
    return source_url, media_type, page


def _import_pending(page):
    pending = list(page.failures)
    for work in page.works:
        if work["abstract_status"] != "available":
            code = "partial_abstract" if work["abstract_status"] == "partial" else "missing_abstract"
            pending.append({"code": code, "work_id": work["work_id"]})
        if work["id"].startswith("arxiv:") and work["version"] is None:
            pending.append({"code": "missing_version", "work_id": work["work_id"]})
    return pending


def preview_import_response(store, provider, response, *, source_url, captured_at, media_type=None,
                            mappings=None, publisher_capture=None):
    """Parse local response bytes and report new DOI-family conflicts without writing evidence."""
    validate_import_size(len(response), input_kind="response")
    _, _, page = _import_page(provider, response, source_url, captured_at, media_type, mappings, publisher_capture)
    snapshot = store.snapshot()
    result = {"status": "preview", "scope": "metadata_import", "revision": snapshot["revision"],
              "work_ids": [work["id"] for work in page.works], "pending": _import_pending(page),
              "warnings": list(page.warnings),
              "identity_conflicts": find_doi_family_conflicts(snapshot["records"], page.works)}
    if publisher_capture is not None:
        from .source_candidates import find_source_candidates
        artifacts = ArtifactStore(store.root)
        result["source_candidates"] = [dict(version_id=work["id"], **find_source_candidates(
            snapshot["records"], artifacts, work["id"])) for work in page.works]
    return result


def build_import_payload(provider, response_sha256, *, source_url, captured_at, media_type=None,
                         mappings=None, publisher_capture=None):
    if provider not in ("web", "mcp"):
        media_type = media_type or ("application/atom+xml" if provider == "arxiv" else "application/json")
    payload = {"provider": provider, "source_url": safe_url(source_url), "captured_at": captured_at,
               "response_sha256": response_sha256, "media_type": media_type, "mappings": mappings}
    if publisher_capture is not None:
        payload["publisher_capture"] = publisher_capture
    return payload


def import_response_file(store, provider, response_file, *, source_url, captured_at, request_id, expected_revision,
                         media_type=None, mappings=None, publisher_capture=None):
    if store.committed_request(request_id) is not None:
        hasher = hashlib.sha256()
        descriptor = os.open(response_file, os.O_RDONLY | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as source:
            if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
                raise ResearchError("invalid_import", "Import response must be a regular file")
            for block in iter(lambda: source.read(65536), b""):
                hasher.update(block)
        payload = build_import_payload(provider, hasher.hexdigest(), source_url=source_url, captured_at=captured_at,
                                       media_type=media_type, mappings=mappings, publisher_capture=publisher_capture)
        return _begin(store, "response.import", payload, request_id, expected_revision, target=payload["source_url"])
    response = read_import_input(response_file, input_kind="response")
    return import_response(store, provider, response, source_url=source_url, captured_at=captured_at,
                           media_type=media_type, mappings=mappings, publisher_capture=publisher_capture,
                           request_id=request_id, expected_revision=expected_revision)


def import_response(store, provider, response, *, source_url, captured_at, request_id, expected_revision,
                    media_type=None, mappings=None, publisher_capture=None):
    if not isinstance(response, bytes):
        raise ResearchError("invalid_import", "Import response must be original bytes")
    payload = build_import_payload(provider, digest_bytes(response), source_url=source_url, captured_at=captured_at,
                                   media_type=media_type, mappings=mappings, publisher_capture=publisher_capture)
    if store.committed_request(request_id) is not None:
        return _begin(store, "response.import", payload, request_id, expected_revision, target=payload["source_url"])
    validate_import_size(len(response), input_kind="response")
    from .storage import _canonical
    validate_import_size(len(_canonical(payload).encode("utf-8")), input_kind="payload")
    with hold_operation(store, payload['source_url'], request_id):
        source_url, media_type, page = _import_page(
            provider, response, source_url, captured_at, media_type, mappings, publisher_capture)
        replay = _begin(store, "response.import", payload, request_id, expected_revision, target=source_url)
        if replay is not None:
            return replay
        snapshot = store.snapshot()
        artifacts = ArtifactStore(store.root)
        attempts = [{"url": source_url, "captured_at": captured_at, "status": 200,
                     "headers": {"content-type": media_type}, "body": response, "complete": True, "error": None}]
        sources = prepare_sources(artifacts, attempts, provider, request_id)
        if provider in ("web", "mcp"):
            sources[0]["response"] = artifacts.put(response, media_type)
        sources[0]["http_status"] = None
        sources[0]["imported"] = True
        sources[0].update({"capture_method": "external_import", "content_scope": "tool_response" if provider in ("web", "mcp") else "provider_response",
                           "origin_verified": False})
        if publisher_capture is not None:
            sources[0].update(publisher_capture=publisher_capture, content_scope="publisher_metadata",
                              observed_identifier=page.works[0]["id"])
        prepared = [prepare_work(artifacts, work, sources[0]["id"]) for work in page.works]
        pending = _import_pending(page)
        identity_conflicts = find_doi_family_conflicts(snapshot["records"], page.works)

        def commit(transaction):
            put_sources(transaction, sources)
            for item in prepared:
                put_work(transaction, item)
            transaction.put("source_import", request_id,
                            dict(payload, source_id=sources[0]["id"], work_ids=[w["id"] for w in page.works], failures=page.failures))

        # The family conflicts come from this snapshot, so the write keeps its revision instead of retrying on a later one;
        # an import costs no network request to run again.
        return _finish_once(store, request_id, snapshot["revision"],
                            {"status": "pending" if pending else "complete", "scope": "metadata_import", "pending": pending,
                             "work_ids": [w["id"] for w in page.works], "source_ids": [s["id"] for s in sources],
                             "identity_conflicts": identity_conflicts}, apply=commit)


def digest_bytes(data):
    import hashlib
    return hashlib.sha256(data).hexdigest()


def import_oai_cohort(store, collection_id, pages, *, request_id, expected_revision):
    """Import an original complete OAI chain into an existing frozen collection."""
    from .oai_cohort import import_cohort
    return import_cohort(store, collection_id, pages, request_id=request_id, expected_revision=expected_revision)

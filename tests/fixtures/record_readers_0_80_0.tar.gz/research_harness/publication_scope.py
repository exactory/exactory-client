"""Immutable supported-manuscript targets, separate from the complete objective.

Scientific identity excludes administrative aliases. Exact candidate identity
retains freshness and provenance. An adverse scientific target stays adverse;
independent review of a correction may accept only its different successor.
"""

import json
import unicodedata

from .artifacts import ArtifactStore
from .development import _Context, _Evidence, _REVIEW_CHECKS, _unique, cycle_authors
from .errors import ResearchError
from .evaluation import Evaluation
from .evidence import digest
from .execution_evidence import author_readiness_state, validate_observed_execution
from .graph import obligation
from .operations import fields, immutable_record, prepared_mutation, strings, text
from .source_deferrals import assess_deferrals, build_source_gap_disclosure
from .workspace import strict_json


POLICY = "source-limited-v1"
_CODE = "invalid_publication_scope"


def _normalize_prose(value):
    return " ".join(unicodedata.normalize("NFC", value).split())


def _sort_canonically(values):
    return sorted(values, key=lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False))


def _build_scientific_set(values):
    return _sort_canonically({digest(value): value for value in values}.values())


def find_publication_scope(records):
    selection = records.get("publication_scope_selection", {}).get("current")
    if selection is None or selection["id"] is None:
        return None
    saved = records.get("publication_scope", {}).get(selection["id"])
    if saved is None:
        raise ResearchError("publication_scope_missing", "The explicitly selected publication scope is missing")
    if not isinstance(saved, dict) or saved.get("digest") != digest({k: v for k, v in saved.items() if k != "digest"}):
        raise ResearchError("publication_scope_corrupt", "The selected immutable scope record failed its content binding")
    return saved


def has_publication_scope(records):
    """An invalid selected ID still opts in and therefore fails closed."""
    return records.get("publication_scope_selection", {}).get("current", {}).get("id") is not None


def _build_canonical_evidence(context, reference):
    item = _Evidence(context).one(reference)
    if reference["kind"] == "source":
        link = reference["link"]
        return {"kind": "source", "original_sha256": item["original_sha256"],
                "content_sha256": link["artifact"]["sha256"], "version_id": context.artifacts.link(link)["work"]["id"],
                "locator": _build_canonical_locator(link["locator"])}
    return {"kind": "result", "content_sha256": reference["artifact"]["sha256"],
            "locator": reference["locator"], "role": item["requirement_kind"]}


def _build_canonical_locator(value):
    if isinstance(value, dict):
        if {"path", "sha256", "size", "media_type"} <= value.keys():
            return {"content_sha256": value["sha256"]}
        return {key: _build_canonical_locator(item) for key, item in value.items() if key not in ("source_id", "capture_id")}
    if isinstance(value, list):
        return [_build_canonical_locator(item) for item in value]
    return value


def build_scientific_target(context, payload):
    """Canonical scientific content, never an independent support certificate."""
    limitations = {item["id"]: {"statement": _normalize_prose(item["statement"]),
                              "version_ids": sorted(set(item["version_ids"]))}
                   for item in payload["public_limitations"]}
    claims = [{"statement": _normalize_prose(c["statement"]), "polarity": c["polarity"],
               "assumptions": sorted({_normalize_prose(a) for a in c["assumptions"]}),
               "evidence": _build_scientific_set([_build_canonical_evidence(context, e) for e in c["evidence"]]),
               "limitations": _build_scientific_set([limitations[i] for i in c["limitation_ids"]])}
              for c in payload["supported_claims"]]
    return {"scope": {"statement": _normalize_prose(payload["scope"]["statement"]),
                      "assumptions": sorted({_normalize_prose(a) for a in payload["scope"]["assumptions"]})},
            "claims": _build_scientific_set(claims), "limitations": _build_scientific_set(list(limitations.values())),
            "source_debt": _build_scientific_set([{k: _normalize_prose(d[k]) if k != "version_id" else d[k]
                                                   for k in ("obligation", "version_id", "dependent_claim")}
                                                  for d in payload["deferred_objective_obligations"]])}


def build_scientific_scope_projection(payload):
    """Public text and exact evidence; private artifact descriptors never enter."""
    projection = {"policy": POLICY, "scope": payload["scope"], "claims": payload["supported_claims"],
                  "public_limitations": payload["public_limitations"], "objective_complete": False}
    return dict(projection, digest=digest(projection))


def _validate_payload(context, payload, candidate):
    fields(payload, ("id", "policy", "objective_digest", "checkpoint_id", "assessment_id", "assessment_digest",
                     "authorization", "scientific_preparers", "scope", "supported_claims", "public_limitations",
                     "deferred_objective_obligations", "correction"), ("scientific_delivery",), code=_CODE)
    text(payload["id"], "Contract ID", code=_CODE)
    if payload["policy"] != POLICY:
        raise ResearchError(_CODE, "Use the explicit source-limited-v1 policy")
    if (candidate is None or any(payload[k] != candidate[k] for k in ("checkpoint_id", "assessment_id"))
            or not context.verify_assessment_digest(payload["assessment_digest"], candidate["assessment_id"])):
        raise ResearchError("publication_scope_stale", "Bind the selected current assessment and checkpoint")
    if payload["objective_digest"] != digest(context.objective):
        raise ResearchError("publication_scope_stale", "Keep the exact original complete objective")
    if not context.artifacts.read(payload["authorization"]).strip():
        raise ResearchError(_CODE, "Pin the actual existing user directive")
    preparers = payload["scientific_preparers"]
    if not isinstance(preparers, list) or not preparers:
        raise ResearchError(_CODE, "Identify every scientific scope preparer")
    for preparer in preparers:
        fields(preparer, ("id", "kind", "provenance", "contributions"), code=_CODE)
        text(preparer["id"], "Scientific preparer", code=_CODE)
        if preparer["kind"] not in ("human", "agent") or not context.artifacts.read(preparer["provenance"]).strip():
            raise ResearchError(_CODE, "Identify a human or agent preparer with checked provenance")
        strings(preparer["contributions"], "Scientific contributions", nonempty=True, code=_CODE)
        if not set(preparer["contributions"]) <= {"claim_selection", "gap_classification", "scientific_correction"}:
            raise ResearchError(_CODE, "Declare scientific scope contributions")
    fields(payload["scope"], ("id", "statement", "assumptions"), code=_CODE)
    for key in ("id", "statement"):
        text(payload["scope"][key], "Supported scope " + key, code=_CODE)
    strings(payload["scope"]["assumptions"], "Supported assumptions", code=_CODE)
    assessment = context.assess_record(candidate["assessment_id"])
    if not set(assessment["payload"]["assumptions"]) <= set(payload["scope"]["assumptions"]):
        raise ResearchError("scope_assumptions_missing", "Retain the assessed scientific assumptions")
    limitations, claims = payload["public_limitations"], payload["supported_claims"]
    if not isinstance(limitations, list) or not limitations or not isinstance(claims, list) or not claims:
        raise ResearchError(_CODE, "Declare supported claims and public source limitations")
    limitation_ids = set()
    for item in limitations:
        fields(item, ("id", "statement", "version_ids"), code=_CODE)
        text(item["id"], "Limitation ID", code=_CODE)
        text(item["statement"], "Public scientific limitation", code=_CODE)
        strings(item["version_ids"], "Limited source versions", code=_CODE)
        if item["id"] in limitation_ids:
            raise ResearchError(_CODE, "Use unique limitation IDs")
        limitation_ids.add(item["id"])
    allowed = {digest(e) for e in candidate["evidence"]}
    seen = set()
    for claim in claims:
        fields(claim, ("id", "statement", "polarity", "assumptions", "evidence", "limitation_ids"), code=_CODE)
        for key in ("id", "statement"):
            text(claim[key], "Supported claim " + key, code=_CODE)
        if claim["id"] in seen or claim["polarity"] not in ("positive", "negative", "limitation"):
            raise ResearchError(_CODE, "Declare unique claims with explicit scientific polarity")
        seen.add(claim["id"])
        strings(claim["assumptions"], "Claim assumptions", code=_CODE)
        strings(claim["limitation_ids"], "Claim limitations", nonempty=True, code=_CODE)
        if not set(claim["limitation_ids"]) <= limitation_ids:
            raise ResearchError(_CODE, "Use declared public limitations")
        if not set(payload["scope"]["assumptions"]) <= set(claim["assumptions"]):
            raise ResearchError("scope_assumptions_missing", "Each claim retains the supported scope assumptions")
        _Evidence(context).many(claim["evidence"], "Supported claim evidence")
        if any(digest(e) not in allowed for e in claim["evidence"]):
            raise ResearchError("publication_evidence_mismatch", "Use actual current assessed candidate evidence")
    _validate_debt(context, payload, assessment)
    if "scientific_delivery" in payload:
        from .scientific_delivery import validate_declarations
        validate_declarations(payload["scientific_delivery"])


def _validate_debt(context, payload, assessment):
    mappings = payload["deferred_objective_obligations"]
    if not isinstance(mappings, list) or not mappings:
        raise ResearchError("publication_scope_debt_mismatch", "Map every remaining objective obligation exactly once")
    active = {d["id"]: d for d in assess_deferrals(context.records, context.artifacts) if d["status"] == "active"}
    seen = set()
    for mapping in mappings:
        fields(mapping, ("obligation", "deferral_id", "version_id", "dependency_digest", "dependent_claim", "reason"),
               code="publication_scope_debt_mismatch")
        for key in mapping:
            text(mapping[key], "Deferred objective " + key, code="publication_scope_debt_mismatch")
        deferred = active.get(mapping["deferral_id"])
        if (mapping["obligation"] in seen or deferred is None
                or any(mapping[k] != deferred[k] for k in ("version_id", "dependency_digest"))
                or mapping["dependent_claim"] not in deferred["dependent_claims"]):
            raise ResearchError("publication_scope_debt_mismatch", "Bind only an exact current active acquisition gap and retained dependent claim")
        seen.add(mapping["obligation"])
    disclosed = {v for item in payload["public_limitations"] for v in item["version_ids"]}
    if (seen != set(assessment["remaining_obligations"])
            or not {d["version_id"] for d in active.values()} <= disclosed
            or not {d["version_id"] for d in mappings} <= disclosed):
        raise ResearchError("publication_scope_debt_mismatch", "Cover the exact remaining obligation union and disclose every active source gap")
    if assessment["payload"]["objective_status"] != "open" or assessment["complete"]:
        raise ResearchError("publication_scope_objective_open", "Source-limited publication retains the incomplete original objective")


def _is_adverse(payload):
    return payload["verdict"] != "ready" or any(c["status"] != "passed" for c in payload["checks"])


def find_required_corrections(records):
    """The service derives the retained findings; selection never removes them."""
    result = []
    for kind in ("readiness_review", "scoped_readiness_review"):
        for review in records.get(kind, {}).values():
            payload = review["payload"]
            if not _is_adverse(payload):
                continue
            findings = [c["kind"] for c in payload["checks"] if c["status"] != "passed"]
            if payload["verdict"] != "ready":
                findings.append("verdict")
            target = review.get("scientific_target_digest")
            if target is None:
                candidate = review.get("candidate")
                target = candidate.get("digest") if isinstance(candidate, dict) else None
            if target is None:
                raise ResearchError("claim_reassessment_required", "Reassess the review whose original scientific target is unavailable.",
                                    {"record_id": review["id"], "missing_input": "recorded review candidate"})
            result.append({"kind": kind, "review_id": review["id"], "review_digest": digest(review),
                           "scientific_target_digest": target,
                           "findings": sorted(findings)})
    return sorted(result, key=lambda value: (value["kind"], value["review_id"]))


def _validate_correction(context, payload, projection, required):
    correction = payload["correction"]
    if not required:
        if correction is not None:
            raise ResearchError("publication_scope_correction_mismatch", "There are no predecessor findings to bridge")
        return []
    if correction is None:
        raise ResearchError("publication_scope_correction_required", "Respond to every retained adverse predecessor review",
                            {"required_corrections": required})
    fields(correction, ("response", "predecessors", "changes"), code="publication_scope_correction_mismatch")
    if any(not isinstance(correction[k], list) for k in ("predecessors", "changes")):
        raise ResearchError("publication_scope_correction_mismatch", "List every predecessor and exact scientific change")
    if not context.artifacts.read(correction["response"]).strip():
        raise ResearchError("publication_scope_correction_mismatch", "Pin the scientific response to predecessor findings")
    expected = {(r["kind"], r["review_id"]): r for r in required}
    seen, ancestors = set(), set()
    for item in correction["predecessors"]:
        fields(item, ("kind", "review_id", "review_digest", "scientific_target_digest", "findings"),
               code="publication_scope_correction_mismatch")
        key = item["kind"], item["review_id"]
        target = expected.get(key)
        if key in seen or target is None or any(item[k] != target[k] for k in ("review_digest", "scientific_target_digest")):
            raise ResearchError("publication_scope_correction_mismatch", "Bind each exact service-required predecessor review")
        seen.add(key)
        findings = set()
        for finding in item["findings"]:
            fields(finding, ("check", "response", "disposition", "evidence", "deferred_obligation"),
                   code="publication_scope_correction_mismatch")
            text(finding["response"], "Finding response", code=_CODE)
            if finding["check"] in findings or finding["check"] not in target["findings"]:
                raise ResearchError("publication_scope_correction_mismatch", "Address every adverse check exactly once")
            findings.add(finding["check"])
            if finding["disposition"] == "open_source_debt":
                if item["kind"] != "readiness_review" or finding["deferred_obligation"] not in {
                        d["obligation"] for d in payload["deferred_objective_obligations"]}:
                    raise ResearchError("publication_scope_correction_mismatch", "Only original full-objective findings may remain explicitly mapped source debt")
            elif finding["disposition"] != "addressed" or finding["deferred_obligation"] is not None:
                raise ResearchError("publication_scope_correction_mismatch", "Address scientific findings or retain exact full-objective source debt")
            _Evidence(context).many(finding["evidence"], "Correction finding evidence")
        if findings != set(target["findings"]):
            raise ResearchError("publication_scope_correction_mismatch", "Retain every predecessor finding")
        previous = context.records[item["kind"]][item["review_id"]]
        if strict_json(context.artifacts.read(previous["artifact"])) != previous["payload"]:
            raise ResearchError("publication_scope_correction_mismatch", "The predecessor review artifact differs from its immutable payload")
        if item["kind"] == "scoped_readiness_review":
            ancestors.add(previous["payload"]["target"]["contract_id"])
    if seen != set(expected):
        raise ResearchError("publication_scope_correction_mismatch", "A response cannot omit an adverse predecessor")
    changed_targets = set()
    for change in correction["changes"]:
        fields(change, ("predecessor_target", "field", "before", "after", "evidence"), code="publication_scope_correction_mismatch")
        targets = [r for r in required if r["scientific_target_digest"] == change["predecessor_target"]]
        if not targets or change["field"] not in projection:
            raise ResearchError("publication_scope_correction_mismatch", "Identify an exact changed scientific field")
        predecessor = targets[0]
        old_review = context.records[predecessor["kind"]][predecessor["review_id"]]
        old = old_review.get("scientific_projection", {})
        if (change["before"] != old.get(change["field"]) or change["after"] != projection[change["field"]]
                or change["before"] == change["after"]):
            raise ResearchError("publication_scope_correction_mismatch", "The correction must change the stated scientific field from its actual predecessor value")
        _Evidence(context).many(change["evidence"], "Scientific correction evidence")
        changed_targets.add(change["predecessor_target"])
    if changed_targets != {r["scientific_target_digest"] for r in required}:
        raise ResearchError("publication_scope_correction_mismatch", "Document scientific changes from every adverse predecessor target")
    return sorted(ancestors)


def collect_scientific_authors(records, contract):
    # Scope selection and explicit clearing do not erase scientific authorship
    # within the study, just as cycle selection does not erase cycle authors.
    authors, pending, visited = set(cycle_authors(records)), list(records.get("publication_scope", {}).values()) + [contract], set()
    while pending:
        current = pending.pop()
        if current["id"] in visited:
            continue
        visited.add(current["id"])
        authors.update(p["id"] for p in current["payload"]["scientific_preparers"])
        pending.extend(records["publication_scope"][i] for i in current.get("ancestor_contract_ids", []))
    return sorted(authors)


def record_publication_scope(store, payload, *, expected_revision, request_id):
    def prepare(records, value):
        context = _Context(records, store.build_artifact_store())
        context.require_objective()
        candidate, _ = context.build_candidate()
        _validate_payload(context, value, candidate)
        projection = build_scientific_target(context, value)
        required = find_required_corrections(records)
        ancestors = _validate_correction(context, value, projection, required)
        selected = find_publication_scope(records)
        if selected is not None:
            ancestors = sorted(set(ancestors + [selected["id"]]))
        saved = {"id": value["id"], "payload": value, "scientific_projection": projection,
                 "scientific_target_digest": digest(projection), "ancestor_contract_ids": ancestors,
                 "required_corrections": required, "public_projection": build_scientific_scope_projection(value)}
        saved["digest"] = digest(saved)
        if value["id"] in records.get("publication_scope", {}):
            raise ResearchError("record_conflict", "A scope ID cannot replace an immutable scientific contract")
        return [immutable_record(records, "publication_scope", value["id"], saved),
                ("publication_scope_selection", "current", {"id": value["id"]})], saved
    return prepared_mutation(store, "publication.scope", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def select_publication_scope(store, payload, *, expected_revision, request_id):
    def prepare(records, value):
        fields(value, ("id",), code=_CODE)
        if value["id"] is not None:
            text(value["id"], "Publication scope ID", code=_CODE)
        if value["id"] is not None and value["id"] not in records.get("publication_scope", {}):
            raise ResearchError("publication_scope_missing", "Select an existing immutable contract or null")
        return [("publication_scope_selection", "current", value)], value
    return prepared_mutation(store, "publication.select_scope", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def _load_scope_snapshot(records, artifacts, *, restore_inputs=None, include_dependencies=False, project_claims=False):
    context = _Context(records, artifacts, restore_inputs=restore_inputs, project_claims=project_claims)
    records, artifacts = context.records, context.artifacts
    candidate, _ = context.build_candidate()
    contract = find_publication_scope(records)
    if contract is None:
        raise ResearchError("publication_scope_missing", "Select an explicit immutable source-limited contract")
    _validate_payload(context, contract["payload"], candidate)
    projection = build_scientific_target(context, contract["payload"])
    if projection != contract["scientific_projection"] or digest(projection) != contract["scientific_target_digest"]:
        raise ResearchError("publication_scope_stale", "The contract no longer identifies its checked scientific evidence")
    current_findings = {(r["kind"], r["review_id"]): r for r in find_required_corrections(records)}
    for required in contract["required_corrections"]:
        if current_findings.get((required["kind"], required["review_id"])) != required:
            raise ResearchError("publication_scope_correction_mismatch", "The retained predecessor record differs from its immutable correction binding")
    _validate_correction(context, contract["payload"], projection, contract["required_corrections"])
    for required in current_findings.values():
        previous = records[required["kind"]][required["review_id"]]
        if strict_json(artifacts.read(previous["artifact"])) != previous["payload"]:
            raise ResearchError("publication_scope_correction_mismatch", "Retained adverse review bytes must match their immutable findings")
    dependencies = {"contract": contract["digest"], "candidate": candidate["digest"],
                    "prerequisites": context.prerequisites, "deferrals": assess_deferrals(records, artifacts)}
    observations, pending = {}, []
    for identifier in sorted({e["execution_id"] for e in candidate["evidence"] if e["kind"] == "result"}):
        if records["execution"][identifier]["payload"]["origin"]["kind"] == "managed":
            try:
                observations[identifier] = validate_observed_execution(records, artifacts, identifier)
            except ResearchError as error:
                pending.append(obligation(error.code, error.message, execution_id=identifier))
    dependencies["observations"] = observations
    result = (context, candidate, contract, digest(context.project_dependencies(dependencies)), observations, pending)
    return result + (dependencies,) if include_dependencies else result


def rebuild_scoped_dependencies(records, artifacts, candidate=None):
    evaluation = Evaluation.of(records, artifacts)
    records = evaluation.records
    key = ("scoped_dependencies", None if candidate is None else candidate["digest"],
           None if candidate is None else digest(candidate))
    return evaluation.compute_once_in_root(key, lambda: _rebuild_scoped_dependencies(records, evaluation, candidate))


def _rebuild_scoped_dependencies(records, artifacts, candidate=None):
    """Recover the complete composition at a recorded scoped-review snapshot."""
    from .evidence import digest
    legacy = candidate is not None and digest({key: value for key, value in candidate.items() if key != "digest"}) == candidate["digest"]
    restore = None if not legacy else {
        "dependencies": {"preparation": candidate["preparation_digest"], "constitution": candidate["constitution"]},
        "record_id": candidate["checkpoint_id"]}
    context, _, _, _, _, _, dependencies = _load_scope_snapshot(
        records, artifacts, restore_inputs=restore, include_dependencies=True, project_claims=True)
    if candidate is not None:
        context.rebuild_candidate(candidate, candidate["checkpoint_id"])
        dependencies = dict(dependencies, candidate=candidate["digest"])
    return dependencies


def _validate_scoped_review(context, value, candidate, contract, candidate_digest, *, assignment_id=None):
    from .publication import validate_assessor
    fields(value, ("id", "target", "candidate_digest", "assessor", "verdict", "checks", "limitations"), code=_CODE)
    text(value["id"], "Scoped review ID", code=_CODE)
    if (value["target"] != {"kind": "source_limited_manuscript", "contract_id": contract["id"],
                           "scientific_target_digest": contract["scientific_target_digest"]}
            or not context.verify_candidate_digest(value["candidate_digest"], candidate_digest, scoped=True,
                                                   record_id=value["id"], assignment_id=assignment_id)):
        raise ResearchError("scoped_review_stale", "Review the exact current scoped scientific target and freshness snapshot")
    validate_assessor(context.artifacts, value["assessor"], collect_scientific_authors(context.records, contract))
    if value["verdict"] not in ("ready", "not_ready", "unresolved"):
        raise ResearchError(_CODE, "Give an explicit scientific readiness verdict")
    strings(value["limitations"], "Review limitations", nonempty=True, code=_CODE)
    expected = set(_REVIEW_CHECKS) | {"source_limits"}
    if contract["required_corrections"]:
        expected.add("corrections")
    evidence, seen = _Evidence(context), set()
    for check in value["checks"]:
        fields(check, ("kind", "status", "reason", "evidence"), code=_CODE)
        if check["kind"] not in expected or check["kind"] in seen or check["status"] not in ("passed", "failed", "unresolved"):
            raise ResearchError(_CODE, "Assess each required scoped scientific check once")
        text(check["reason"], "Independent scientific reason", code=_CODE)
        seen.add(check["kind"])
        evidence.many(check["evidence"], "Scoped independent evidence")
    from .review_parts_study import validate_series_evidence
    for reference in validate_series_evidence(
            context.records, context.artifacts, assignment_id, candidate['evidence'],
            [item['reference'] for item in evidence.summary()]):
        evidence.one(reference)
    if seen != expected or not {digest(e) for e in candidate["evidence"]} <= {digest(e["reference"]) for e in evidence.summary()}:
        raise ResearchError("review_evidence_incomplete", "Independently assess every scientific check and candidate evidence reference")


def prepare_combined_scoped_support(records, artifacts, payload, *, revision, request_id, assignment_id=None):
    """Prepare scoped support and its pure report for one combined review commit."""
    context, candidate, contract, exact, _, _ = _load_scope_snapshot(records, Evaluation.of(records, artifacts))
    _validate_scoped_review(context, payload, candidate, contract, exact, assignment_id=assignment_id)
    artifact = context.artifacts.put(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode(), "application/json")
    saved = {"id": payload["id"], "payload": payload, "artifact": artifact, "candidate": candidate,
             "scientific_target_digest": contract["scientific_target_digest"],
             "scientific_projection": contract["scientific_projection"], "reviewed_revision": revision}
    if assignment_id is not None and 'review_parts' in records['review_assignment'][assignment_id]:
        saved['assignment_id'] = assignment_id
    if payload["candidate_digest"] in context.candidate_inputs:
        saved["candidate_inputs"] = context.candidate_inputs[payload["candidate_digest"]]
    changes = [immutable_record(records, "scoped_readiness_review", payload["id"], saved),
               ("scoped_review_selection", contract["id"], {"id": payload["id"]})]
    prospective = records.copy()
    for kind, key, value in changes:
        prospective[kind] = dict(prospective.get(kind, {}), **{key: value})
    report = assess_manuscript_readiness(prospective, artifacts)
    return changes, report


def record_scoped_readiness_review(store, payload, *, expected_revision, request_id):
    def prepare(records, value):
        changes, _ = prepare_combined_scoped_support(records, store.build_artifact_store(), value,
                                                    revision=expected_revision + 1, request_id=request_id)
        return changes, changes[0][2]
    return prepared_mutation(store, "publication.scoped_review", payload, prepare,
                             expected_revision=expected_revision, request_id=request_id)


def assess_manuscript_readiness(records, artifacts, *, restore_inputs=None):
    evaluation = Evaluation.of(records, artifacts)
    records = evaluation.records
    key = ("manuscript_readiness", None if restore_inputs is None else digest(restore_inputs))
    return evaluation.once(key, lambda: _assess_manuscript_readiness(records, evaluation, restore_inputs=restore_inputs))


def _assess_manuscript_readiness(records, artifacts, *, restore_inputs=None):
    artifacts = Evaluation.of(records, artifacts)
    full = author_readiness_state(records, artifacts, restore_inputs=restore_inputs)
    obligations, contract, exact, observations, review = [], None, None, {}, None
    candidate = full["candidate"]
    remaining = []
    required_corrections = []
    try:
        required_corrections = find_required_corrections(records)
        contract = find_publication_scope(records)
        context, candidate, contract, exact, observations, pending = _load_scope_snapshot(records, artifacts, restore_inputs=restore_inputs)
        assessment = context.assess_record(candidate["assessment_id"])
        remaining = assessment["remaining_obligations"]
        obligations.extend(context.prerequisites["validity"] + context.prerequisites["workflow"] + pending)
        for cycle in records.get("cycle", {}).values():
            if cycle["assessment_id"] is None:
                obligations.append(obligation("development_assessment_missing", "Assess every retained actual branch", cycle_id=cycle["id"]))
        current_target = contract["scientific_target_digest"]
        adverse = [r for r in records.get("scoped_readiness_review", {}).values()
                   if r["scientific_target_digest"] == current_target and _is_adverse(r["payload"])]
        if adverse:
            obligations.append(obligation("scoped_target_rejected", "A retained adverse review blocks this identical scientific target",
                                          review_ids=sorted(r["id"] for r in adverse)))
        owed = [r for r in find_required_corrections(records) if r["scientific_target_digest"] != current_target]
        if owed != contract["required_corrections"]:
            obligations.append(obligation("publication_scope_correction_required", "Bind all newly retained predecessor findings in a new immutable correction"))
        selection = records.get("scoped_review_selection", {}).get(contract["id"])
        if selection is None:
            obligations.append(obligation("scoped_review_missing", "Obtain an independent assessment of this supported manuscript target"))
        else:
            review = records["scoped_readiness_review"][selection["id"]]
            if strict_json(artifacts.read(review["artifact"])) != review["payload"]:
                raise ResearchError("scoped_review_corrupt", "The current independent review artifact differs from its immutable payload")
            _validate_scoped_review(context, review["payload"], candidate, contract, exact,
                                    assignment_id=review.get('assignment_id'))
            if _is_adverse(review["payload"]):
                obligations.append(obligation("scoped_review_pending", "Resolve the scientific finding through a substantively corrected target"))
    except ResearchError as error:
        obligations.append(obligation(error.code, error.message, **(error.details or {})))
    obligations = _unique(obligations)
    result = {"ready": not obligations, "manuscript_ready": not obligations, "manuscript_obligations": obligations,
              "obligations": obligations, "objective_complete": full["ready"], "objective_obligations": full["obligations"],
              "remaining_obligations": remaining, "contract": contract, "candidate": candidate, "candidate_digest": exact,
              "selected_contract_id": records.get("publication_scope_selection", {}).get("current", {}).get("id"),
              "required_corrections": required_corrections,
              "scientific_target_digest": contract["scientific_target_digest"] if contract else None,
              "review": review, "review_inputs": full["review_inputs"], "execution_observations": observations,
              "source_gaps": build_source_gap_disclosure((full.get("synthesis") or {}).get("foundation", {}).get("source_deferrals", [])),
              "mechanical_only": True, "native_proof_acceptance": False}
    result["counts"] = {"cycles": len(records.get("cycle", {})), "obligations": len(obligations)}
    return result


def build_manuscript_readiness_report(store):
    snapshot = store.snapshot()
    return dict(assess_manuscript_readiness(snapshot["records"], store.build_artifact_store()),
                revision=snapshot["revision"])


def validate_manuscript_claims(contract, claims, claim_evidence):
    """The current claims equal the approved claims exactly; continuity markers are round metadata.

    A `revised` marker records the earlier wording of an approved claim and a
    `superseded` claim is a withdrawn opening claim that the scope no longer
    supports, so neither takes part in the comparison with the contract.
    `prepare_publication`, the only caller, has already validated the marker
    shapes, unique ids and the evidence mapping of every claim."""
    payload = contract["payload"]
    expected = [{"id": c["id"], "claim": c["statement"], "polarity": c["polarity"],
                 "assumptions": c["assumptions"], "limitation_ids": c["limitation_ids"],
                 "public_limitations": [l for l in payload["public_limitations"] if l["id"] in c["limitation_ids"]]}
                for c in payload["supported_claims"]]
    mappings = [{"claim_id": c["id"], "evidence": c["evidence"]} for c in payload["supported_claims"]]
    withdrawn = {c["id"] for c in claims if "superseded" in c}
    current = [{key: value for key, value in c.items() if key != "revised"} for c in claims if c["id"] not in withdrawn]
    links = [link for link in claim_evidence if link["claim_id"] not in withdrawn]
    if _sort_canonically(current) != _sort_canonically(expected) or _sort_canonically(links) != _sort_canonically(mappings):
        raise ResearchError("publication_scope_claim_mismatch", "The manuscript must retain every exact approved claim, polarity, assumption, evidence mapping and public limitation")


def build_publication_scope_binding(bundle):
    scope = bundle.get("publication_scope")
    return ({key: scope[key] for key in ("mode", "contract_id", "scientific_target_digest", "objective_complete")}
            if scope is not None else None)


def validate_expected_scope(store, contract_id, target_digest):
    records = store.snapshot()["records"]
    contract = find_publication_scope(records)
    if contract is None:
        raise ResearchError("publication_scope_missing", "Strict scoped publication requires its selected contract")
    if contract["id"] != contract_id or contract["scientific_target_digest"] != target_digest:
        raise ResearchError("publication_scope_mismatch", "The selected scientific contract differs from the caller's explicit publication target")
    report = assess_manuscript_readiness(records, store.build_artifact_store())
    if not report["manuscript_ready"]:
        raise ResearchError("manuscript_readiness_required", "The scoped scientific target is not currently ready",
                            {"obligations": report["manuscript_obligations"]})


def validate_scope_binding(bundle, expected):
    if build_publication_scope_binding(bundle) != expected:
        raise ResearchError("publication_scope_mismatch", "The current bundle differs from the publication intent's exact scientific scope")


def validate_caller_scope(binding, contract_id, target_digest):
    if contract_id is not None or target_digest is not None:
        if binding is None or binding.get("contract_id") != contract_id or binding.get("scientific_target_digest") != target_digest:
            raise ResearchError("publication_scope_mismatch", "The publication intent differs from the caller's explicit contract and scientific target")

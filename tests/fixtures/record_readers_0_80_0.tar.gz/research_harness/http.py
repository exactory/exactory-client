"""Bounded HTTPS GETs with pinned public destinations and evidence of each attempt.

HttpClient(...).get(url, *, headers=None, accept=(), budget=None,
                    not_before=None) returns Fetch
or raises HttpFailure. Both expose attempts: [{url, captured_at, status, headers,
body: bytes, complete: bool, error: code | None, response_received_at,
next_eligible_at}]. Receipt and eligibility are UTC ISO timestamps or None.
Retry-After eligibility is recorded before a request budget can stop retries.
not_before restores persisted eligibility. Waiting counts against total_timeout;
waits beyond max_retry_after or the remaining deadline fail with rate_limited
before DNS, budget consumption or a new attempt. An expired eligibility adds no
wait. No request headers, cookies or credential URLs enter attempt evidence.
`complete` describes the response transfer, not article availability.
HttpFailure.as_dict() excludes binary attempt bodies.

Injection: transport(url, headers, *, address, timeout) -> RawResponse; it must
connect only to address, validate TLS for the URL hostname, perform no redirects
or retries, and expose its actual peer_ip. resolver(host, timeout) -> [numeric IP]
must finish within timeout. clock supplies now() (ISO UTC), monotonic(), sleep(s).
The default transport also bounds header/body reads by an absolute deadline.
RequestBudget counts EVERY attempted resolution/connection, redirect and retry.
"""

import http.client
import io
import ipaddress
import math
import queue
import re
import socket
import ssl
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import parse_qsl, urljoin, urlsplit, urlunsplit

from .errors import ResearchError
from .provider_pacing import ProviderPacing


_SECRET = re.compile(r"(^|[-_])(key|token|secret|password|sig|signature|credential|authorization)($|[-_])", re.I)
_COMPACT_SECRET_NAMES = {"apikey", "accesskey", "accesskeyid", "accesstoken", "authtoken", "authentication",
                         "bearertoken", "clientsecret", "clientkey", "refreshtoken", "sessiontoken", "subscriptionkey"}
_SAFE_HEADERS = {"content-type", "content-length", "content-range", "content-encoding", "retry-after", "etag", "last-modified", "date"}
_RETRY = {408, 429, 500, 502, 503, 504}
# Largest response body kept in memory; arXiv PDFs with many figures exceed 32 MiB.
DEFAULT_MAX_RESPONSE_BYTES = 128 * 1024 * 1024
# Supplement older Python IANA tables. Protocol, translation and deprecated
# prefixes are conservatively outside the untrusted literature download scope.
_SPECIAL_NETWORKS = tuple(ipaddress.ip_network(value) for value in (
    "192.0.0.0/24", "192.88.99.0/24", "::/96", "64:ff9b::/96", "64:ff9b:1::/48",
    "100::/64", "100:0:0:1::/64", "2001::/23", "3ffe::/16", "3fff::/20", "5f00::/16", "fec0::/10"))


def public_address(value):
    try:
        if not isinstance(value, str) or "%" in value:
            raise ValueError()
        address = ipaddress.ip_address(value)
    except ValueError as error:
        raise ResearchError("unsafe_destination", "Destination is not a numeric public IP address") from error
    if (not address.is_global or address.is_multicast or address.is_unspecified
            or any(address in network for network in _SPECIAL_NETWORKS if address.version == network.version)
            or getattr(address, "ipv4_mapped", None) is not None
            or getattr(address, "sixtofour", None) is not None
            or getattr(address, "teredo", None) is not None):
        raise ResearchError("unsafe_destination", "Destination is not a public unicast address")
    return str(address)


def safe_url(value):
    """Validate an untrusted URL without DNS or retaining credential values."""
    try:
        if (not isinstance(value, str) or not value or len(value) > 16384
                or any(ord(c) <= 32 or ord(c) >= 127 for c in value) or "\\" in value):
            raise ValueError()
        parts = urlsplit(value)
        if (parts.scheme != "https" or not parts.hostname or parts.username is not None
                or parts.password is not None or parts.fragment or parts.port not in (None, 443)):
            raise ValueError()
        host = parts.hostname
        if "%" in host or host.endswith(".") or host.lower() in ("localhost", "localhost.localdomain"):
            raise ValueError()
        for key, _ in parse_qsl(parts.query, keep_blank_values=True):
            compact = re.sub(r"[-_]", "", key).lower()
            if _SECRET.search(key) or compact in _COMPACT_SECRET_NAMES or key.lower().startswith(("x-amz-", "x-goog-")):
                raise ValueError()
        try:
            ipaddress.ip_address(host)
        except ValueError:
            if not re.fullmatch(r"[A-Za-z0-9.-]+", host) or any(not p or len(p) > 63 for p in host.split(".")):
                raise ValueError()
        else:
            public_address(host)
        return urlunsplit(("https", parts.netloc.lower(), parts.path or "/", parts.query, ""))
    except (ValueError, ResearchError) as error:
        raise ResearchError("unsafe_url", "Expected a public HTTPS URL without credentials or fragments") from error


class SystemClock:
    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def monotonic(self):
        return time.monotonic()

    def sleep(self, seconds):
        time.sleep(seconds)


class RequestBudget:
    def __init__(self, maximum=None):
        if maximum is not None and (type(maximum) is not int or maximum < 0):
            raise ResearchError("invalid_input", "max_requests must be a nonnegative integer or null")
        self.maximum = maximum
        self.used = 0

    def check(self):
        if self.maximum is not None and self.used >= self.maximum:
            raise ResearchError("request_budget", "The HTTP attempt budget is exhausted; resume with a new operation")

    def consume(self):
        self.check()
        self.used += 1


@dataclass
class RawResponse:
    status: int
    headers: dict
    stream: object
    peer_ip: str
    close_connection: object = None

    def close(self):
        try:
            self.stream.close()
        finally:
            if self.close_connection:
                self.close_connection()


@dataclass
class Fetch:
    url: str
    status: int
    headers: dict
    body: bytes
    attempts: list = field(default_factory=list)


@dataclass
class StreamFetch:
    url: str
    status: int
    headers: dict
    response: dict
    attempts: list = field(default_factory=list)


class _StreamingReader:
    """Finish artifact publication of a failed attempt's bounded prefix."""

    def __init__(self, source, clock, deadline, maximum, limit_code):
        self.source, self.clock, self.deadline = source, clock, deadline
        self.maximum, self.limit_code = maximum, limit_code
        self.size, self.error = 0, None

    def read(self, amount):
        if self.error is not None:
            return b""
        try:
            if self.clock.monotonic() >= self.deadline:
                raise socket.timeout()
            chunk = self.source.read(min(amount, 65536, self.maximum + 1 - self.size))
        except http.client.IncompleteRead as error:
            chunk, self.error = error.partial, error
        except (OSError, http.client.HTTPException) as error:
            self.error = error
            return b""
        if not isinstance(chunk, bytes) or len(chunk) > amount:
            self.error = ResearchError("invalid_input", "Expected a bounded binary response stream")
            return b""
        room = self.maximum - self.size
        if len(chunk) > room:
            chunk = chunk[:room]
            self.error = ResearchError(self.limit_code, "Response exceeds the configured byte allowance")
        self.size += len(chunk)
        return chunk


class HttpFailure(ResearchError):
    def __init__(self, code, message, attempts, details=None):
        super().__init__(code, message, details)
        self.attempts = attempts


def _retry_after_time(value, received_at):
    if not value:
        return None
    try:
        if re.fullmatch(r"[0-9]+", value.strip()):
            eligible = datetime.fromisoformat(received_at) + timedelta(seconds=int(value))
        else:
            eligible = parsedate_to_datetime(value)
        if eligible.utcoffset() is None:
            return None
        return eligible.astimezone(timezone.utc).isoformat()
    except (ValueError, TypeError, OverflowError):
        return None


def _resolve(host, timeout):
    # getaddrinfo has no timeout argument. A daemon confines a stalled resolver's
    # effect to this call's finite wait; it never holds a store transaction.
    result = queue.Queue(maxsize=1)

    def run():
        try:
            result.put((socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM), None))
        except OSError as error:
            result.put((None, error))

    threading.Thread(target=run, daemon=True).start()
    try:
        addresses, error = result.get(timeout=timeout)
    except queue.Empty as error:
        raise socket.timeout() from error
    if error:
        raise error
    return sorted({item[4][0] for item in addresses})


class _DeadlineReader(io.RawIOBase):
    def __init__(self, sock, clock, deadline, timeout):
        self.sock, self.clock, self.deadline, self.timeout = sock, clock, deadline, timeout

    def readable(self):
        return True

    def readinto(self, buffer):
        remaining = self.deadline - self.clock.monotonic()
        if remaining <= 0:
            raise socket.timeout()
        self.sock.settimeout(min(self.timeout, remaining))
        return self.sock.recv_into(buffer)


class _ResponseSocket:
    def __init__(self, sock, clock, deadline, timeout):
        self.sock, self.clock, self.deadline, self.timeout = sock, clock, deadline, timeout

    def makefile(self, mode):
        return io.BufferedReader(_DeadlineReader(self.sock, self.clock, self.deadline, self.timeout))


class _PinnedConnection(http.client.HTTPSConnection):
    def __init__(self, host, address, timeout, clock):
        super().__init__(host, timeout=timeout, context=ssl.create_default_context())
        self.address, self.clock = address, clock
        self.deadline = clock.monotonic() + timeout
        self.response_class = lambda sock, **kw: http.client.HTTPResponse(
            _ResponseSocket(sock, clock, self.deadline, timeout), **kw)

    def connect(self):
        family = socket.AF_INET6 if ":" in self.address else socket.AF_INET
        raw = socket.socket(family, socket.SOCK_STREAM)
        try:
            raw.settimeout(max(0.001, self.deadline - self.clock.monotonic()))
            raw.connect((self.address, self.port))
            if public_address(raw.getpeername()[0]) != self.address:
                raise ResearchError("unsafe_destination", "Connected peer differs from the approved address")
            raw.settimeout(max(0.001, self.deadline - self.clock.monotonic()))
            self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        except BaseException:
            raw.close()
            raise


class HttpClient:
    def __init__(self, *, transport=None, resolver=None, clock=None, timeout=30,
                 total_timeout=120, max_bytes=DEFAULT_MAX_RESPONSE_BYTES, max_redirects=5,
                 max_retries=2, max_retry_after=60, user_agent=None, pacing=None):
        for number in (timeout, total_timeout, max_retry_after):
            if not isinstance(number, (float, int)) or not math.isfinite(number) or number <= 0:
                raise ResearchError("invalid_input", "HTTP time limits must be positive and finite")
        for number in (max_bytes, max_redirects, max_retries):
            if type(number) is not int or number < 0:
                raise ResearchError("invalid_input", "HTTP bounds must be nonnegative integers")
        self.clock = clock or SystemClock()
        self.transport = transport or self._open
        self.resolver = resolver or _resolve
        self.timeout, self.total_timeout, self.max_bytes = timeout, total_timeout, max_bytes
        self.max_redirects, self.max_retries = max_redirects, max_retries
        from .provenance import plugin_version
        self.max_retry_after = max_retry_after
        self.user_agent = user_agent or "exactory-research/" + plugin_version()
        self.pacing = pacing if pacing is not None else ProviderPacing(clock=self.clock)

    def _open(self, url, headers, *, address, timeout):
        parts = urlsplit(url)
        connection = _PinnedConnection(parts.hostname, address, timeout, self.clock)
        try:
            connection.connect()
            peer = connection.sock.getpeername()[0]
            connection.request("GET", urlunsplit(("", "", parts.path, parts.query, "")), headers=headers)
            response = connection.getresponse()
            return RawResponse(response.status, dict(response.getheaders()), response, peer, connection.close)
        except BaseException:
            connection.close()
            raise

    def pace_from(self, host, captured_at):
        """Apply persisted pacing across separate collection invocations."""
        url = safe_url("https://" + host + "/")
        try:
            captured = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
            if captured.utcoffset() is None:
                raise ValueError()
            from .provider_pacing import group_provider
            interval = self.pacing.intervals.get(group_provider(url), 0.0)
            eligible = (captured + timedelta(seconds=interval)).isoformat()
        except (AttributeError, TypeError, ValueError, OverflowError) as error:
            raise ResearchError("invalid_input", "Pacing time must be an ISO timestamp with timezone") from error
        self.pacing.defer_until(url, eligible, deadline=self.clock.monotonic() + self.total_timeout,
                                max_wait=self.max_retry_after, pacing=True)

    def _delay(self, seconds, deadline):
        if self.clock.monotonic() + seconds >= deadline:
            raise ResearchError("timeout", "HTTP operation exceeded its total time limit")
        if seconds > 0:
            self.clock.sleep(seconds)

    def _wait_until(self, eligible_at, deadline, url):
        if eligible_at is None:
            return
        try:
            eligible = datetime.fromisoformat(eligible_at.replace("Z", "+00:00"))
            if eligible.utcoffset() is None:
                raise ValueError()
            delay = max(0.0, (eligible - datetime.fromisoformat(self.clock.now())).total_seconds())
        except (TypeError, ValueError, AttributeError) as error:
            raise ResearchError("invalid_input", "Request eligibility must be an ISO timestamp with timezone") from error
        if delay > self.max_retry_after or self.clock.monotonic() + delay >= deadline:
            from .provider_pacing import group_provider
            raise ResearchError("rate_limited", "The next eligible request exceeds this call's wait allowance",
                                {"provider_group": group_provider(url), "next_eligible_at": eligible_at,
                                 "retry_after_seconds": delay})
        self._delay(delay, deadline)

    def _retry_delay(self, headers, retry):
        value = headers.get("retry-after")
        if value:
            try:
                delay = float(value)
            except ValueError:
                try:
                    delay = (parsedate_to_datetime(value) - datetime.fromisoformat(self.clock.now())).total_seconds()
                except (ValueError, TypeError, OverflowError):
                    delay = 2 ** retry
            if not math.isfinite(delay):
                delay = self.max_retry_after + 1
            if delay > self.max_retry_after:
                raise ResearchError("rate_limited", "Provider Retry-After exceeds this call's wait limit",
                                    {"retry_after_seconds": delay})
            return max(0.0, delay)
        return float(2 ** retry)

    def get(self, url, *, headers=None, accept=(), budget=None, not_before=None):
        return self._get(url, headers=headers, accept=accept, budget=budget, not_before=not_before)

    def get_stream(self, url, artifacts, *, max_bytes, max_retained_bytes, total_timeout,
                   headers=None, accept=(), budget=None, not_before=None, validate_response=None):
        """Retain attempts as artifacts; an optional validator admits partial responses.

        validate_response(url, status, headers) runs before reading a successful
        body and returns its exact length, or None for a complete response of
        unknown length. Retained prefixes, redirects and retries share the byte
        allowance. The caller supplies finite job allowances, independently of
        the legacy in-memory bound. Attempts use response refs instead of body.
        """
        for number in (max_bytes, max_retained_bytes):
            if type(number) is not int or number < 0:
                raise HttpFailure("invalid_input", "Stream byte allowances must be nonnegative integers", [])
        if type(total_timeout) not in (float, int) or not math.isfinite(total_timeout) or total_timeout <= 0:
            raise HttpFailure("invalid_input", "Stream time allowance must be positive and finite", [])
        return self._get(url, headers=headers, accept=accept, budget=budget, not_before=not_before,
                         artifacts=artifacts, max_bytes=max_bytes, max_retained_bytes=max_retained_bytes,
                         total_timeout=total_timeout, validate_response=validate_response)

    def _get(self, url, *, headers=None, accept=(), budget=None, not_before=None, artifacts=None,
             max_bytes=None, max_retained_bytes=None, total_timeout=None, validate_response=None):
        budget = budget if budget is not None else RequestBudget()
        attempts, redirects, retries = [], 0, 0
        streaming = artifacts is not None
        maximum = self.max_bytes if not streaming else max_bytes
        retained = 0
        retained_refs = set()
        deadline = self.clock.monotonic() + (self.total_timeout if total_timeout is None else total_timeout)
        request_headers = {"User-Agent": self.user_agent, "Accept-Encoding": "identity"}
        request_headers.update(headers or {})
        if any(not isinstance(k, str) or not isinstance(v, str) or re.search(r"[\x00-\x1f\x7f]", k + v)
               for k, v in request_headers.items()):
            raise HttpFailure("invalid_input", "HTTP headers cannot contain control characters", [])
        try:
            url = safe_url(url)
            if not_before is not None:
                self.pacing.defer_until(url, not_before, deadline=deadline, max_wait=self.max_retry_after)
            while True:
                budget.check()
                self._wait_until(not_before, deadline, url)
                host = urlsplit(url).hostname
                with self.pacing.admit(url, deadline=deadline, max_wait=self.max_retry_after):
                    budget.consume()
                    attempt = {"url": url, "captured_at": self.clock.now(), "status": None,
                               "headers": {}, "body": b"", "complete": False, "error": None,
                               "response_received_at": None, "next_eligible_at": None}
                    if streaming:
                        del attempt["body"]
                        attempt["response"] = None
                    attempts.append(attempt)
                    response = None
                    body = bytearray()
                    try:
                        remaining = min(self.timeout, deadline - self.clock.monotonic())
                        if remaining <= 0:
                            raise socket.timeout()
                        addresses = [public_address(item) for item in self.resolver(host, remaining)]
                        if not addresses:
                            raise socket.gaierror()
                        address = addresses[retries % len(addresses)]
                        response = self.transport(url, request_headers, address=address,
                                                  timeout=min(self.timeout, deadline - self.clock.monotonic()))
                        if public_address(response.peer_ip) != address:
                            raise ResearchError("unsafe_destination", "Connected peer differs from the approved address")
                        all_headers = {k.lower(): str(v) for k, v in response.headers.items()}
                        attempt["headers"] = {k: v for k, v in all_headers.items() if k in _SAFE_HEADERS}
                        attempt["status"] = response.status
                        attempt["response_received_at"] = self.clock.now()
                        attempt["next_eligible_at"] = _retry_after_time(all_headers.get("retry-after"), attempt["response_received_at"])
                        if attempt["next_eligible_at"] is not None:
                            self.pacing.defer_until(url, attempt["next_eligible_at"], deadline=deadline,
                                                    max_wait=self.max_retry_after)
                            not_before = max((time for time in (not_before, attempt["next_eligible_at"]) if time is not None),
                                             key=lambda time: datetime.fromisoformat(time.replace("Z", "+00:00")))
                        length = all_headers.get("content-length")
                        if length is not None:
                            try:
                                if not length.isascii() or not length.isdigit() or int(length) > maximum:
                                    raise ValueError()
                            except ValueError as error:
                                raise ResearchError("response_too_large", "Response length exceeds the configured bound or is invalid") from error
                        if all_headers.get("content-encoding", "identity").lower() != "identity":
                            raise ResearchError("unsupported_encoding", "Response ignored the identity encoding request")
                        expected_length = int(length) if length is not None else None
                        if streaming:
                            if 200 <= response.status < 300:
                                if validate_response is not None:
                                    expected_length = validate_response(url, response.status, attempt["headers"])
                                elif response.status == 206 or "content-range" in all_headers:
                                    raise ResearchError("partial_response", "A partial response requires a transfer validator")
                            available = max_retained_bytes - retained
                            if length is not None and int(length) > available:
                                raise ResearchError("fulltext_storage_limit", "Response exceeds the retained-byte allowance")
                            body_maximum = min(maximum, available)
                            limit_code = "fulltext_storage_limit" if available < maximum else "response_too_large"
                            if response.status == 206 and expected_length is not None and expected_length <= body_maximum:
                                body_maximum, limit_code = expected_length, "fulltext_transfer_changed"
                            reader = _StreamingReader(response.stream, self.clock, deadline, body_maximum, limit_code)
                            from .evidence import media_type
                            attempt["response"] = artifacts.put_stream(reader, media_type(attempt["headers"]))
                            if attempt["response"]["sha256"] not in retained_refs:
                                retained += reader.size
                                retained_refs.add(attempt["response"]["sha256"])
                            if reader.error is not None:
                                if isinstance(reader.error, http.client.IncompleteRead):
                                    raise http.client.IncompleteRead(b"") from reader.error
                                raise reader.error
                            body_size = reader.size
                        else:
                            while True:
                                if self.clock.monotonic() >= deadline:
                                    raise socket.timeout()
                                chunk = response.stream.read(min(65536, maximum + 1 - len(body)))
                                if not chunk:
                                    break
                                room = maximum - len(body)
                                body.extend(chunk[:room])
                                if len(chunk) > room:
                                    raise ResearchError("response_too_large", "Response exceeds the configured byte limit")
                            body_size = len(body)
                        if self.clock.monotonic() >= deadline:
                            raise socket.timeout()
                        if expected_length is not None and body_size != expected_length:
                            raise ResearchError("incomplete_response", "Response ended before its declared length")
                        attempt["complete"] = True
                    except (socket.timeout, TimeoutError) as error:
                        attempt["error"] = "timeout"
                        if retries >= self.max_retries:
                            raise ResearchError("timeout", "HTTP operation timed out") from error
                    except http.client.IncompleteRead as error:
                        room = self.max_bytes - len(body)
                        body.extend(error.partial[:room])
                        attempt["complete"] = False
                        attempt["error"] = "response_too_large" if len(error.partial) > room else "incomplete_response"
                        if len(error.partial) > room:
                            raise ResearchError("response_too_large", "Partial response exceeds the configured byte limit") from error
                        if retries >= self.max_retries:
                            raise ResearchError("incomplete_response", "HTTP response ended before its body was complete") from error
                    except (OSError, http.client.HTTPException) as error:
                        attempt["error"] = "network_error"
                        if retries >= self.max_retries:
                            raise ResearchError("network_error", "HTTP connection or response failed") from error
                    except ResearchError as error:
                        attempt["error"] = error.code
                        raise
                    finally:
                        if not streaming:
                            attempt["body"] = bytes(body)
                        if response is not None:
                            response.close()
                if attempt["error"]:
                    budget.check()
                    if attempt["next_eligible_at"] is not None:
                        self._wait_until(not_before, deadline, url)
                    else:
                        self._delay(float(2 ** retries), deadline)
                    retries += 1
                    continue
                status = attempt["status"]
                if not streaming and (status == 206 or "content-range" in attempt["headers"]):
                    raise ResearchError("partial_response", "A partial HTTP response cannot satisfy full source capture")
                if status in (301, 302, 303, 307, 308):
                    if redirects >= self.max_redirects:
                        raise ResearchError("redirect_limit", "HTTP redirect limit reached")
                    location = all_headers.get("location")
                    if not location:
                        raise ResearchError("invalid_redirect", "Redirect omitted its destination")
                    target = safe_url(urljoin(url, location))
                    if urlsplit(target).netloc != urlsplit(url).netloc:
                        request_headers = {k: v for k, v in request_headers.items()
                                           if k.lower() in ("user-agent", "accept", "accept-encoding")}
                    url, redirects = target, redirects + 1
                    continue
                if status in _RETRY and retries < self.max_retries:
                    budget.check()
                    if attempt["next_eligible_at"] is not None:
                        self._wait_until(not_before, deadline, url)
                    else:
                        self._delay(self._retry_delay(attempt["headers"], retries), deadline)
                    retries += 1
                    continue
                if status < 200 or status >= 300:
                    code = "rate_limited" if status == 429 else "http_status"
                    raise ResearchError(code, "Provider returned an unsuccessful HTTP status", {"status": status})
                media_type = attempt["headers"].get("content-type", "application/octet-stream").split(";")[0].lower().strip()
                if accept and media_type not in accept:
                    raise ResearchError("unexpected_mime", "Provider returned an unexpected media type", {"media_type": media_type})
                if streaming:
                    return StreamFetch(url, status, attempt["headers"], attempt["response"], attempts)
                return Fetch(url, status, attempt["headers"], attempt["body"], attempts)
        except ResearchError as error:
            if attempts and attempts[-1]["error"] is None:
                attempts[-1]["error"] = error.code
            raise HttpFailure(error.code, error.message, attempts, error.details) from error

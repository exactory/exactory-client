"""Sampled verification preparation (sampled-v1): a stratified random sample of the population,
placement judgments, the percentile prediction, and the verification limits."""

import math
import random

from .depth import find_current_depth_plan, resolve_depth_value, resolve_depth_values
from .errors import ResearchError
from .evidence import digest
from .graph import find_active_requirements, obligation
from .operations import fields, immutable_record, prepared_mutation, text
from .principles import preparation_policy

SAMPLED = "sampled-v1"
SAMPLE_LIMIT = 100
SEARCH_READING_LIMIT = 20
CORE_LIMIT = 10
UNPLACED_WIDEN = 20
POSITIONS = ("above", "below", "unplaced")


def resolve_sample_limit(records):
    return resolve_depth_value(records, "sample_size", SAMPLE_LIMIT)


def resolve_search_reading_limit(records):
    return resolve_depth_value(records, "search_readings", SEARCH_READING_LIMIT)


def resolve_core_limit(records):
    return resolve_depth_value(records, "core_fulltexts", CORE_LIMIT)


def core_requirements(records, profile="verification"):
    """Fulltext requirements with purpose core under the requested profile."""
    return sorted((r for r in find_active_requirements(records).values()
                   if r["profile"] == profile and r["purpose"] == "core"), key=lambda r: r["id"])


def _require_sampled(records):
    if preparation_policy(records) != SAMPLED:
        raise ResearchError("policy_inapplicable", "Sample records belong to the sampled-v1 preparation policy",
                            {"policy": preparation_policy(records)})


def draw(members, size, seed):
    """A deterministic stratified sample: equal allocation per month, a short month's shortfall
    passed to the next months, and the whole population when it fits within size."""
    by_month = {}
    for item in sorted(members, key=lambda m: (m["month"], m["work_id"])):
        by_month.setdefault(item["month"], []).append(item)
    if len(members) <= size:
        return [dict(m) for month in sorted(by_month) for m in by_month[month]]
    rng = random.Random(seed)
    for month in sorted(by_month):
        rng.shuffle(by_month[month])
    months = sorted(by_month)
    taken = {month: 0 for month in months}
    remaining = size
    while remaining > 0:
        open_months = [m for m in months if taken[m] < len(by_month[m])]
        share = max(1, remaining // len(open_months))
        for month in open_months:
            allowance = min(share, len(by_month[month]) - taken[month], remaining)
            taken[month] += allowance
            remaining -= allowance
            if remaining == 0:
                break
    return [dict(m) for month in months for m in by_month[month][:taken[month]]]


def _members(records, collection):
    from .acquisition import _collection_summary
    summary = _collection_summary(records, collection)
    if summary["pending"]:
        raise ResearchError("collection_pending", "Complete the population enumeration before drawing the sample",
                            {"pending": summary["pending"]})
    # One entry per work: a work with several reading obligations keeps the last of them,
    # which is the version the rest of the harness reads as version_ids[-1].
    members = {}
    for item in summary["reading_obligations"]:
        work = records.get("work", {}).get(item["version_id"]) or {}
        members[item["work_id"]] = {"work_id": item["work_id"], "version_id": item["version_id"],
                                    "month": (work.get("publication_date") or "")[:7]}
    return list(members.values())


def record_sample(store, payload, *, expected_revision, request_id):
    """Draw and record {id, collection_id, size, seed} as the verification's sample."""
    def prepare(records, value):
        fields(value, ("id", "collection_id", "size", "seed"), ("depth",))
        text(value["id"], "Sample ID")
        text(value["seed"], "Sample seed")
        research_tool = ((records.get("configuration", {}).get("research") or {}).get("profile") == "research"
                         and ("depth" in value or find_current_depth_plan(records) is not None))
        if not research_tool:
            _require_sampled(records)
        depth = resolve_depth_values(records, value.get("depth"), keys=("sample_size",))
        if type(value["size"]) is not int or not 1 <= value["size"] <= depth["sample_size"]:
            raise ResearchError("invalid_input", "The sample size is between 1 and " + str(depth["sample_size"]))
        collection = records.get("collection", {}).get(value["collection_id"])
        if collection is None:
            raise ResearchError("cohort_missing", "Select the frozen population collection", {"collection_id": value["collection_id"]})
        members = _members(records, collection)
        population_digest = digest(sorted(m["work_id"] for m in members))
        existing = current_sample(records)
        if (existing is not None and existing["collection_id"] == value["collection_id"]
                and existing["population_digest"] == population_digest):
            raise ResearchError("sample_exists", "This verification already drew its sample; draw again only after the population changed",
                                {"sample_id": existing["id"]})
        drawn = draw(members, value["size"], value["seed"])
        months = {}
        for item in members:
            months.setdefault(item["month"], {"population": 0, "sampled": 0})["population"] += 1
        for item in drawn:
            months[item["month"]]["sampled"] += 1
        record = {"id": value["id"], "collection_id": value["collection_id"], "seed": value["seed"], "size": value["size"],
                  "population": len(members), "population_digest": population_digest,
                  "months": months, "members": drawn, "revision": expected_revision + 1, "depth": depth}
        return [immutable_record(records, "cohort_sample", value["id"], record),
                ("cohort_sample_selection", "current", {"id": value["id"]})], record

    return prepared_mutation(store, "cohort.sample", payload, prepare, expected_revision=expected_revision, request_id=request_id)


def current_sample(records):
    selection = records.get("cohort_sample_selection", {}).get("current")
    return records.get("cohort_sample", {}).get(selection["id"]) if selection else None


def placements(records, sample):
    """The placement judgment recorded on each sampled member's abstract reading, by version.
    Readings are taken in batch order, so the latest batch's placement is the one that stands."""
    batches = records.get("reading_batch", {})
    wanted = {m["version_id"] for m in sample["members"]}
    judged = [r for r in records.get("reading", {}).values()
              if (r.get("batch") or {}).get("placement") and r["version_id"] in wanted
              and r["assessment"]["status"] == "complete"]
    judged.sort(key=lambda r: (batches.get(r["batch"]["batch_id"], {}).get("revision", 0), r["id"]))
    return {r["version_id"]: r["batch"]["placement"] for r in judged}


def prediction(records):
    """The percentile estimate and one-standard-error band the sample supports."""
    sample = current_sample(records)
    if sample is None:
        raise ResearchError("sample_missing", "Draw the verification sample before predicting")
    judged = placements(records, sample)
    above = sum(p["position"] == "above" for p in judged.values())
    below = sum(p["position"] == "below" for p in judged.values())
    unplaced = sum(p["position"] == "unplaced" for p in judged.values())
    placed = above + below
    if placed == 0:
        return {"sample_id": sample["id"], "size": len(sample["members"]), "n": len(judged), "placed": 0,
                "above": above, "below": below, "unplaced": unplaced,
                "percentile": None, "standard_error": None, "band": None, "widen_required": unplaced > UNPLACED_WIDEN}
    share = above / placed
    error = math.sqrt(share * (1 - share) / placed) * 100
    # The platform states a percentile and a band as integers from 1 to 100, with best <= percentile <= worst.
    percentile = min(100, max(1, round((1 - share) * 100)))
    band = {"best": max(1, round(percentile - error)), "worst": min(100, round(percentile + error))}
    return {"sample_id": sample["id"], "size": len(sample["members"]), "n": len(judged), "placed": placed,
            "above": above, "below": below, "unplaced": unplaced,
            "percentile": percentile, "standard_error": round(error, 2), "band": band, "widen_required": unplaced > UNPLACED_WIDEN}


def search_readings(records):
    """Abstract readings a verification registered from targeted search hits."""
    return sorted((r for r in records.get("reading", {}).values() if (r.get("batch") or {}).get("search_hit")), key=lambda r: r["id"])


def sample_obligations(records, collection, inventory):
    """The sampled policy's obligations for one collection: a current sample, and a placed abstract reading per sampled member."""
    sample = current_sample(records)
    counts = {"sampled": 0, "read": 0, "placed": 0}
    if sample is None or sample["collection_id"] != collection["id"]:
        return [obligation("sample_missing", "Draw the stratified random sample of this population before reading.", collection_id=collection["id"])], counts
    population = digest(sorted({item["work_id"] for item in inventory}))
    if population != sample["population_digest"]:
        return [obligation("sample_stale", "The population changed after the sample was drawn; draw a new sample.", sample_id=sample["id"])], counts
    by_version = {item["version_id"]: item for item in inventory}
    judged = placements(records, sample)
    found = []
    for member in sample["members"]:
        counts["sampled"] += 1
        item = by_version.get(member["version_id"])
        if item is None or item["reading_id"] is None:
            found.append(obligation("sample_reading_missing", "Read the complete abstract of this sampled member.",
                                    version_id=member["version_id"], work_id=member["work_id"], collection_id=collection["id"],
                                    paths=(item or {}).get("paths", [])))
            continue
        counts["read"] += 1
        if member["version_id"] not in judged:
            found.append(obligation("placement_missing", "Record the placement judgment on this sampled member's reading.",
                                    version_id=member["version_id"], work_id=member["work_id"], collection_id=collection["id"]))
        else:
            counts["placed"] += 1
    return found, counts

"""Current snapshot gates, separate from historical receipts and proof authority."""

from .artifacts import ArtifactStore
from .cohort_evidence import cohort_report
from .claim_dependencies import uses_claim_dependencies
from .development import validate_admitted_execution
from .evaluation import Evaluation
from .execution_evidence import author_readiness_state
from .errors import ResearchError
from .evidence import digest
from .graph import obligation
from .literature import foundation_state
from .principles import configuration_state
from .synthesis import synthesis_state


STAGES = ("initiate", "cohort", "literature", "ideate", "experiment", "write",
          "evaluate", "deposit", "submit", "complete")
BACKWARD = {(stage, "literature") for stage in STAGES[3:-1]} | {
    ("experiment", "ideate"), ("evaluate", "experiment"), ("evaluate", "write")}


def _report(obligations, **values):
    return dict(ready=not obligations, obligations=obligations, digest=digest(values),
                counts={"obligations": len(obligations)}, **values)


def require_ready(report, action):
    if not report["ready"]:
        raise ResearchError("readiness_required", "Current research readiness is required for " + action,
                            {"action": action, "obligations": report["obligations"],
                             "next": "exactory-research next"})
    return report


def gate_state(records, artifacts, action, *, profile=None):
    artifacts = Evaluation.of(records, artifacts)
    # One direct marker lookup, with no history or inventory work for all
    # existing orchestrations. Problem claims own only the post gate.
    problem = "problem" in records.get("workspace", {})
    if problem != (action == "post"):
        return _report([obligation("gate_inapplicable", "Use the gate belonging to this workspace's orchestration.", gate=action)])
    if problem:
        from .problem_delivery import assess_post
        return assess_post(records, artifacts)
    config = records.get("configuration", {}).get("research")
    if config is None:
        return _report([obligation("migration_required", "Initialize or explicitly adopt the current research contract.")])
    profile = profile or config["profile"]
    managed = uses_claim_dependencies(records)
    if profile != config["profile"]:
        return _report([obligation("profile_mismatch", "Use a separate workspace with the applicable profile.")])
    if action == "cohort":
        scope = records.get("literature_scope", {}).get(profile, {})
        return cohort_report(records, artifacts, scope.get("collection_ids", sorted(records.get("collection", {}))))
    if action == "foundation":
        return foundation_state(records, artifacts, profile)
    if action in {"preparation", "verification"}:
        if action == "verification" and profile != "verification":
            return _report([obligation("profile_mismatch", "Verdicts require an independent verification workspace.")])
        return synthesis_state(records, artifacts, profile)
    if action == "direction":
        if not managed:
            return synthesis_state(records, artifacts, profile)
        from .claim_minimums import assess_direction
        from .research_decisions import decision_state
        configuration = configuration_state(records, artifacts, profile)
        decision = decision_state(records, artifacts, "cycle")
        # Before the cycle decision exists, the gate lists the direction minimum
        # itself; a recorded decision carries the minimum in its own obligations.
        minimum = assess_direction(records, artifacts) if decision["decision"] is None else []
        return _report(configuration["obligations"] + decision["obligations"] + minimum,
                       configuration=configuration, research_decision=decision)
    if action == "manuscript-readiness":
        from .publication_scope import assess_manuscript_readiness
        from .decision_integration import with_decision
        return with_decision(assess_manuscript_readiness(records, artifacts), records, artifacts, "write")
    if action in {"readiness", "write"}:
        from .decision_integration import with_decision
        return with_decision(author_readiness_state(records, artifacts), records, artifacts, "write")
    if action == "execution":
        preparation = synthesis_state(records, artifacts, profile)
        pending = [a for key, a in records.get("execution_admission", {}).items()
                   if key not in records.get("execution_outcome", {})]
        obligations = [] if managed else list(preparation["obligations"])
        for admission in pending:
            try:
                validate_admitted_execution(records, artifacts, admission["id"])
            except ResearchError as error:
                obligations.append(obligation(error.code, error.message, admission_id=admission["id"]))
        if not pending:
            obligations.append(obligation("execution_admission_required", "Plan and admit a prospective cycle before entering experiment."))
        return _report(obligations, preparation=preparation, admissions=pending)
    if action in {"manuscript", "publication", "deposited", "submitted"}:
        from .publication import publication_state
        return publication_state(records, artifacts, action)
    if action == "round":
        from .rounds import round_state
        return round_state(records, artifacts)
    if action == "initiate":
        # Fixing the objective is a supported preparation operation before
        # literature -> ideate. Intake itself does not require that objective.
        return _report([], configuration=config)
    raise ResearchError("invalid_gate", "Unknown research gate", {"action": action})


def gate_report(store, action, *, profile=None):
    snapshot = store.snapshot()
    report = gate_state(snapshot["records"], Evaluation(snapshot["records"], ArtifactStore(store.root)), action, profile=profile)
    return dict(report, revision=snapshot["revision"])


def validate_transition(records, artifacts, previous, proposed):
    artifacts = Evaluation.of(records, artifacts)
    source, target = previous["stage"], proposed["stage"]
    managed = uses_claim_dependencies(records)
    if source not in STAGES or target not in STAGES:
        raise ResearchError("invalid_stage", "Unsupported study stage")
    if any(row.get("transition") == {"from": source, "to": target}
           for row in records.get("gate_override", {}).values()):
        return
    if (target != source and (source, target) not in BACKWARD
            and STAGES.index(target) != STAGES.index(source) + 1
            and not (managed and (source, target) == ("initiate", "literature"))):
        raise ResearchError("readiness_transition", "Research readiness does not permit a direct stage jump",
                            {"from": source, "to": target, "next": "exactory-research next"})
    if (source, target) in BACKWARD:
        if (source, target) == ("experiment", "ideate") and not records.get("cycle_assessment"):
            raise ResearchError("readiness_required", "Assess the experiment before returning to ideate")
        if proposed["status"] == "done":
            raise ResearchError("readiness_required", "A return for more work cannot assert that work is done")
        if managed and target == "ideate":
            require_ready(gate_state(records, artifacts, "direction"), "entering ideate")
        if (source, target) == ("evaluate", "literature"):
            if managed:
                from .research_decisions import decision_state
                report = require_ready(decision_state(records, artifacts, "round"), "entering a development round")
                if report["decision"]["payload"]["action"] not in ("investigate", "pivot"):
                    raise ResearchError("readiness_required", "A return to literature requires an approved investigate or pivot decision")
                return
            # The round entry: round-admit opened the next round, which is then active until its assessment.
            from .rounds import active_round, round_state
            if active_round(records) is None:
                report = round_state(records, artifacts)
                raise ResearchError("readiness_required", "A development round is entered after round-admit opens an approved continue decision",
                                    {"action": "entering a development round", "decision": report["decision"],
                                     "obligations": report["obligations"], "next": "exactory-research gate round"})
        return
    if target == source and proposed["status"] != "done":
        return
    completed = {
        "initiate": "initiate", "cohort": "cohort", "literature": "preparation",
        "ideate": "execution", "experiment": "readiness", "write": "manuscript",
        "evaluate": "publication", "deposit": "deposited", "submit": "submitted", "complete": "submitted",
    }
    if managed:
        completed["literature"] = "direction"
    from .publication_scope import has_publication_scope
    scoped = has_publication_scope(records)
    if scoped:
        completed["experiment"] = "manuscript-readiness"
    if not (managed and source == "cohort" and target != source):
        require_ready(gate_state(records, artifacts, completed[source]), source + " completion")
    if (source, target) == ("evaluate", "deposit"):
        from .rounds import round_state
        # A ready round gate is an approved stop: an active round owes its assessment, and an approved continue owes its admission.
        require_ready(round_state(records, artifacts), "entering deposit")
    prerequisites = {"ideate": "preparation", "experiment": "execution", "write": "readiness",
                     "evaluate": "manuscript", "deposit": "publication", "submit": "deposited", "complete": "submitted"}
    if managed:
        prerequisites["ideate"] = "direction"
    if scoped:
        prerequisites["write"] = "manuscript-readiness"
    if target in prerequisites:
        require_ready(gate_state(records, artifacts, prerequisites[target]), "entering " + target)
    if proposed["status"] == "done" and target != source:
        require_ready(gate_state(records, artifacts, completed[target]), target + " completion")

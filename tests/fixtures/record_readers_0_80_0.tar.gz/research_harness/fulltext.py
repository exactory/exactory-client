"""Conservative full-text extraction, independent of acquisition and reading.

extract(data, media_type, *, extractor=None, layout=True) -> {status, text,
includes_abstract, visual_inspection_required, extractor, version, options,
media_type, format_detection}. media_type is the type the extraction used and
format_detection names how it was decided: 'reported_media_type', or
'pdf_signature_from_generic_binary' for an application/octet-stream or
binary/octet-stream body whose bytes start with the PDF signature.
detect_media_type(data, media_type) keeps reported spellings for review delivery;
extraction recognizes their normalized base types. PDF extractor injection
accepts bytes and returns {status, text}; its successful status is 'extracted'.
extraction_measures(text, original_size) describes an extraction (bytes, pages,
longest line, whitespace fraction, expansion) so a coordinator sees layout
padding before a reader does; a high value is a signal to inspect, never a
reason to truncate. Missing, scanned, malformed or timed-out extraction remains
pending.
The default pdftotext invocation uses explicit argv, a timeout, a private temp
directory, and a bounded output read. HTML requires article-body structure with
nonempty content blocks beyond titles, metadata and abstracts. XML
(application/xml or text/xml) is read as a JATS article when the local name of
its root element is article: the text of the whole document is saved with a
break at each block element, body content is text in paragraphs, list items,
table cells and similar elements inside body outside headings, abstracts and
metadata, and the href of each graphic inside a fig is returned as
visual_asset_names, names only. The parser matches element names by local
name, loads no external DTD or entity and expands no declared entity: an
internal entity declaration is 'xml_internal_entity', a reference to an
external entity or to one that only an external DTD defines is
'xml_external_entity', invalid XML is 'malformed_xml', an article without body
content is 'landing_page', and other XML stays 'unsupported_fulltext'.
includes_abstract only describes nonempty abstract content actually saved in
the extraction. HTTP success or arbitrary extracted text is not evidence of
full-text availability. No function here creates a reading record.
"""

import math
import os
import re
import selectors
import shutil
import subprocess
import tempfile
import time
from html.parser import HTMLParser
from pathlib import Path
from xml.parsers import expat

from .errors import ResearchError


def extraction_measures(text, original_size):
    """Describe an extraction so oversized or padded text is visible before reading."""
    pages = text.split("\f")
    if pages and not pages[-1].strip():
        pages.pop()
    encoded = len(text.encode("utf-8"))
    return {"text_bytes": encoded, "page_count": max(1, len(pages)),
            "max_line_length": max((len(line) for line in text.splitlines()), default=0),
            "whitespace_fraction": round(sum(c.isspace() for c in text) / len(text), 4) if text else 0.0,
            "expansion_ratio": round(encoded / original_size, 3) if original_size else None}


class PdfExtractor:
    name = "pdftotext"

    def __init__(self, *, executable=None, timeout=30, max_text_bytes=32 * 1024 * 1024, layout=True,
                 pdfinfo_executable=None):
        if not isinstance(timeout, (float, int)) or not math.isfinite(timeout) or timeout <= 0:
            raise ResearchError("invalid_input", "PDF extraction timeout must be positive and finite")
        if type(max_text_bytes) is not int or max_text_bytes < 0:
            raise ResearchError("invalid_input", "PDF extraction output limit must be a nonnegative integer")
        if type(layout) is not bool:
            raise ResearchError("invalid_input", "PDF layout mode must be a boolean")
        self.executable = executable if executable is not None else shutil.which("pdftotext")
        self.timeout, self.max_text_bytes, self.layout = timeout, max_text_bytes, layout
        self.pdfinfo_executable = pdfinfo_executable if pdfinfo_executable is not None else shutil.which("pdfinfo")

    def version(self):
        """The extractor's reported version, or None when it cannot be determined."""
        if not self.executable:
            return None
        try:
            result = subprocess.run([self.executable, "-v"], capture_output=True, text=True, timeout=5,
                                    stdin=subprocess.DEVNULL)
        except (OSError, subprocess.SubprocessError, UnicodeError):
            return None
        match = re.search(r"version\s+(\S+)", result.stdout + result.stderr)
        return match.group(1) if match else None

    def get_page_options(self):
        return {"layout": self.layout}

    def read_page_tool_versions(self, *, run=None, deadline=None):
        from .ocr import read_pdf_tool_versions
        return read_pdf_tool_versions({"pdfinfo": self.pdfinfo_executable, "pdftotext": self.executable},
                                      run=run, deadline=deadline)

    def count_pages(self, original, *, run=None, deadline=None):
        from .ocr import count_pdf_pages
        return count_pdf_pages(original, self.pdfinfo_executable, run=run,
                               deadline=deadline if deadline is not None else time.monotonic() + self.timeout)

    def extract_page(self, original, page, *, run=None, deadline=None):
        """Extract one path-backed page; a successful blank page returns an empty string."""
        from .ocr import run_page_tool
        if type(page) is not int or page < 1:
            raise ResearchError("invalid_input", "PDF page index must be a positive integer")
        deadline = min(deadline, time.monotonic() + self.timeout) if deadline is not None else time.monotonic() + self.timeout
        argv = [self.executable, "-enc", "UTF-8"] + (["-layout"] if self.layout else [])
        argv += ["-f", str(page), "-l", str(page), str(original), "-"]
        data = run_page_tool(argv, self.max_text_bytes, deadline, run=run)
        # A single-page pdftotext result ends with one form feed. The protocol
        # supplies its own separator, including for a page with no output.
        text = data.decode("utf-8")
        return text[:-1] if text.endswith("\f") else text

    def __call__(self, data):
        if not self.executable:
            return {"status": "extractor_missing", "text": None}
        with tempfile.TemporaryDirectory(prefix="exactory-pdf-") as directory:
            original = Path(directory) / "source.pdf"
            original.write_bytes(data)
            process = None
            try:
                deadline = time.monotonic() + self.timeout
                argv = [self.executable, "-enc", "UTF-8"] + (["-layout"] if self.layout else []) + [str(original), "-"]
                process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                text = bytearray()
                with selectors.DefaultSelector() as selector:
                    selector.register(process.stdout, selectors.EVENT_READ)
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0 or not selector.select(remaining):
                            return {"status": "extraction_timeout", "text": None}
                        chunk = os.read(process.stdout.fileno(), min(65536, self.max_text_bytes + 1 - len(text)))
                        if not chunk:
                            break
                        text.extend(chunk)
                        if len(text) > self.max_text_bytes:
                            return {"status": "extraction_too_large", "text": None}
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return {"status": "extraction_timeout", "text": None}
                if process.wait(timeout=remaining) != 0:
                    return {"status": "malformed_pdf", "text": None}
                text = text.decode("utf-8")
                return {"status": "extracted" if text.strip() else "empty_text", "text": text if text.strip() else None,
                        "extractor": self.name, "version": self.version(), "options": {"layout": self.layout}}
            except subprocess.TimeoutExpired:
                return {"status": "extraction_timeout", "text": None}
            except FileNotFoundError:
                return {"status": "extractor_missing", "text": None}
            except (OSError, UnicodeError):
                return {"status": "extraction_failed", "text": None}
            finally:
                if process is not None:
                    if process.poll() is None:
                        process.kill()
                    try:
                        process.wait(timeout=1)
                    except subprocess.TimeoutExpired as error:
                        raise ResearchError("extraction_cleanup_failed", "PDF extractor did not stop after termination") from error
                    finally:
                        process.stdout.close()


class _Article(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.text = []
        self.all_text = []
        self.body_text = []
        self.included_abstract = False
        self.has_article = False
        self.has_body = False

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").lower().split())
        properties = set((attributes.get("itemprop") or "").lower().split())
        roles = set((attributes.get("role") or "").lower().split())
        parent = self.stack[-1][1] if self.stack else {"skip": False, "article": False, "abstract": False,
                                                    "body": False, "heading": False, "metadata": False,
                                                    "references": False, "content": False}
        state = dict(parent)
        state["skip"] = state["skip"] or tag in ("script", "style", "nav", "form", "noscript")
        state["article"] = state["article"] or tag == "article" or bool(classes & {"ltx_document", "article-body", "article__body", "jats_body"})
        state["abstract"] = (state["abstract"] or tag == "abstract" or "doc-abstract" in roles or "abstract" in properties
                             or bool(classes & {"abstract", "ltx_abstract", "article-abstract"}) or attributes.get("id") in ("abstract", "Abs1"))
        state["body"] = state["body"] or bool(
            classes & {"article-body", "article__body", "jats_body", "ltx_section", "main-article-body"})
        state["heading"] = state["heading"] or tag in ("h1", "h2", "h3", "h4", "h5", "h6", "title") or "heading" in roles or bool(properties & {"headline", "name"}) or bool(
            classes & {"title", "subtitle", "article-title", "article__title", "ltx_title", "jats_title"})
        state["metadata"] = state["metadata"] or tag in ("header", "footer", "aside", "address", "time") or bool(
            properties & {"author", "affiliation", "datepublished", "datemodified", "datecreated", "publisher", "identifier", "keywords", "copyrightnotice"}) or bool(
            classes & {"metadata", "article-meta", "article__meta", "article-info", "authors", "author", "affiliation",
                       "affiliations", "article-author", "article-authors", "byline", "journal", "publication-date", "ltx_authors", "ltx_date"})
        state["references"] = state["references"] or "ref-list" in classes
        state["content"] = state["content"] or tag in ("p", "li", "dd", "td", "pre", "blockquote") or bool(
            classes & {"ltx_para", "ltx_p", "paragraph"})
        self.has_article |= state["article"]
        self.has_body |= state["body"]
        if tag not in ("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"):
            self.stack.append((tag, state))
        if tag in ("p", "div", "section", "h1", "h2", "h3", "br", "li", "tr"):
            self.text.append("\n")

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break
        if tag in ("p", "div", "section", "h1", "h2", "h3", "li", "tr"):
            self.text.append("\n")

    def handle_data(self, data):
        state = self.stack[-1][1] if self.stack else None
        if state and state["skip"]:
            return
        self.all_text.append(data)
        if state and state["article"]:
            self.text.append(data)
            if state["abstract"] and not state["heading"] and data.strip():
                self.included_abstract = True
            if state["body"] and state["content"] and not any(
                    state[key] for key in ("abstract", "heading", "metadata", "references")):
                self.body_text.append(data)


JATS_MAX_ELEMENTS = 200000
JATS_MAX_DEPTH = 256
JATS_MAX_TEXT_CHARACTERS = 32 * 1024 * 1024
JATS_TIMEOUT_SECONDS = 10


class _JatsArticle:
    """Read article text and figure names without resolving XML dependencies."""

    blocks = frozenset({"front", "body", "back", "abstract", "trans-abstract", "sec", "title", "subtitle",
                        "article-title", "journal-title", "contrib", "kwd", "p", "list", "list-item", "def-list",
                        "def-item", "term", "def", "disp-quote", "preformat", "fig", "caption", "label",
                        "table-wrap", "table", "tr", "td", "th", "ref-list", "ref", "ack", "break"})

    def __init__(self):
        self.root = None
        self.stack = []
        self.text = []
        self.body_text = []
        self.abstract_text = []
        self.visual_asset_names = []
        self.visual_asset_set = set()
        self.declaration = None
        self.deadline = None
        self.element_count = 0
        self.text_characters = 0
        self.token_depth = 0
        self.in_cdata = False
        self.in_attribute_declaration = False

    def require_time(self):
        if time.monotonic() > self.deadline:
            raise ResearchError("xml_timeout", "JATS XML extraction exceeded its time limit")

    def require_resolved_entities(self, token):
        for entity in re.findall(r"&([^;\s]+);", token):
            if not entity.startswith("#") and entity not in ("amp", "lt", "gt", "quot", "apos"):
                self.refuse_external_entity()

    def validate_token(self, token):
        self.require_time()
        self.text_characters += len(token)
        if self.text_characters > JATS_MAX_TEXT_CHARACTERS:
            raise ResearchError("xml_text_limit", "JATS XML exceeds the text size limit")
        if token == "<![CDATA[":
            self.in_cdata = True
        elif token == "]]>":
            self.in_cdata = False
        elif not self.in_cdata and token == "<!ATTLIST":
            self.in_attribute_declaration = True
        elif self.in_attribute_declaration:
            self.require_resolved_entities(token)
            if token == ">":
                self.in_attribute_declaration = False
        elif not self.in_cdata and token.startswith("<") and not token.startswith(("<!", "<?")):
            if token.startswith("</"):
                self.token_depth -= 1
            else:
                self.element_count += 1
                depth = self.token_depth + 1
                if self.element_count > JATS_MAX_ELEMENTS:
                    raise ResearchError("xml_element_limit", "JATS XML exceeds the element count limit")
                if depth > JATS_MAX_DEPTH:
                    raise ResearchError("xml_depth_limit", "JATS XML exceeds the nesting depth limit")
                if not token.endswith("/>"):
                    self.token_depth = depth
                self.require_resolved_entities(token)
        if not self.in_cdata:
            self.handle_default(token)

    def handle_start(self, name, attrs):
        self.require_time()
        tag = name.rsplit("}", 1)[-1]
        if self.root is None:
            self.root = tag
        state = dict(self.stack[-1]) if self.stack else dict.fromkeys(
            ("body", "abstract", "heading", "metadata", "content", "figure"), False)
        state["body"] |= tag == "body"
        state["abstract"] |= tag in ("abstract", "trans-abstract")
        state["heading"] |= tag in ("title", "subtitle", "article-title", "alt-title", "label")
        state["metadata"] |= tag in ("front", "back", "article-meta", "journal-meta", "ref-list", "ref",
                                    "kwd-group", "contrib-group", "aff", "permissions", "author-notes")
        state["content"] |= tag in ("p", "list-item", "def", "td", "preformat", "disp-quote")
        state["figure"] |= tag == "fig"
        self.stack.append(state)
        if tag in self.blocks:
            self.text.append("\n")
        if tag == "graphic" and state["figure"]:
            for attribute, value in attrs.items():
                if attribute.rsplit("}", 1)[-1] == "href" and value.strip():
                    asset = value.strip()
                    if asset not in self.visual_asset_set:
                        self.visual_asset_set.add(asset)
                        self.visual_asset_names.append(asset)

    def handle_end(self, name):
        self.require_time()
        self.stack.pop()
        if name.rsplit("}", 1)[-1] in self.blocks:
            self.text.append("\n")

    def handle_characters(self, data):
        self.require_time()
        if not self.stack:
            return
        state = self.stack[-1]
        self.text.append(data)
        if state["abstract"] and not state["heading"]:
            self.abstract_text.append(data)
        if state["body"] and state["content"] and not any(
                state[key] for key in ("abstract", "heading", "metadata")):
            self.body_text.append(data)

    def handle_default(self, token):
        if token.startswith("%") and token.endswith(";"):
            self.refuse_external_entity()
        # DefaultHandler also sees declarations that EntityDeclHandler omits.
        if token == "<!ENTITY":
            self.declaration = []
        elif self.declaration is not None and token.strip():
            if token == ">":
                self.declaration = None
                return
            self.declaration.append(token)
            value_index = 2 if self.declaration[0] == "%" else 1
            if len(self.declaration) == value_index + 1 and token[0] in "\"'":
                raise ResearchError("xml_internal_entity",
                                    "JATS XML with an internal entity declaration is not extracted")

    def refuse_external_entity(self, *args):
        raise ResearchError("xml_external_entity", "JATS XML requiring an external entity is not extracted")

    def parse(self, data):
        self.deadline = time.monotonic() + JATS_TIMEOUT_SECONDS
        # Without a start handler Expat supplies decoded, unexpanded start tokens,
        # including attribute references it otherwise silently drops after an unread DTD.
        # Validate namespace declaration references before Expat binds their URIs.
        tokens = expat.ParserCreate()
        tokens.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
        tokens.DefaultHandler = self.validate_token
        tokens.ExternalEntityRefHandler = self.refuse_external_entity
        tokens.SkippedEntityHandler = self.refuse_external_entity
        self.parse_chunks(tokens, data)
        parser = expat.ParserCreate(namespace_separator="}")
        parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
        parser.StartElementHandler = self.handle_start
        parser.EndElementHandler = self.handle_end
        parser.CharacterDataHandler = self.handle_characters
        parser.DefaultHandler = self.handle_default
        parser.ExternalEntityRefHandler = self.refuse_external_entity
        parser.SkippedEntityHandler = self.refuse_external_entity
        self.parse_chunks(parser, data)

    def parse_chunks(self, parser, data):
        for start in range(0, len(data), 65536):
            self.require_time()
            parser.Parse(data[start:start + 65536], False)
        self.require_time()
        parser.Parse(b"", True)
        self.require_time()


GENERIC_BINARY_MEDIA_TYPES = frozenset({"application/octet-stream", "binary/octet-stream"})
XML_MEDIA_TYPES = frozenset({"application/xml", "text/xml"})


def parse_base_media_type(media_type):
    """Normalize a type for comparisons without changing the reported descriptor or capture."""
    return media_type.split(";", 1)[0].strip().lower() if isinstance(media_type, str) else ""


def detect_media_type(data, media_type):
    """Recognize PDF and raster signatures in generic binary; preserve other reported types."""
    if media_type in GENERIC_BINARY_MEDIA_TYPES and data.startswith(b"%PDF-"):
        return "application/pdf", "pdf_signature_from_generic_binary"
    if media_type in GENERIC_BINARY_MEDIA_TYPES:
        for signature, detected in ((b"\x89PNG\r\n\x1a\n", "image/png"), (b"\xff\xd8\xff", "image/jpeg"),
                                    (b"GIF87a", "image/gif"), (b"GIF89a", "image/gif")):
            if data.startswith(signature):
                return detected, "image_signature_from_generic_binary"
        if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
            return "image/webp", "image_signature_from_generic_binary"
    return media_type, "reported_media_type"


def extract(data, media_type, *, extractor=None, layout=True, ocr=False):
    # Extraction may recognize base types; review construction keeps the exact reported spelling.
    detected_type, format_detection = detect_media_type(data, parse_base_media_type(media_type))
    if format_detection != "reported_media_type":
        media_type = detected_type
    result = {"status": "unsupported_fulltext", "text": None, "includes_abstract": None, "visual_inspection_required": True,
              "extractor": None, "version": None, "options": {},
              "media_type": media_type, "format_detection": format_detection}
    if parse_base_media_type(media_type) == "application/pdf":
        if extractor is None and ocr:
            from .ocr import OcrPdfExtractor
            extractor = OcrPdfExtractor()
        result.update({"extractor": getattr(extractor, "name", PdfExtractor.name),
                       "options": {"ocr": True} if ocr else {"layout": layout}})
        if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-4096:]:
            result["status"] = "malformed_pdf"
            return result
        extracted = (extractor or PdfExtractor(layout=layout))(data)
        result.update({"status": extracted["status"], "text": extracted["text"],
                       "extractor": extracted.get("extractor", result["extractor"]),
                       "version": extracted.get("version"), "options": extracted.get("options", {"layout": layout})})
        if result["status"] == "extracted" and (not isinstance(result["text"], str) or not result["text"].strip()):
            result["status"], result["text"] = "empty_text", None
        return result
    if parse_base_media_type(media_type) in XML_MEDIA_TYPES:
        result["extractor"] = "jats"
        article = _JatsArticle()
        try:
            article.parse(data)
        except ResearchError as error:
            result["status"] = error.code
        except expat.ExpatError as error:
            entity_errors = (expat.errors.XML_ERROR_UNDEFINED_ENTITY,
                             expat.errors.XML_ERROR_ATTRIBUTE_EXTERNAL_ENTITY_REF)
            result["status"] = ("xml_external_entity" if error.code in
                                {expat.errors.codes[name] for name in entity_errors} else "malformed_xml")
        except (LookupError, ValueError):
            result["status"] = "malformed_xml"
        else:
            if article.root == "article":
                result["status"] = "landing_page"
                if "".join(article.body_text).strip():
                    result.update({"status": "extracted",
                                   "text": re.sub(r"\n[ \t]*\n+", "\n\n", "".join(article.text)).strip(),
                                   "includes_abstract": bool("".join(article.abstract_text).strip()),
                                   "visual_asset_names": article.visual_asset_names})
        return result
    if parse_base_media_type(media_type) not in ("text/html", "application/xhtml+xml"):
        return result
    try:
        text = data.decode("utf-8-sig")
    except UnicodeError:
        result["status"] = "invalid_encoding"
        return result
    result["extractor"] = "html"
    parser = _Article()
    parser.feed(text)
    parser.close()
    visible = " ".join(" ".join(parser.all_text).lower().split())
    if any(marker in visible for marker in ("checking your browser", "enable javascript and cookies",
            "verify you are human", "checking if the site connection is secure", "access denied", "just a moment...")):
        result["status"] = "challenge"
    elif any(state["article"] for _, state in parser.stack):
        result["status"] = "malformed_html"
    elif not parser.has_article or not parser.has_body or not "".join(parser.body_text).strip():
        result["status"] = "landing_page"
    else:
        result.update({"status": "extracted", "text": re.sub(r"\n[ \t]*\n+", "\n\n", "".join(parser.text)).strip(),
                       "includes_abstract": parser.included_abstract})
    return result

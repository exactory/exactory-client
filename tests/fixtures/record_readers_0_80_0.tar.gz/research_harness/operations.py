"""Prepare domain mutations outside short, nonreentrant Store callbacks.

The domain receipt permits replay before validating today's source selection.
Store remains authoritative for original-result replay, request conflicts and
CAS. Preparation may verify/create immutable artifacts but cannot publish state.
Callbacks only apply the prepared record patch and receipt through Transaction.
"""

import json
from datetime import date, datetime
import math

from .errors import ResearchError
from .storage import _canonical, _PreparedSnapshot, _ScopedPreparation, _text


def fields(value, required, optional=(), *, code="invalid_input", path=None):
    if (not isinstance(value, dict) or not set(required) <= value.keys()
            or optional is not None and not value.keys() <= set(required) | set(optional)):
        details = None
        if path is not None:
            received = set(value) if isinstance(value, dict) else set()
            types = {dict: "object", list: "array", str: "string", type(None): "null",
                     bool: "boolean", int: "number", float: "number"}
            details = {"path": path, "expected_type": "object",
                       "received_type": types.get(type(value), type(value).__name__),
                       "missing_fields": sorted(set(required) - received),
                       "unexpected_fields": sorted(received - set(required) - set(optional)) if optional is not None else []}
        raise ResearchError(code, "Expected fields: " + ", ".join(sorted(required)) +
                            ("; optional: " + ", ".join(sorted(optional)) if optional else ""), details)


def text(value, name, *, code="invalid_input"):
    _text(value, name, code)
    return value


def normalized_text(value):
    """Casefolded text with every run of whitespace collapsed to one space, for comparing statements."""
    return " ".join(value.casefold().split())


def strings(value, name, *, nonempty=False, code="invalid_input"):
    if not isinstance(value, list) or nonempty and not value:
        raise ResearchError(code, name + " must be an array" + (" with at least one entry" if nonempty else ""))
    for item in value:
        text(item, name, code=code)
    if len(set(value)) != len(value):
        raise ResearchError(code, name + " cannot contain duplicates")
    return value


def is_finite_number(value):
    """Whether value is an int or a float, not a bool, with a finite float value. An integer beyond the float range
    (about 1.8e308) has none, and math.isfinite raises OverflowError for it."""
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def describe_received_value(name, value):
    """A received value by name for refusal details when it is a boolean or a finite number; any other value, which
    could nest beyond the store's bounds, is named only by the path of the error."""
    return {name: value} if type(value) is bool or is_finite_number(value) else {}


def profile_name(value):
    if value not in ("research", "verification"):
        raise ResearchError("invalid_profile", "Profile must be research or verification")
    return value


def iso_date(value):
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError()
        return parsed
    except (TypeError, ValueError) as error:
        raise ResearchError("invalid_input", "Expected an ISO calendar date") from error


def timestamp(value):
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.utcoffset() is None:
            raise ValueError()
        return parsed
    except (TypeError, AttributeError, ValueError) as error:
        raise ResearchError("invalid_input", "Expected a timestamp with an explicit timezone") from error


def _read_preparation(store, snapshot=None):
    """Reuse only an internally owned read from this Store; authenticate all other inputs afresh."""
    if isinstance(snapshot, _PreparedSnapshot) and snapshot._store is store and snapshot.records is not None:
        return snapshot
    return store._read_preparation()


def prepared_mutation(store, operation, payload, prepare, *, expected_revision, request_id, _snapshot=None,
                      validate_commit=None):
    """prepare(records, payload) returns ([(kind, key, value), ...], result).

    Optional validate_commit(transaction, result) checks admission in the same
    serialized write, before applying the prepared patch. It performs no external I/O.
    """
    text(request_id, "Request ID")
    if not isinstance(payload, dict):
        raise ResearchError("invalid_input", "A domain mutation requires a JSON object")
    payload = json.loads(_canonical(payload))
    snapshot = _read_preparation(store, _snapshot)
    if snapshot.has_request(request_id):
        # The Store checks the original operation and payload before invoking a
        # callback, including when the caller supplies the historical revision.
        return store.mutate(operation, payload, lambda tx: None,
                            expected_revision=expected_revision, request_id=request_id,
                            _preparation=snapshot.release_proof())
    if type(expected_revision) is not int or expected_revision < 0:
        raise ResearchError("invalid_input", "Expected revision must be a nonnegative integer")
    if snapshot.revision != expected_revision:
        raise ResearchError("stale_revision", "Research state changed; read the current revision before a new mutation",
                            {"expected_revision": expected_revision, "revision": snapshot.revision})
    changes, result = prepare(snapshot.records, payload)
    runtime = store.describe_runtime()

    def apply(transaction):
        if validate_commit is not None:
            validate_commit(transaction, result)
        for kind, key, value in changes:
            transaction.put(kind, key, value)
        transaction.put("literature_operation", request_id, {"operation": operation, "runtime": runtime})
        return result

    return store.mutate(operation, payload, apply, expected_revision=expected_revision, request_id=request_id,
                        _preparation=snapshot.release_proof())


def immutable_record(records, kind, key, value):
    text(key, "Record ID")
    existing = records.get(kind, {}).get(key)
    if existing is not None and existing != value:
        raise ResearchError("record_conflict", "An evidence record ID cannot replace historical content",
                            {"kind": kind, "id": key})
    return kind, key, value


def prepared_task_mutation(store, operation, payload, prepare, *, request_id, expected_revision=None, finalize=None,
                           _snapshot=None, validate_commit=None):
    """Prepare a tracked task patch; finalize(changes, result, commit_revision) may stamp commit fields."""
    text(request_id, "Request ID")
    if not isinstance(payload, dict):
        raise ResearchError("invalid_input", "A domain mutation requires a JSON object")
    payload = json.loads(_canonical(payload))
    snapshot = (_snapshot if isinstance(_snapshot, _ScopedPreparation) and _snapshot._store is store
                and _snapshot.records is not None else store._read_scoped_preparation())
    if snapshot.has_request(request_id):
        return store.mutate_scoped(operation, payload, lambda tx, revision: None,
                                   request_id=request_id, expected_revision=expected_revision,
                                   _preparation=snapshot.release_proof())
    if expected_revision is not None:
        if type(expected_revision) is not int or expected_revision < 0:
            raise ResearchError("invalid_input", "Expected revision must be a nonnegative integer")
        if expected_revision != snapshot.revision:
            raise ResearchError("stale_revision", "Prepare against the expected research revision",
                                {"expected_revision": expected_revision, "revision": snapshot.revision})
    changes, result = prepare(snapshot.records, payload)
    # Own the prepared values and every write target, including blind writes.
    changes, result = json.loads(_canonical([changes, result]))
    for kind, key, value in changes:
        snapshot.bind_record(kind, key)
    snapshot.bind_record("literature_operation", request_id)
    write_targets = tuple((kind, key) for kind, key, _ in changes)
    runtime = store.describe_runtime()

    def apply(transaction, revision):
        current_changes, current_result = changes, result
        if finalize is not None:
            current_changes, current_result = finalize(current_changes, current_result, revision)
            if tuple((kind, key) for kind, key, _ in current_changes) != write_targets:
                raise ResearchError("invalid_preparation", "Commit finalization cannot change prepared write targets")
        if validate_commit is not None:
            validate_commit(transaction, current_result, revision)
        for kind, key, value in current_changes:
            transaction.put(kind, key, value)
        transaction.put("literature_operation", request_id, {"operation": operation, "runtime": runtime})
        return current_result

    return store.mutate_scoped(operation, payload, apply, request_id=request_id, expected_revision=expected_revision,
                               _preparation=snapshot.release_proof())
